function New-ScmAzCertificateInputs
{
    <#
    .Synopsis

    .DESCRIPTION

    .EXAMPLE

    #>
    [CmdletBinding()]
    [OutputType([PreProdCert], [StageCert], [ProductionCert])]
    param
    (
        # Deloitte Channel
        [Parameter(Mandatory)]
        [string]$Channel,

        # Scm Project Code
        # Project specific
        [Parameter(Mandatory)]
        [string]$ProjectCode,

        # Production URL
        [Parameter(Mandatory)]
        [string]$ProductionUrl,

        # Production App Service Name
        [Parameter(Mandatory)]
        [string]$ProductionAppServiceName,

        # Bcp App Service Name
        [Parameter(Mandatory)]
        [string]$BcpAppServiceName
    )
    begin
    {
    }
    process
    {
        [CertFactory]::Generate(
            $Channel,
            $ProjectCode,
            $ProductionUrl,
            $ProductionAppServiceName,
            $BcpAppServiceName
        )
    }
    end
    {
    }
}
