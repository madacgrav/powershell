class CertProperties
{
    [ValidateSet('preprod', 'stg', 'prod')]
    [string]$Environment
    
    [string]$FriendlyName

    [string]$CommonName

    [string[]]$SubjectAlternativeName    

    CertProperties ([string]$friendlyName, [string]$commonName, [string[]]$subjectAlternativeName, [string]$environment)
    {
        $type = $this.GetType()

        if ($type -eq [CertProperties])
        {
            throw "Class $type must be inherited"
        }

        $this.CommonName = $commonName.ToLower().Trim()
        $this.FriendlyName = $friendlyName.ToLower().Trim()
        $this.Environment = $environment.ToLower().Trim()
        
        foreach ($san in $subjectAlternativeName)
        {
            $this.SubjectAlternativeName += $san.ToLower().Trim()
        }
    }
}

class CertFactory
{
    static [CertProperties[]] Generate([string]$dasChannel, [string]$projectCode, [string]$prodUrl, [string]$prodAppService, [string]$bcpAppService)
    {
        $certInfo = New-Object -TypeName 'System.Collections.Generic.List[CertProperties]'
        $certInfo.Add([PreProdCert]::Generate($dasChannel, $projectCode, $prodUrl, $prodAppService))
        $certInfo.Add([StageCert]::Generate($dasChannel, $projectCode, $prodUrl, $prodAppService))
        $certInfo.Add([ProductionCert]::Generate($dasChannel, $projectCode, $prodUrl, $prodAppService, $bcpAppService))
        return $certInfo
    }
}

class PreProdCert : CertProperties
{
    PreProdCert (
        [string]$friendlyName, [string]$commonName, [string[]]$subjectAlternativeName, [string]$environment
    ): base ($friendlyName, $commonName, $subjectAlternativeName, $environment)
    {

    }

    static [PreProdCert] Generate ([string]$dasChannel, [string]$projectCode, [string]$url, [string]$appService)
    {
        $environment = 'preprod'
        $subjectAlternativeName = New-Object -TypeName 'System.Collections.Generic.List[string]'

        $friendlyName = "$dasChannel-das$projectCode-$environment-appcert"
        $commonName = "d$url"
        $subjectAlternativeName.Add("d$url")
        $subjectAlternativeName.Add("q$url")
        $subjectAlternativeName.Add("d$appService.$dasChannel.app.deloitte.com")
        $subjectAlternativeName.Add("q$appService.$dasChannel.app.deloitte.com")
        
        return [PreProdCert]::new($friendlyName, $commonName, $subjectAlternativeName, $environment)
    }
}

class StageCert : CertProperties
{
    StageCert (
        [string]$friendlyName, [string]$commonName, [string[]]$subjectAlternativeName, [string]$environment
    ): base ($friendlyName, $commonName, $subjectAlternativeName, $environment)
    {

    }

    static [StageCert] Generate ([string]$dasChannel, [string]$projectCode, [string]$url, [string]$appService)
    {
        $environment = 'stg'
        $subjectAlternativeName = New-Object -TypeName 'System.Collections.Generic.List[string]'

        $friendlyName = "$dasChannel-das$projectCode-$environment-appcert"
        $commonName = "s$url"
        $subjectAlternativeName.Add("s$url")
        $subjectAlternativeName.Add("s$appService.$dasChannel.app.deloitte.com")

        return [StageCert]::new($friendlyName, $commonName, $subjectAlternativeName, $environment)
    }
}

class ProductionCert : CertProperties
{
    ProductionCert (
        [string]$friendlyName, [string]$commonName, [string[]]$subjectAlternativeName, [string]$environment
    ): base ($friendlyName, $commonName, $subjectAlternativeName, $environment)
    {

    }

    static [ProductionCert] Generate ([string]$dasChannel, [string]$projectCode, [string]$url,
        [string]$appService, [string]$bcpAppService)
    {
        $environment = 'prod'
        $subjectAlternativeName = New-Object -TypeName 'System.Collections.Generic.List[string]'

        $friendlyName = "$dasChannel-das$projectCode-$environment-appcert"
        $commonName = "$url"
        $subjectAlternativeName.Add("$url")
        $subjectAlternativeName.Add("$appService.$dasChannel.app.deloitte.com")
        $subjectAlternativeName.Add("$bcpAppService.$dasChannel.app.deloitte.com")

        return [ProductionCert]::new($friendlyName, $commonName, $subjectAlternativeName, $environment)
    }
}
