class AzResource
{
    [string]$Name
    [string]$ProjectCode
    [AzRegionCode]$RegionCode
    hidden [Environment]$Environment
    [string]$UniqueId

    AzResource () { }

    AzResource (
        [string]$projectCode, [AzRegionCode]$regionCode, [Environment]$environment, [string]$uniqueId
    )
    {
        $this.ProjectCode = $projectCode.ToLower()
        $this.RegionCode = $regionCode.ToString().ToLower()
        $this.Environment = $environment.ToString().ToLower()
        $this.UniqueId = $uniqueId.ToLower()
    }
    
    hidden [string] GetNameWithDashes ()
    {
        $_name = "$($this.Environment)-$($this.ProjectCode)-$($this.RegionCode)"
        return $_name
    }

    hidden [string] GetNameWithDashesNoRegion ()
    {
        $_name = "$($this.Environment)-$($this.ProjectCode)"
        return $_name
    }

    hidden [string] GetNameWithoutDashes ()
    {
        $_name = "$($this.Environment)$($this.ProjectCode)$($this.RegionCode)"
        return $_name
    }
}

class AzAppService : AzResource
{    
    hidden [AppServiceType]$AppServiceType

    AzAppService (
        [string]$projectCode, [AzRegionCode]$regionCode, [AppServiceType]$appServiceType, [Environment]$environment, [string]$uniqueId
    )
    : base ($projectCode, $regionCode, $environment, $uniqueId)
    {
        $this.AppServiceType = $appServiceType
        $this.Name = "$($this.GetNameWithDashes())-$($this.AppServiceType.ToString().ToLower())-$($this.UniqueId)"
    }
}

class AzAppServicePlan : AzResource
{    
    AzAppServicePlan (
        [string]$projectCode, [AzRegionCode]$regionCode, [Environment]$environment, [string]$uniqueId
    )
    : base ($projectCode, $regionCode, $environment, $uniqueId)
    {        
        $this.Name = "$($this.GetNameWithDashes())-asp-$($this.UniqueId)"
    }
}

class AzAppServiceEnvironment : AzResource
{    
    AzAppServiceEnvironment (
        [string]$projectCode, [AzRegionCode]$regionCode, [Environment]$environment, [string]$uniqueId
    )
    : base ($projectCode, $regionCode, $environment, $uniqueId)
    {        
        $this.Name = "$($this.GetNameWithDashes())-ase-$($this.UniqueId)"
    }
}

class AzDatabase : AzResource
{    
    AzDatabase (
        [string]$projectCode, [AzRegionCode]$regionCode, [Environment]$environment, [string]$uniqueId
    )
    : base ($projectCode, $regionCode, $environment, $uniqueId)
    {        
        $this.Name = "$($this.GetNameWithDashes())-db"
    }
}

class AzStorageAccount : AzResource
{    
    AzStorageAccount (
        [string]$projectCode, [AzRegionCode]$regionCode, [Environment]$environment, [string]$uniqueId
    )
    : base ($projectCode, $regionCode, $environment, $uniqueId)
    {        
        $this.Name = "$($this.GetNameWithoutDashes())sa$($this.UniqueId)"
    }    
}

class AzKeyVault : AzResource
{        
    hidden [KeyVaultType]$KeyVaultType

    AzKeyVault (
        [string]$projectCode, [AzRegionCode]$regionCode, [KeyVaultType]$keyVaultType, [Environment]$environment, [string]$uniqueId
    )
    : base ($projectCode, $regionCode, $environment, $uniqueId)
    {
        $this.KeyVaultType = $keyVaultType
        $this.Name = "$($this.GetNameWithDashes())-kv-$($this.UniqueId)"
    }
}

class AzAppInsights : AzResource
{    
    AzAppInsights (
        [string]$projectCode, [AzRegionCode]$regionCode, [Environment]$environment, [string]$uniqueId
    )
    : base ($projectCode, $regionCode, $environment, $uniqueId)
    {        
        $this.Name = "$($this.GetNameWithDashes())-ai-$($this.UniqueId)"
    }    
}

class AzTrafficManager : AzResource
{    
    AzTrafficManager (
        [string]$projectCode, [AzRegionCode]$regionCode, [Environment]$environment, [string]$uniqueId
    )
    : base ($projectCode, $regionCode, $environment, $uniqueId)
    {        
        $this.Name = "$($this.GetNameWithDashesNoRegion())-tm-$($this.UniqueId)"
    }    
}

class AzElasticPool : AzResource
{    
    AzElasticPool (
        [string]$projectCode, [AzRegionCode]$regionCode, [Environment]$environment, [string]$uniqueId
    )
    : base ($projectCode, $regionCode, $environment, $uniqueId)
    {        
        $this.Name = "$($this.GetNameWithDashesNoRegion())-dbpool"
    }    
}

class AzFailoverGroup : AzResource
{    
    AzFailoverGroup (
        [string]$projectCode, [AzRegionCode]$regionCode, [Environment]$environment, [string]$uniqueId
    )
    : base ($projectCode, $regionCode, $environment, $uniqueId)
    {        
        $this.Name = "$($this.GetNameWithDashesNoRegion())-dbfg"
    }    
}

class AzSqlServer : AzResource
{    
    AzSqlServer (
        [string]$projectCode, [AzRegionCode]$regionCode, [Environment]$environment, [string]$uniqueId
    )
    : base ($projectCode, $regionCode, $environment, $uniqueId)
    {        
        $this.Name = "$($this.GetNameWithDashes())-sql-$($this.UniqueId)"
    }    
}