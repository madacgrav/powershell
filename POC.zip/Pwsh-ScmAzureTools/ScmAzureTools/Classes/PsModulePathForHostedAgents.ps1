class PsModulePathForHostedAgents
{
    static [string] GetLatestModule ([string]$patternToMatch, [string]$patternToExtract)
    {
        $resultFolder = ''
        $regexToMatch = New-Object -TypeName System.Text.RegularExpressions.Regex -ArgumentList $patternToMatch
        $regexToExtract = New-Object -TypeName System.Text.RegularExpressions.Regex -ArgumentList $patternToExtract
        $maxVersion = [version]'0.0.0'

        try
        {
            $moduleFolders = Get-ChildItem -Directory -Path $($env:SystemDrive + '\Modules') | Where-Object { $regexToMatch.IsMatch($_.Name) }
            
            foreach ($moduleFolder in $moduleFolders)
            {
                $moduleVersion = [version]$($regexToExtract.Match($moduleFolder.Name).Groups[0].Value)

                if ($moduleVersion -gt $maxVersion)
                {
                    $modulePath = [System.IO.Path]::Combine($moduleFolder.FullName, "Az\$moduleVersion\Az.psm1")

                    if (Test-Path -LiteralPath $modulePath -PathType Leaf)
                    {
                        $maxVersion = $moduleVersion
                        $resultFolder = $moduleFolder.FullName
                    }
                    else
                    {
                        Write-Verbose "A folder matching the module folder pattern was found at $($moduleFolder.FullName) but didn't contain a valid module file"
                    }
                }
            }
        }
        catch
        {
            Write-Verbose "Attempting to find the Latest Module Folder failed with the error: $($_.Exception.Message)"
            $resultFolder = ''
        }
        
        Write-Verbose "Latest module folder detected: $resultFolder"
        return $resultFolder
    }

    static [void] CleanPsModulePath ()
    {
        $azureRmModulePath = 'C:\Modules\azurerm_2.1.0'
        $azureModulePath = 'C:\Modules\azure_2.1.0'
        $azPsModulePath = $env:PSModulePath

        if ($azPsModulePath.split(";") -contains $azureRmModulePath)
        {
            $azPsModulePath = (($azPsModulePath).Split(';') | Where-Object { $_ -ne $azureRmModulePath }) -join ';'
            Write-Verbose "$azureRmModulePath removed. Restart the prompt for the changes to take effect."
        }
        else
        {
            Write-Verbose "$azureRmModulePath is not present in $azPsModulePath"
        }

        if ($azPsModulePath.split(";") -contains $azureModulePath)
        {
            $azPsModulePath = (($azPsModulePath).Split(';') | Where-Object { $_ -ne $azureModulePath }) -join ';'
            Write-Verbose "$azureModulePath removed. Restart the prompt for the changes to take effect."
        }
        else
        {
            Write-Verbose "$azureModulePath is not present in $azPsModulePath"
        }

        $env:PSModulePath = $azPsModulePath
    }

    static [void] UpdatePsModulePath ()
    {
        try
        {
            [PsModulePathForHostedAgents]::CleanPsModulePath()

            $hostedAgentAzModulePath = [PsModulePathForHostedAgents]::GetLatestModule("^az_[0-9]+\.[0-9]+\.[0-9]+$", "[0-9]+\.[0-9]+\.[0-9]+$")
            
            $env:PSModulePath = $hostedAgentAzModulePath + ";" + $env:PSModulePath
            $env:PSModulePath = $env:PSModulePath.TrimStart(';') 
        }
        finally
        {
            Write-Verbose "The updated value of the PSModulePath is: $($env:PSModulePath)"
        }
    }
}