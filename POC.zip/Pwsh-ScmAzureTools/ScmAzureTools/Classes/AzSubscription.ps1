class AzSubscription 
{
    static [void] ClearContext ([string]$errorAction)
    {
        Write-Host "##[command]Clear-AzContext -Scope Process -ErrorAction $errorAction"
        [void](Clear-AzContext -Scope Process -ErrorAction $errorAction)

        Write-Host "##[command]Clear-AzContext -Scope CurrentUser -Force -ErrorAction $errorAction"
        [void](Clear-AzContext -Scope CurrentUser -Force -ErrorAction $errorAction)
    }

    static [void] Connect ([psobject]$endpoint, [string]$errorAction)
    {
        Write-Output "##[command]Disable-AzContextAutosave -ErrorAction $errorAction"
        Disable-AzContextAutosave -ErrorAction $errorAction

        [AzSubscription]::ClearContext($errorAction)

        $environmentName = 'AzureCloud'

        $spnKey = ConvertTo-SecureString $endpoint.Auth.Parameters.ServicePrincipalKey -AsPlainText -Force
        $credentials = New-Object System.Management.Automation.PSCredential($endpoint.Auth.Parameters.ServicePrincipalId, $spnKey)

        Write-Host "##[command]Connect-AzAccount -ServicePrincipal -Tenant $($endpoint.Auth.Parameters.TenantId) -Credential $credentials -Environment $environmentName"        
        $splatConnectAzAccount = @{
            ServicePrincipal = $true
            Tenant           = $endpoint.Auth.Parameters.TenantId
            Credential       = $credentials
            Environment      = $environmentName
            ErrorAction      = $errorAction
        }
        [void](Connect-AzAccount @splatConnectAzAccount)
        
        Write-Host "##[command] Set-AzContext -SubscriptionId $endpoint.Data.SubscriptionId -Tenant $endpoint.Auth.Parameters.TenantId"
        [void](Set-AzContext -SubscriptionId $endpoint.Data.SubscriptionId -Tenant $endpoint.Auth.Parameters.TenantId)
    }

    static [void] Disconnect ([string]$errorAction)
    {
        Write-Host "##[command]Disconnect-AzAccount -Scope Process -ErrorAction $errorAction"	
        [void](Disconnect-AzAccount -Scope Process -ErrorAction $errorAction)

        [AzSubscription]::ClearContext($errorAction)
    }

    static [string] GetOmsWorkspaceId ([string]$subscriptionName)
    {
        $omsLookupTable = @{
            'US_ADVISORY_PREPROD'                   = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourcegroups/US_ADVISORY_PREPROD/providers/Microsoft.OperationalInsights/workspaces/US-ADVISORY-PREPROD-OMS'
            'US_ADVISORY_PROD'                      = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourcegroups/US_ADVISORY_PROD/providers/Microsoft.OperationalInsights/workspaces/US-ADVISORY-PROD-OMS'

            'US_CONSULTING_PREPROD'                 = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourcegroups/US_CONSULTING_PREPROD/providers/Microsoft.OperationalInsights/workspaces/US-CONSULTING-PREPROD-OMS'
            'US_CONSULTING_PROD'                    = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourcegroups/US_CONSULTING_PROD/providers/Microsoft.OperationalInsights/workspaces/US-CONSULTING-PROD-OMS'
            
            'US-ENABLINGAREAS-PREPROD'              = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourcegroups/US-ENABLINGAREAS-PREPROD/providers/Microsoft.OperationalInsights/workspaces/US-ENABLINGAREAS-PREPROD-OMS'
            'US-ENABLINGAREAS-PROD'                 = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourcegroups/US-ENABLINGAREAS-PROD/providers/Microsoft.OperationalInsights/workspaces/US-ENABLINGAREAS-PROD-OMS'
            
            'US_TAX_PREPROD'                        = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourcegroups/US_TAX_PREPROD/providers/Microsoft.OperationalInsights/workspaces/US-TAX-PREPROD-OMS'
            'US_TAX_PROD'                           = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourcegroups/US_TAX_PROD/providers/Microsoft.OperationalInsights/workspaces/US-TAX-PROD-OMS'

            'US-AZSUB-AME-ENA-DAS-HotelDigSvcs-NPD' = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourceGroups/US-ENABLINGAREAS-PREPROD/providers/Microsoft.OperationalInsights/workspaces/US-ENABLINGAREAS-PREPROD-OMS'
            'US-AZSUB-AME-ENA-DAS-HotelDigSvcs-PRD' = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourcegroups/US-ENABLINGAREAS-PROD/providers/Microsoft.OperationalInsights/workspaces/US-ENABLINGAREAS-PROD-OMS'

            'US-AZSUB-AME-ENA-DAS-LRR-NPD'          = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourceGroups/US-ENABLINGAREAS-PREPROD/providers/Microsoft.OperationalInsights/workspaces/US-ENABLINGAREAS-PREPROD-OMS'
            'US-AZSUB-AME-ENA-DAS-LRR-PRD'          = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourcegroups/US-ENABLINGAREAS-PROD/providers/Microsoft.OperationalInsights/workspaces/US-ENABLINGAREAS-PROD-OMS'

            'US-AZSUB-AME-ENA-DAS-MCE-NPD'          = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourceGroups/US-ENABLINGAREAS-PREPROD/providers/Microsoft.OperationalInsights/workspaces/US-ENABLINGAREAS-PREPROD-OMS'
            'US-AZSUB-AME-ENA-DAS-MCE-PRD'          = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourcegroups/US-ENABLINGAREAS-PROD/providers/Microsoft.OperationalInsights/workspaces/US-ENABLINGAREAS-PROD-OMS'

            'US-AZSUB-AME-ENA-DAS-MOBILE-NPD'       = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourceGroups/US-ENABLINGAREAS-PREPROD/providers/Microsoft.OperationalInsights/workspaces/US-ENABLINGAREAS-PREPROD-OMS'
            'US-AZSUB-AME-ENA-DAS-MOBILE-PRD'       = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourcegroups/US-ENABLINGAREAS-PROD/providers/Microsoft.OperationalInsights/workspaces/US-ENABLINGAREAS-PROD-OMS'

            'US-AZSUB-AME-ENA-DAS-SCM-NPD'          = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourceGroups/US-ENABLINGAREAS-PREPROD/providers/Microsoft.OperationalInsights/workspaces/US-ENABLINGAREAS-PREPROD-OMS'
            'US-AZSUB-AME-ENA-DAS-SCM-PRD'          = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourcegroups/US-ENABLINGAREAS-PROD/providers/Microsoft.OperationalInsights/workspaces/US-ENABLINGAREAS-PROD-OMS'

            'US-AZSUB-AME-ENA-DAS-USAPARENT-NPD'    = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourceGroups/US-ENABLINGAREAS-PREPROD/providers/Microsoft.OperationalInsights/workspaces/US-ENABLINGAREAS-PREPROD-OMS'
            'US-AZSUB-AME-ENA-DAS-USAPARENT-PRD'    = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourcegroups/US-ENABLINGAREAS-PROD/providers/Microsoft.OperationalInsights/workspaces/US-ENABLINGAREAS-PROD-OMS'

            'US-AZSUB-AME-ENA-TODINNOV-NPD'         = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourceGroups/US-ENABLINGAREAS-PREPROD/providers/Microsoft.OperationalInsights/workspaces/US-ENABLINGAREAS-PREPROD-OMS'
            'US-AZSUB-AME-ENA-TODINNOV-PRD'         = '/subscriptions/0c660c62-0a87-47e9-90e1-6eb078055ff5/resourcegroups/US-ENABLINGAREAS-PROD/providers/Microsoft.OperationalInsights/workspaces/US-ENABLINGAREAS-PROD-OMS'
        }

        return $omsLookupTable[$subscriptionName]
    }
}