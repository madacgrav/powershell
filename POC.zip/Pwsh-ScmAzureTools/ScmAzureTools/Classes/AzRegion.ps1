class AzRegion
{
    static [string] GetAzRegionCode ([string]$region)
    {
        $regionLookupTable = @{                        
            'East US'             = [AzRegionCode]::eus
            'East US 2'           = [AzRegionCode]::eus2
            'West US'             = [AzRegionCode]::wus
            'West US 2'           = [AzRegionCode]::wus2
            'Central US'          = [AzRegionCode]::usc
            'North Central US'    = [AzRegionCode]::usnc
            'South Central US'    = [AzRegionCode]::ussc
            'West Central US'     = [AzRegionCode]::uswc
            'Canada Central'      = [AzRegionCode]::cac
            'Canada East'         = [AzRegionCode]::cae
            'Brazil South'        = [AzRegionCode]::brs
            'Southeast Asia'      = [AzRegionCode]::asse
            'East Asia'           = [AzRegionCode]::ase
            'Australia Central'   = [AzRegionCode]::ausc
            'Australia East'      = [AzRegionCode]::ause
            'Australia Southeast' = [AzRegionCode]::auss
            'North Europe'        = [AzRegionCode]::neu
            'West Europe'         = [AzRegionCode]::weu
            'Japan East'          = [AzRegionCode]::jpe
            'Japan West'          = [AzRegionCode]::jpw
            'Korea South'         = [AzRegionCode]::krs
            'Korea Central'       = [AzRegionCode]::krc
            'Central India'       = [AzRegionCode]::inc
            'South India'         = [AzRegionCode]::ins
            'West India'          = [AzRegionCode]::inw
            'UK South'            = [AzRegionCode]::uks
            'UK West'             = [AzRegionCode]::ukw
            'France Central'      = [AzRegionCode]::frc
            'South Africa North'  = [AzRegionCode]::zan
            'UAE North'           = [AzRegionCode]::uaen
        }

        return $regionLookupTable[$region]
    }
}