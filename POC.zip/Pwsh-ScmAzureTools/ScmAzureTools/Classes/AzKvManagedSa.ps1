class AzKvManagedSa
{
    [string]$StorageAccountName

    [string]$ResourceGroupName

    [string]$KeyVaultName

    [int]$RegenerationPeriodDays = 1

    [string]$StorageAccountKey = 'key2'

    hidden [timespan]$RegenerationPeriod

    AzKvManagedSa ([string]$storageAccountName, [string]$resourceGroupName, [string]$keyVaultName)
    {
        $this.StorageAccountName = $storageAccountName
        $this.ResourceGroupName = $resourceGroupName
        $this.KeyVaultName = $keyVaultName
        $this.RegenerationPeriod = (New-TimeSpan -Days $this.RegenerationPeriodDays)
    }

    AzKvManagedSa ([string]$storageAccountName, [string]$resourceGroupName, [string]$keyVaultName,
        [string]$storageAccountKey, [int]$regenerationPeriodDays)
    {
        $this.StorageAccountName = $storageAccountName
        $this.ResourceGroupName = $resourceGroupName
        $this.KeyVaultName = $keyVaultName
        $this.StorageAccountKey = $storageAccountKey
        $this.RegenerationPeriodDays = $regenerationPeriodDays
        $this.RegenerationPeriod = (New-TimeSpan -Days $this.RegenerationPeriodDays)
    }

    [psobject] Get ([string]$errorAction)
    {
        Write-Verbose "Getting Azure KeyVault Managed Storage Account: $($this.SasDefinitionName)"
        $splatGetAzKvManagedSa = @{
            VaultName   = $this.KeyVaultName
            AccountName = $this.StorageAccountName
            ErrorAction = $errorAction
        }
        $kvManagedSa = Get-AzureKeyVaultManagedStorageAccount @splatGetAzKvManagedSa

        return $kvManagedSa
    }

    [void] Add ($errorAction)
    {
        $storageAccountId = (Get-AzureRmStorageAccount -Name $this.StorageAccountName -ResourceGroupName $this.ResourceGroupName -ErrorAction $errorAction).Id

        Write-Verbose "Creating Azure KeyVault managed storage account: $($this.StorageAccountName)"
        $splatAddAzKvManagedSa = @{
            VaultName          = $this.KeyVaultName
            AccountResourceId  = $storageAccountId
            AccountName        = $this.StorageAccountName
            ActiveKeyName      = $this.StorageAccountKey
            RegenerationPeriod = $this.RegenerationPeriod
            ErrorAction        = $errorAction
        }
        Add-AzureKeyVaultManagedStorageAccount @splatAddAzKvManagedSa
    }

    static [void] Add ([string]$storageAccountName, [string]$resourceGroupName, [string]$keyVaultName, [string]$errorAction)
    {
        $_azKvManagedSa = [AzKvManagedSa]::new($storageAccountName, $resourceGroupName, $keyVaultName)

        $_azKvManagedSa.Add($errorAction)
    }

    static [void] Add ([string]$storageAccountName, [string]$resourceGroupName, [string]$keyVaultName,
        [string]$storageAccountKey, [int]$regenerationPeriodDays, [string]$errorAction)
    {
        $_azKvManagedSa = [AzKvManagedSa]::new($storageAccountName, $resourceGroupName, $keyVaultName,
            $storageAccountKey, $regenerationPeriodDays)

        $_azKvManagedSa.Add($errorAction)
    }

    [void] Update ($errorAction)
    {
        Write-Verbose "Updating Azure KeyVault managed storage account: $($this.StorageAccountName)"
        $splatUpdateAzKvManagedSa = @{
            VaultName          = $this.KeyVaultName
            AccountName        = $this.StorageAccountName
            ActiveKeyName      = $this.StorageAccountKey
            RegenerationPeriod = $this.RegenerationPeriod
            ErrorAction        = $errorAction
        }
        Update-AzureKeyVaultManagedStorageAccount @splatUpdateAzKvManagedSa
    }

    static [void] Update ([string]$storageAccountName, [string]$resourceGroupName, [string]$keyVaultName, [string]$errorAction)
    {
        $_azKvManagedSa = [AzKvManagedSa]::new($storageAccountName, $resourceGroupName, $keyVaultName)

        $_azKvManagedSa.Update($errorAction)
    }

    static [void] Update ([string]$storageAccountName, [string]$resourceGroupName, [string]$keyVaultName,
        [string]$storageAccountKey, [int]$regenerationPeriodDays, [string]$errorAction)
    {
        $_azKvManagedSa = [AzKvManagedSa]::new($storageAccountName, $resourceGroupName, $keyVaultName,
            $storageAccountKey, $regenerationPeriodDays)

        $_azKvManagedSa.Update($errorAction)
    }

    [void] Remove ($errorAction)
    {
        Write-Verbose "Removing Azure KeyVault managed storage account: $($this.StorageAccountName)"
        $splatUpdateAzKvManagedSa = @{
            VaultName   = $this.KeyVaultName
            AccountName = $this.StorageAccountName
            ErrorAction = $errorAction
        }
        Remove-AzureKeyVaultManagedStorageAccount @splatUpdateAzKvManagedSa
    }

    static [void] Remove ([string]$storageAccountName, [string]$resourceGroupName, [string]$keyVaultName, [string]$errorAction)
    {
        $_azKvManagedSa = [AzKvManagedSa]::new($storageAccountName, $resourceGroupName, $keyVaultName)

        $_azKvManagedSa.Remove($errorAction)
    }
}

