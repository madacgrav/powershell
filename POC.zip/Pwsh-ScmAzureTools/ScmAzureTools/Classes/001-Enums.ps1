enum Environment
{
    dev
    qas
    loa
    stg
    prd
    bcp
}

enum AzResourceType
{
    AzAppService
    AzAppServicePlan
    AzAppServiceEnvironment
    AzDatabase
    AzStorageAccount
    AzKeyVault
    AzAppInsights
    AzTrafficManager
    AzElasticPool
    AzFailoverGroup
    AzSqlServer
}

enum AppServiceType
{
    Web
    Job
    Fnc
}

enum KeyVaultType
{
    KvConfig
    KvSecret
    KvShared
}

enum AzRegionCode
{
    eus
    eus2
    wus
    wus2
    usc
    usnc
    ussc
    uswc
    cac
    cae
    brs
    asse
    ase
    ausc
    ause
    auss
    neu
    weu
    jpe
    jpw
    krs
    krc
    inc
    ins
    inw
    uks
    ukw
    frc
    zan
    uaen
}
