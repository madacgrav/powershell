class AzKvManagedSaSasDef
{
    [string]$StorageAccountName    

    [string]$KeyVaultName

    [string]$SasDefinitionName

    [ValidateSet('Blob', 'File', 'Queue', 'Table')]
    [string[]]$StorageAccountService

    [ValidateSet('Service', 'Container', 'Object')]
    [string[]]$StorageAccountResourceType

    [ValidateSet('Add', 'Create', 'Delete', 'List', 'Process', 'Read', 'Query', 'Update', 'Write')]
    [string[]]$SasPermissions

    [int]$RegenerationPeriodDays = 1    
    
    hidden [timespan]$RegenerationPeriod

    AzKvManagedSaSasDef ([string]$saName, [string]$kvName, [string]$sasDefName)
    {
        $this.StorageAccountName = $saName
        $this.KeyVaultName = $kvName
        $this.SasDefinitionName = $sasDefName
    }

    AzKvManagedSaSasDef ([string]$saName, [string]$kvName, [string]$sasDefName, [string[]]$saService,
        [string[]]$saResourceType, [string[]]$sasPermissions, [string]$varSubstitueName)
    {
        $this.StorageAccountName = $saName
        $this.KeyVaultName = $kvName
        $this.SasDefinitionName = $sasDefName
        $this.StorageAccountService = $saService
        $this.StorageAccountResourceType = $saResourceType
        $this.SasPermissions = $sasPermissions        
        $this.RegenerationPeriod = (New-TimeSpan -Days $this.RegenerationPeriodDays)
    }

    AzKvManagedSaSasDef ([string]$saName, [string]$kvName, [string]$sasDefName, [string[]]$saService,
        [string[]]$saResourceType, [string[]]$sasPermissions, [string]$varSubstitueName, [int]$regenerationPeriodDays)
    {
        $this.StorageAccountName = $saName
        $this.KeyVaultName = $kvName
        $this.SasDefinitionName = $sasDefName
        $this.StorageAccountService = $saService
        $this.StorageAccountResourceType = $saResourceType
        $this.SasPermissions = $sasPermissions        
        $this.RegenerationPeriodDays = $regenerationPeriodDays
        $this.RegenerationPeriod = (New-TimeSpan -Days $this.RegenerationPeriodDays)
    }

    [psobject] Get ([string]$errorAction)
    {
        Write-Verbose "Getting Azure KeyVault Managed SAS Defintion Key: $($this.SasDefinitionName)"
        $splatGetAzKvManagedSaSasDef = @{
            VaultName   = $this.KeyVaultName
            AccountName = $this.StorageAccountName
            ErrorAction = $errorAction
        }
        $sasDefinition = @(Get-AzureKeyVaultManagedStorageSasDefinition @splatGetAzKvManagedSaSasDef).Where( { $_.Name -eq $this.SasDefinitionName })

        return $sasDefinition
    }

    static [psobject] Get ([string]$saName, [string]$kvName, [string]$sasDefName, [string]$errorAction)
    {
        $_sasDefinition = [AzKvManagedSaSasDef]::new($saName, $kvName, $sasDefName)

        return $_sasDefinition.Get($errorAction)
    }

    [psobject] Set ([string]$errorAction)
    {
        Write-Verbose "Creating Azure KeyVault Managed SAS Defintion Key: $($this.SasDefinitionName)"
        $splatSetAzKvManagedSaSasDef = @{
            Service        = $this.StorageAccountService
            ResourceType   = $this.StorageAccountResourceType
            VaultName      = $this.KeyVaultName
            AccountName    = $this.StorageAccountName
            Name           = $this.SasDefinitionName
            Protocol       = 'HttpsOnly'
            ValidityPeriod = $this.RegenerationPeriod
            Permission     = $this.SasPermissions
            ErrorAction    = $errorAction
        }
        $sasDefinition = Set-AzureKeyVaultManagedStorageSasDefinition @splatSetAzKvManagedSaSasDef

        return $sasDefinition
    }

    static [psobject] Set ([string]$saName, [string]$kvName, [string]$sasDefName, [string[]]$saService,
        [string[]]$saResourceType, [string[]]$sasPermissions, [string]$errorAction)
    {
        $_sasDefinition = [AzKvManagedSaSasDef]::new($saName, $kvName, $sasDefName, $saService,
            $saResourceType, $sasPermissions)

        return $_sasDefinition.Set($errorAction)
    }

    static [psobject] Set ([string]$saName, [string]$kvName, [string]$sasDefName, [string[]]$saService,
        [string[]]$saResourceType, [string[]]$sasPermissions, [int]$regenerationPeriodDays, [string]$errorAction)
    {
        $_sasDefinition = [AzKvManagedSaSasDef]::new($saName, $kvName, $sasDefName, $saService,
            $saResourceType, $sasPermissions, $regenerationPeriodDays)

        return $_sasDefinition.Set($errorAction)
    }

    [psobject] Remove ([string]$errorAction)
    {
        Write-Verbose "Removing Azure KeyVault Managed SAS Defintion Key: $($this.SasDefinitionName)"
        $splatRemoveAzKvManagedSaSasDef = @{
            VaultName   = $this.KeyVaultName
            AccountName = $this.StorageAccountName
            Name        = $this.SasDefinitionName
            ErrorAction = $errorAction
        }
        $sasDefinition = Remove-AzureKeyVaultManagedStorageSasDefinition @splatRemoveAzKvManagedSaSasDef

        return $sasDefinition
    }

    static [string] GetSasTokenForAdo ([string]$vaultName, [string]$secretName)
    {        
        if (-not $env:ADO_SASTOKEN)
        {
            $sasToken = Get-AzKeyVaultSecret -VaultName $vaultName -Name $secretName
            Write-Host "Creating new secret variable: ado.SasToken"
            Write-Host "##vso[task.setvariable variable=ado.SasToken;issecret=true]$($sasToken.SecretValueText)"

            return $sasToken.SecretValueText
        }
        
        return $env:ADO_SASTOKEN
    }
}

