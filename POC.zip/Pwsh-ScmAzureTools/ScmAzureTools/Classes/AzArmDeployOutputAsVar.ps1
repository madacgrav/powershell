class AzArmDeployOutputAsVar
{
    [string[]]$ArmDeploymentOutput

    [string]$SubstituteVariableJsonConfigFile

    AzArmDeployOutputAsVar ([string[]]$armDeployOutput)
    {
        $this.ArmDeploymentOutput = $armDeployOutput
    }

    AzArmDeployOutputAsVar ([string[]]$armDeployOutput, [string]$jsonConfigFile)
    {
        Write-Verbose "Verifying $jsonConfigFile is a valid path."
        if (-not (Test-Path -Path $jsonConfigFile -PathType Leaf))
        {
            throw "$jsonConfigFile is not a valid path to a json file. Please provide a full path to the json file."
        }
        $this.ArmDeploymentOutput = $armDeployOutput
        $this.SubstituteVariableJsonConfigFile = $jsonConfigFile
    }

    [string[]] Add ($errorAction)
    {
        Write-Verbose 'Convert json output from ARM Template deployment to Azure DevOps variables.'
        $adoVariablesHashtable = @{}
        $adoVariablesStrings = New-Object -TypeName 'System.Collections.Generic.List[string]'

        foreach ($output in $this.ArmDeploymentOutput)
        {
            ($output | ConvertFrom-Json).psobject.Properties | ForEach-Object { $adoVariablesHashtable[$_.Name] = $_.Value.value }
        }

        foreach ($adoVariable in $adoVariablesHashtable.GetEnumerator())
        {
            $variableName = $adoVariable.Name
            $variableValue = $adoVariable.Value

            Write-Verbose "Creating new variable: $variableName $variableValue"
            [void]$adoVariablesStrings.Add("Creating new variable: $variableName $variableValue")
            [void]$adoVariablesStrings.Add("##vso[task.setvariable variable=$variableName;]$variableValue")
        }

        if ($this.SubstituteVariableJsonConfigFile)
        {
            Write-Verbose 'Subtitute Azure DevOps variables with output values from ARM template deployment'
            $substituteVariableJsonConfig = Get-Content -Path $this.SubstituteVariableJsonConfigFile -ErrorAction $errorAction

            $variablesToSubstitue = ($substituteVariableJsonConfig | ConvertFrom-Json).psobject.Properties

            foreach ($varToSub in $variablesToSubstitue)
            {
                $substituteVariableName = $varToSub.Value.substituteVariable
                $substituteVariableValue = $adoVariablesHashtable[$varToSub.Value.armOutputVariable]

                Write-Verbose "Creating new variable: $substitutevariableName $substitutevariableValue"
                [void]$adoVariablesStrings.Add("Creating new variable: $substitutevariableName $substitutevariableValue")
                [void]$adoVariablesStrings.Add("##vso[task.setvariable variable=$substitutevariableName;]$substitutevariableValue")
            }
        }

        return $adoVariablesStrings
    }

    static [string[]] Add ([string[]]$armDeployOutput, [string]$errorAction)
    {
        $_armDeploymentObject = [AzArmDeployOutputAsVar]::new($armDeployOutput)

        return $_armDeploymentObject.Add($errorAction)
    }

    static [string[]] Add ([string[]]$armDeployOutput, [string]$jsonConfigFile, [string]$errorAction)
    {
        $_armDeploymentObject = [AzArmDeployOutputAsVar]::new($armDeployOutput, $jsonConfigFile)

        return $_armDeploymentObject.Add($errorAction)
    }
}