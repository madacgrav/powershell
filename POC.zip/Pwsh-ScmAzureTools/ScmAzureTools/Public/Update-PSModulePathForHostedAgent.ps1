function Update-PSModulePathForHostedAgent
{
    <#
    .Synopsis
        
    .DESCRIPTION
        
    .EXAMPLE
        
    #>
    [CmdletBinding()]
    param
    ()
    begin
    {
    }
    process
    {
        [PsModulePathForHostedAgents]::UpdatePsModulePath()
    }
    end
    {
    }    
}