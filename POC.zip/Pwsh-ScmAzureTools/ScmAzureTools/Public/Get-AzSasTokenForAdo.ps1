function Get-AzSasTokenForAdo
{
    <#
    .Synopsis
        
    .DESCRIPTION
        
    .EXAMPLE
        
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param
    (
        # Azure KeyVault
        [Parameter(
            Mandatory,
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
        )]
        [string]$VaultName,
        
        # Azure KeyVault Secret Name
        [Parameter(
            Mandatory,
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
        )]
        [string]$SecretName
    )
    begin
    {
    }
    process
    {
        [AzKvManagedSaSasDef]::GetSasTokenForAdo($VaultName, $SecretName)
    }
    end
    {
    }
}