function Get-AzOmsWorkspaceId
{
    <#
    .Synopsis
        Get Azure OMS Workspace ID that matches a Subscription name
    .DESCRIPTION
        Use this function to get the Azure OMS Workspce ID for an Azure Subscription.
    .EXAMPLE
        Get-AzOmsWorkspaceId -SubscriptionName 'Azure_Subscription'

        Description
        -----------
        Get OMS Workspace ID for subscription "Azure_Subscription."
        If there is a matching OMS Workspace ID for "Azure_Subscription," the ID is returned
        to the pipeline as a string.    
    .Parameter SubscriptionName
        Azure Subscription Name
    .INPUTS
        String
    .OUTPUTS
        String
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param
    (
        # Azure Subscription Name
        [Parameter(
            Mandatory,
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
        )]
        [string]$SubscriptionName
    )
    begin
    {
    }
    process
    {
        [AzSubscription]::GetOmsWorkspaceId($SubscriptionName)
    }
    end
    {
    }
}
