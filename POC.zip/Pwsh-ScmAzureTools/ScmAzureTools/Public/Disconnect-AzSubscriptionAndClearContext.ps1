function Disconnect-AzSubscriptionAndClearContext
{
    <#
    .Synopsis
        
    .DESCRIPTION
        
    .EXAMPLE
        
    #>
    [CmdletBinding()]
    param
    ()
    begin
    {
    }
    process
    {
        $errorAction = $ErrorActionPreference
        if ($PSBoundParameters['ErrorAction'])
        {
            $errorAction = $PSBoundParameters['ErrorAction']
        }

        [AzSubscription]::Disconnect($errorAction)        
    }
    end
    {
    }
}
