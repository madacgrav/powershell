function Get-ScmAzKvManagedSaSasDef
{
    <#
    .Synopsis
        
    .DESCRIPTION
        
    .EXAMPLE
        
    #>
    [CmdletBinding()]
    [OutputType([psobject])]
    param
    (
        # Azure Storage Account Name
        [Parameter(Mandatory)]
        [string]$StorageAccountName,

        # Azure Key Vault Name
        # Project specific
        [Parameter(Mandatory)]
        [string]$KeyVaultName,

        # Sas Definition Name
        [Parameter(Mandatory)]
        [string]$SasDefinitionName
    )
    begin
    {
    }
    process
    {                
        $errorAction = $ErrorActionPreference
        if ($PSBoundParameters['ErrorAction'])
        {
            $errorAction = $PSBoundParameters['ErrorAction']
        }

        $sasDefinition = [AzKvManagedSaSasDef]::new($StorageAccountName, $KeyVaultName, $SasDefinitionName)

        $sasDefinition.Get($errorAction)                
    }
    end
    {
    }
}
