function New-AzResourceName
{
    <#
    .Synopsis
        
    .DESCRIPTION
        
    .EXAMPLE
        
    #>
    [CmdletBinding()]    
    param
    (
        # Azure Resource Type
        [Parameter(
            Mandatory,
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
        )]
        [AzResourceType]$AzResourceType,
        
        # Project Code
        [Parameter(
            Mandatory,
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
        )]
        [string]$ProjectCode,
        
        # Azure Region Code
        [Parameter(
            Mandatory,
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
        )]
        [AzRegionCode]$AzRegionCode,
        
        # Environment
        [Parameter(
            Mandatory,
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
        )]
        [Environment]$Environment,

        # Resource Unique Id
        [Parameter(
            Mandatory,
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
        )]
        [ValidateNotNullOrEmpty()]
        [string]$UniqueId
    )

    DynamicParam
    {                
        if ($AzResourceType -eq 'AzAppService' -or $AzResourceType -eq 'AzKeyVault')
        {            
            # Create the collection of attributes
            $attributeCollection = New-Object System.Collections.ObjectModel.Collection[System.Attribute]
            # Create and set the parameters' attributes
            $paramAttribute = New-Object System.Management.Automation.ParameterAttribute
            $paramAttribute.Mandatory = $true
            $paramAttribute.ValueFromPipeline = $true
            $paramAttribute.ValueFromPipelineByPropertyName = $true
            # Add the attributes to the attributes collection
            $attributeCollection.Add($paramAttribute)            

            if ($AzResourceType -eq 'AzAppService')
            {
                $paramName = 'AppServiceType'                
                $runtimeParameter = New-Object System.Management.Automation.RuntimeDefinedParameter($paramName, [AppServiceType], $attributeCollection)
            }

            if ($AzResourceType -eq 'AzKeyVault')
            {            
                $paramName = 'KeyVaultType'
                $runtimeParameter = New-Object System.Management.Automation.RuntimeDefinedParameter($paramName, [KeyVaultType], $attributeCollection)
            }

            # Create the dictionary
            $runtimeParameterDictionary = New-Object System.Management.Automation.RuntimeDefinedParameterDictionary            
            # Create and return the dynamic parameter
            $runtimeParameterDictionary.Add($paramName, $runtimeParameter)

            return $runtimeParameterDictionary
        }
    }
    begin
    {
    }
    process
    {
        $splatNewObject = @{
            TypeName     = $PSBoundParameters['AzResourceType']
            ArgumentList = $PSBoundParameters['ProjectCode'], $PSBoundParameters['AzRegionCode'], $PSBoundParameters['Environment'], $PSBoundParameters['UniqueId']
        }
        
        if ($paramName)
        {
            $splatNewObject['ArgumentList'] = $PSBoundParameters['ProjectCode'], $PSBoundParameters['AzRegionCode'], $PSBoundParameters[$paramName], $PSBoundParameters['Environment'], $PSBoundParameters['UniqueId']
        }
        
        New-Object @splatNewObject
    }
    end
    {
    }
}
