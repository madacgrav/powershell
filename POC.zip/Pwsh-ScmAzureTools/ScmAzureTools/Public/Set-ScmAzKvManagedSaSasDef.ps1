function Set-ScmAzKvManagedSaSasDef
{
    <#
    .Synopsis
        
    .DESCRIPTION
        
    .EXAMPLE
        
    #>
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'Low')]
    [OutputType([psobject])]
    param
    (
        # Azure Storage Account Name
        [Parameter(Mandatory)]
        [string]$StorageAccountName,

        # Azure Key Vault Name
        # Project specific
        [Parameter(Mandatory)]
        [string]$KeyVaultName,

        # Sas Definition Name
        [Parameter(Mandatory)]
        [string]$SasDefinitionName,

        # Storage Account Service
        [Parameter(Mandatory)]
        [ValidateSet('Blob', 'File', 'Queue', 'Table')]
        [string[]]$StorageAccountService,

        # Storage Account Resource Type
        [Parameter(Mandatory)]
        [ValidateSet('Service', 'Container', 'Object')]
        [string[]]$StorageAccountResourceType,

        # Sas Permissions
        [Parameter(Mandatory)]
        [ValidateSet('Add', 'Create', 'Delete', 'List', 'Process', 'Read', 'Query', 'Update', 'Write')]
        [string[]]$SasPermissions,

        # Key Regeneration Period
        [Parameter()]
        [int]$RegenerationPeriodDays = 1
    )
    begin
    {
    }
    process
    {        
        if ($PSCmdlet.ShouldProcess(""))
        {
            $errorAction = $ErrorActionPreference
            if ($PSBoundParameters['ErrorAction'])
            {
                $errorAction = $PSBoundParameters['ErrorAction']
            }

            $sasDefinition = [AzKvManagedSaSasDef]::new($StorageAccountName, $KeyVaultName, $SasDefinitionName, $StorageAccountService,
                $StorageAccountResourceType, $SasPermissions, $VariableSubstituteName, $RegenerationPeriodDays)            

            $sasDefinition.Set($errorAction)
        }        
    }
    end
    {
    }
}
