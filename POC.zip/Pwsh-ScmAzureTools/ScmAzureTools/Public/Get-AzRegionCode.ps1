function Get-AzRegionCode
{
    <#
    .Synopsis
        
    .DESCRIPTION
        
    .EXAMPLE
        
    #>
    [CmdletBinding()]
    [OutputType([string])]
    param
    (
        # Azure Region
        [Parameter(
            Mandatory,
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
        )]
        [string]$AzureRegion
    )
    begin
    {
    }
    process
    {
        [AzRegion]::GetAzRegionCode($AzureRegion)
    }
    end
    {
    }
}
