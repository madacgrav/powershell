function Remove-ScmAzKvManagedSa
{
    <#
    .Synopsis
        Function to remove an Azure Key Vault managed storage account
    .DESCRIPTION
        Use this function to remove an Azure Key Vault managed storage account.
    .EXAMPLE
        $splatRemoveScmAzKvManagedSa = @{
            StorageAccountName = 'mystorageaccount'
            ResourceGroupName  = 'myresourcegroup'
            KeyVaultName       = 'mykeyvault'
        }
        Remove-ScmAzKvManagedSa @splatRemoveScmAzKvManagedSa

        Description
        -----------
        Remove an Azure Key Vault managed storage account for mystorageaccount in resource group
        myresourcegroup using mykeyvault to manage keys.
    #>
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'High')]
    param
    (
        # Azure Storage Account Name
        [Parameter(
            Mandatory,
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
        )]
        [string]$StorageAccountName,

        # Azure Resource Group Name
        [Parameter(
            Mandatory,
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
        )]
        [string]$ResourceGroupName,

        # Azure Key Vault Name
        # Project specific
        [Parameter(
            Mandatory,
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
        )]
        [string]$KeyVaultName
    )
    begin
    {
    }
    process
    {
        if ($PSCmdlet.ShouldProcess("Will remove Azure KeyVault managed storage account, Account Name: $StorageAccountName"))
        {
            $errorAction = $ErrorActionPreference
            if ($PSBoundParameters['ErrorAction'])
            {
                $errorAction = $PSBoundParameters['ErrorAction']
            }

            [AzKvManagedSa]::Remove($StorageAccountName, $ResourceGroupName, $KeyVaultName, $errorAction)
        }
    }
    end
    {
    }
}
