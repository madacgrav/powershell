function Update-ScmAzKvManagedSa
{
    <#
    .Synopsis
        Function to update an existing Azure Key Vault managed storage account
    .DESCRIPTION
        Use this function to update an existing Azure Key Vault managed storage account.
    .EXAMPLE
        $splatUpdateScmAzKvManagedSa = @{
            StorageAccountName     = 'mystorageaccount'
            ResourceGroupName      = 'myresourcegroup'
            KeyVaultName           = 'mykeyvault'
            RegenerationPeriodDays = '1'
            StorageAccountKey      = 'key1'
        }
        Update-ScmAzKvManagedSa @splatUpdateScmAzKvManagedSa

        Description
        -----------
        Update an Azure Key Vault managed storage account for mystorageaccount in resource group
        myresourcegroup using mykeyvault to manage keys. Regerate keys every 1 day using key1.
    #>
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'Low')]
    param
    (
        # Azure Storage Account Name
        [Parameter(
            Mandatory,
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
        )]
        [string]$StorageAccountName,

        # Azure Resource Group Name
        [Parameter(
            Mandatory,
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
        )]
        [string]$ResourceGroupName,

        # Azure Key Vault Name
        # Project specific
        [Parameter(
            Mandatory,
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
        )]
        [string]$KeyVaultName,

        # Key Regeneration Period
        [Parameter(
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
        )]
        [int]$RegenerationPeriodDays = 1,

        # Storage Account Key
        [Parameter(
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
        )]
        [string]$StorageAccountKey = 'key2'
    )
    begin
    {
    }
    process
    {
        if ($PSCmdlet.ShouldProcess("Will update Azure KeyVault managed storage account, Account Name: $StorageAccountName"))
        {
            $errorAction = $ErrorActionPreference
            if ($PSBoundParameters['ErrorAction'])
            {
                $errorAction = $PSBoundParameters['ErrorAction']
            }

            [AzKvManagedSa]::Update($StorageAccountName, $ResourceGroupName, $KeyVaultName, $StorageAccountKey,
                $RegenerationPeriodDays, $errorAction)
        }
    }
    end
    {
    }
}
