function Initialize-AzSubscription
{
    <#
    .Synopsis
        
    .DESCRIPTION
        
    .EXAMPLE
        
    #>
    [CmdletBinding()]
    param
    (
        # Azure DevOps Endpoint
        [Parameter(
            Mandatory,
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
        )]
        [psobject]$Endpoint
    )
    begin
    {
    }
    process
    {
        $errorAction = $ErrorActionPreference
        if ($PSBoundParameters['ErrorAction'])
        {
            $errorAction = $PSBoundParameters['ErrorAction']
        }

        [AzSubscription]::Connect($Endpoint, $errorAction)        
    }
    end
    {
    }
}
