function Import-AzModule
{
    <#
    .Synopsis
        
    .DESCRIPTION
        
    .EXAMPLE
        
    #>
    [CmdletBinding()]
    param
    (
        # Az Module Name
        [Parameter(
            Mandatory,
            ValueFromPipeline,
            ValueFromPipelineByPropertyName
        )]
        [string]$AzModuleName
    )
    begin
    {
    }
    process
    {
        foreach ($moduleName in $AzModuleName)
        {
            Write-Verbose "Attempting to find module '$moduleName' from the module path."

            $module = Get-Module -Name $moduleName -ListAvailable | Sort-Object Version -Descending | Select-Object -First 1

            if (-not $module) 
            {
                Write-Verbose "No module found with name: $moduleName"
                throw "No module found with name: $moduleName"
            }

            Write-Host "##[command]Import-Module -Name $($module.Path) -Global"
            $module = Import-Module -Name $module.Path -Global -PassThru -Force        
            Write-Verbose "Imported module version: $($module.Version)"
        }        
    }
    end
    {
    }    
}