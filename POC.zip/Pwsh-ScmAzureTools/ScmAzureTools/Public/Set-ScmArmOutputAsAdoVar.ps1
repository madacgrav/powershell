function Set-ScmArmOutputAsAdoVar
{
    <#
    .Synopsis
        Converts json output from ARM deployment to Azure DevOps pipeline variables
    .DESCRIPTION
        Use this function to convert json output from ARM deployment to Azure DevOps pipeline variables.
        Function must be run from within an Azure DevOps pipeline. Strings are written to the pipeline that
        ADO converts to variables that tasks can utilize.
    .EXAMPLE
        ```
        $json1Data = @"
        {
            "storageAccount1Name": {
                "type": "String",
                "value": "storageAccount1Name"
            },
            "storageContainer1Name": {
                "type": "String",
                "value": "storageContainer1Name"
            }
        }
        "@
        Set-ScmArmOutputAsAdoVar -DeploymentOutput $json1Data        

        Description
        -----------
        Outputs strings matching those below:  
        ##vso[task.setvariable variable=storageContainer1Name;]container1Name  
        ##vso[task.setvariable variable=storageAccount1Name;]storageAccount1Name
        ```
    #>
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'Low')]
    [OutputType([System.String[]])]
    param
    (
        # Arm Deployment Output
        [Parameter(Mandatory)]
        [string[]]$DeploymentOutput,

        # Substitute Variable Json Config File
        [Parameter()]
        [ValidateScript( {
                if (-not (Test-Path $_))
                {
                    throw "$_ is not a valid path to a json file. Please provide a full path to the json file."
                }
                return $true
            })]
        [string]$SubstituteVariableJsonConfigFile
    )
    begin
    {
    }
    process
    {
        foreach ($output in $DeploymentOutput)
        {
            if ($PSCmdlet.ShouldProcess("Add Azure DevOps variable to pipeline"))
            {
                $errorAction = $ErrorActionPreference
                if ($PSBoundParameters['ErrorAction'])
                {
                    $errorAction = $PSBoundParameters['ErrorAction']
                }

                if ($PSBoundParameters['SubstituteVariableJsonConfigFile'])
                {
                    [AzArmDeployOutputAsVar]::Add($output, $SubstituteVariableJsonConfigFile, $errorAction)
                    continue
                }

                [AzArmDeployOutputAsVar]::Add($output, $errorAction)
            }
        }
    }
    end
    {
    }
}
