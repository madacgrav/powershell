#  SCM Azure Tools - New-AzResourceName cmdlet

[[_TOC_]]

## Overview



## Contact Information

Please report a problem at to the US SCM Platform Mgmt, <usscmplatformmgmt@deloitte.com>, if you are facing any issues with making this task work.  You can also share feedback about the task like, what more functionality should be added to the task, what other tasks you would like to have, at the same place.




### FAQ

