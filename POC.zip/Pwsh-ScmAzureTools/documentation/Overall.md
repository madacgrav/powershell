#  Azure Resource Deployment

[[_TOC_]]

## Overview

The Azure Resource Deployment Tool is used to create and update resources in Azure via the Azure DevOps pipelines.

## Contact Information

Please report a problem at to the US SCM Platform Mgmt, <usscmplatformmgmt@deloitte.com>, if you are facing any issues with making this task work.  You can also share feedback about the task like, what more functionality should be added to the task, what other tasks you would like to have, at the same place.


## Available cmdlets

* **[New-AzResourceName](/New-AzResourceName)**

    SCM Azure Tools - New-AzResourceName is used to create a name for an Azure Resource following SCM Deloitte naming standards.



