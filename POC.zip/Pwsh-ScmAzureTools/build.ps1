
[CmdletBinding()]
param
(
    [Parameter()]    
    [string]$Task = 'Default'
)

$modules = @( 
    @{
        Name    = 'Pester'
        Version = '4.4.2'
    },
    @{
        Name    = 'psake'
        Version = '4.7.4'
    },
    @{
        Name    = 'PSScriptAnalyzer'
        Version = '1.17.1'
    }
)

Set-PSRepository -Name PSGallery -InstallationPolicy Trusted

foreach ($module in $modules) 
{
    if (-not (Get-InstalledModule -Name $module['Name'] -RequiredVersion $module['Version'] -ErrorAction SilentlyContinue)) 
    { 
        Install-Module -Name $module['Name'] -RequiredVersion $module['Version'] -Scope CurrentUser -SkipPublisherCheck -AllowClobber -Confirm:$false
        Import-module -Name $module['Name'] -RequiredVersion $module['Version']
    }
}

Invoke-PSake -buildFile "$PSScriptRoot\psake.ps1" -taskList $Task -Verbose:$VerbosePreference

if (-not $psake.build_success)
{
    throw "Build failed"
}

