
$projectRoot = Resolve-Path "$PSScriptRoot\.."
$moduleRoot = Split-Path (Resolve-Path "$projectRoot\*\*.psd1")
$moduleName = Split-Path $moduleRoot -Leaf

Get-Module -Name $moduleName -All | Remove-Module -Force
Import-Module (Join-Path $moduleRoot "$moduleName.psm1") -force

InModuleScope -ModuleName $moduleName {

    $sut = Split-Path $MyInvocation.MyCommand.ScriptBlock.File -Leaf
    $cmdletName = $sut.Split('.')[0]
    $cmdlet = Get-Command -Name $cmdletName

    Describe $cmdletName {

        Context "Testing $cmdletName Parameters" {

            It 'Should throw when mandatory parameters are not provided' {
                $cmdlet.Parameters.AzResourceType.Attributes.Mandatory | Should -Be $true
                $cmdlet.Parameters.ProjectCode.Attributes.Mandatory | Should -Be $true
                $cmdlet.Parameters.AzRegionCode.Attributes.Mandatory | Should -Be $true
                $cmdlet.Parameters.Environment.Attributes.Mandatory | Should -Be $true
                $cmdlet.Parameters.UniqueId.Attributes.Mandatory | Should -Be $true
            }
        }

        # Build hashtable to splat for AzResource name
        $splatNewAzResourceName = @{
            AzResourceType = ''
            ProjectCode    = 'ddi'
            AzRegionCode   = 'eus'
            Environment    = 'dev'
            UniqueId       = '01'
        }

        Context "Testing $cmdletName Basic Functionality" {

            It 'Should not throw when all Function parameters are provided' {
                # Change resource type in splat to AzAppInsights
                $splatNewAzResourceName['AzResourceType'] = 'AzAppInsights'

                { New-AzResourceName @splatNewAzResourceName } | Should -Not -Throw
            }
        }

        Context "Testing $cmdletName Output" {

            It 'Should return the correct name for AzAppInsights resource' {
                # Change resource type in splat to AzAppInsights
                $splatNewAzResourceName['AzResourceType'] = 'AzAppInsights'
                $resource = New-AzResourceName @splatNewAzResourceName
                $resource.Name | Should -MatchExactly 'dev-ddi-eus-ai-01'
            }

            It 'Should return the correct name for AzAppService resource' {
                # Change resource type in splat to AzAppService
                $splatNewAzResourceName['AzResourceType'] = 'AzAppService'
                # Add dynamic parameter to splat called AppServiceType
                # Valid values are Web, Job, Fnc
                $splatNewAzResourceName.Add('AppServiceType', 'Web')
                $resource = New-AzResourceName @splatNewAzResourceName
                $resource.Name | Should -MatchExactly 'dev-ddi-eus-web-01'

                $splatNewAzResourceName['AppServiceType'] = 'Job'
                $resource = New-AzResourceName @splatNewAzResourceName
                $resource.Name | Should -MatchExactly 'dev-ddi-eus-job-01'

                $splatNewAzResourceName['AppServiceType'] = 'Fnc'
                $resource = New-AzResourceName @splatNewAzResourceName
                $resource.Name | Should -MatchExactly 'dev-ddi-eus-fnc-01'

                $splatNewAzResourceName.Remove('AppServiceType')
            }

            It 'Should return the correct name for AzAppServicePlan resource' {
                $splatNewAzResourceName['AzResourceType'] = 'AzAppServicePlan'
                $resource = New-AzResourceName @splatNewAzResourceName
                $resource.Name | Should -MatchExactly 'dev-ddi-eus-asp-01'
            }

            It 'Should return the correct name for AzAppServiceEnvironment resource' {
                $splatNewAzResourceName['AzResourceType'] = 'AzAppServiceEnvironment'
                $resource = New-AzResourceName @splatNewAzResourceName
                $resource.Name | Should -MatchExactly 'dev-ddi-eus-ase-01'
            }

            It 'Should return the correct name for AzDatabase resource' {
                $splatNewAzResourceName['AzResourceType'] = 'AzDatabase'
                $resource = New-AzResourceName @splatNewAzResourceName
                $resource.Name | Should -MatchExactly 'dev-ddi-eus-db'
            }

            It 'Should return the correct name for AzStorageAccount resource' {
                $splatNewAzResourceName['AzResourceType'] = 'AzStorageAccount'
                $resource = New-AzResourceName @splatNewAzResourceName
                $resource.Name | Should -MatchExactly 'devddieussa01'
            }

            It 'Should return the correct name for AzKeyVault resource' {    
                $splatNewAzResourceName['AzResourceType'] = 'AzKeyVault'
                # Add dynamic parameter to splat called KeyVaultType
                # Valid values are KvConfig, KvSecret, KvShared
                $splatNewAzResourceName.Add('KeyVaultType', 'KvConfig')
                $splatNewAzResourceName['UniqueId'] = 'cfg01'
                $resource = New-AzResourceName @splatNewAzResourceName
                $resource.Name | Should -MatchExactly 'dev-ddi-eus-kv-cfg01'

                $splatNewAzResourceName['KeyVaultType'] = 'KvSecret'
                $splatNewAzResourceName['UniqueId'] = 'sec01'
                $resource = New-AzResourceName @splatNewAzResourceName
                $resource.Name | Should -MatchExactly 'dev-ddi-eus-kv-sec01'

                $splatNewAzResourceName['KeyVaultType'] = 'KvShared'
                $splatNewAzResourceName['UniqueId'] = 'sha01'
                $resource = New-AzResourceName @splatNewAzResourceName
                $resource.Name | Should -MatchExactly 'dev-ddi-eus-kv-sha01'

                $splatNewAzResourceName.Remove('KeyVaultType')
                $splatNewAzResourceName['UniqueId'] = '01'
            }

            It 'Should return the correct name for AzTrafficManager resource' {
                $splatNewAzResourceName['AzResourceType'] = 'AzTrafficManager'
                $resource = New-AzResourceName @splatNewAzResourceName
                $resource.Name | Should -MatchExactly 'dev-ddi-tm-01'
            }

            It 'Should return the correct name for AzElasticPool resource' {
                $splatNewAzResourceName['AzResourceType'] = 'AzElasticPool'
                $resource = New-AzResourceName @splatNewAzResourceName
                $resource.Name | Should -MatchExactly 'dev-ddi-dbpool'
            }

            It 'Should return the correct name for AzFailoverGroup resource' {
                $splatNewAzResourceName['AzResourceType'] = 'AzFailoverGroup'
                $resource = New-AzResourceName @splatNewAzResourceName
                $resource.Name | Should -MatchExactly 'dev-ddi-dbfg'
            }

            It 'Should return the correct name for AzSqlServer resource' {
                $splatNewAzResourceName['AzResourceType'] = 'AzSqlServer'
                $resource = New-AzResourceName @splatNewAzResourceName
                $resource.Name | Should -MatchExactly 'dev-ddi-eus-sql-01'
            }
        }
    }
}
