
$projectRoot = Resolve-Path "$PSScriptRoot\.."
$moduleRoot = Split-Path (Resolve-Path "$projectRoot\*\*.psd1")
$moduleName = Split-Path $moduleRoot -Leaf

Get-Module -Name $moduleName -All | Remove-Module -Force
Import-Module (Join-Path $moduleRoot "$moduleName.psm1") -force

InModuleScope -ModuleName $moduleName {

    $sut = Split-Path $MyInvocation.MyCommand.ScriptBlock.File -Leaf
    $cmdletName = $sut.Split('.')[0]
    $cmdlet = Get-Command -Name $cmdletName

    Describe 'Get-AzRegionCode' {                

        Context 'Testing Get-AzRegionCode Parameters' {                    
            
            It 'Should throw when mandatory parameters are not provided' {
                $cmdlet.Parameters.AzureRegion.Attributes.Mandatory | should be $true
            }
        }

        Context 'Testing Get-AzRegionCode Output' {
            
            $regions = 'East US', 'West US'
            
            It 'Should return correct region codes' {

                foreach ($region in $regions)
                {
                    $regionCode = Get-AzRegionCode -AzureRegion $region

                    if ($region -eq 'East US')
                    {
                        $regionCode | should be 'eus'
                    }
                    else
                    {
                        $regionCode | should be 'wus'
                    }
                }
            }
        }
    }
}
