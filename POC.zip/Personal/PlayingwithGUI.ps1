#Variables
$SubId = "bfc7eac2-0d08-4251-921e-5fe25ba65b98"
$VaultName = "enabling-kv-prod-eus"



function Create-DropDown () {
param (
    $ddltype, 
    [string[]]$ddlitems
)
    write-host $ddltype
    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
    $Form = New-Object System.Windows.Forms.Form
    $Form.width = 300
    $Form.height = 125
    $Form.Text = "Select a $ddltype"
    $form.StartPosition = 'CenterScreen'

    $DropDown = new-object System.Windows.Forms.ComboBox
    $DropDown.Location = new-object System.Drawing.Size(25,10)
    $DropDown.Size = new-object System.Drawing.Size(200,30)
    ForEach ($Item in $ddlitems) {
        $DropDown.Items.Add($Item)
    }
    $Form.Controls.Add($DropDown)

    $Button = new-object System.Windows.Forms.Button
    $Button.Location = new-object System.Drawing.Size(25,50)
    $Button.Size = new-object System.Drawing.Size(50,20)
    $Button.Text = "OK"
    $Button.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $form.AcceptButton = $Button
    $form.Controls.Add($Button)
    
    #$Form.Add_Shown({$Form.Activate()})
    $result = $form.ShowDialog()

    if ($result -eq [System.Windows.Forms.DialogResult]::OK)
    {
        $x = $DropDown.SelectedItem.ToString()
        $script:certificateName = $DropDown.SelectedItem.ToString()
    }
}

#$login= Login-AzureRmAccount -SubscriptionId $SubId -ErrorAction Stop
$value = "ValutName"
$vaultlist = [string[]](Get-AzureRMKeyVault | Select-Object -ExpandProperty VaultName)
Create-DropDown -ddltype $value -ddlitems $vaultlist
$pfxPassword = Read-Host -Prompt 'Provide a challenge password for the pfx'
$value = "Certificate"
$certlist = [string[]](Get-AzureKeyVaultCertificate -VaultName $vaultName | Select-Object -ExpandProperty Name)
Create-DropDown -ddltype $value -ddlitems $certlist
$kvSecret = Get-AzureKeyVaultSecret -VaultName $vaultName -Name $certificateName
$kvSecretBytes = [System.Convert]::FromBase64String($kvSecret.SecretValueText)
$certCollection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
$certCollection.Import($kvSecretBytes,$null,[System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)
$protectedCertificateBytes = $certCollection.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Pkcs12, $pfxPassword)

Add-Type -AssemblyName System.Windows.Forms
$saveFileDialog = New-Object System.Windows.Forms.SaveFileDialog -Property @{
    initialDirectory = [System.IO.Directory]::GetCurrentDirectory()
    FileName         = $certificateName
    Title            = "save $certificateName to disk"
    ShowHelp         = $True
    Filter           = 'pfx files (*.pfx)|*.pfx' # Specified file types
}
 
$result = $saveFileDialog.ShowDialog()

if ($result -eq "OK") {    
    Write-Host "Selected File and Location:"  -ForegroundColor Green  
    $SaveFileDialog.filename
    [System.IO.File]::WriteAllBytes($SaveFileDialog.filename, $protectedCertificateBytes)
                     
} 
else { 
    Write-Host "File Save Dialog Cancelled!" -ForegroundColor Yellow
    Clear-Variable pfxPassword, certificateName, kvSecret, kvSecretBytes, certCollection, protectedCertificateBytes, saveFileDialog, result
   break;
} 