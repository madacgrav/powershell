<# This form was created using POSHGUI.com  a free online gui designer for PowerShell
.NAME
    Untitled
#>

Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()

$CertificateManager              = New-Object system.Windows.Forms.Form
$CertificateManager.ClientSize   = '605,540'
$CertificateManager.text         = "Certificate Manager"
$CertificateManager.TopMost      = $false

$ComboBox1                       = New-Object system.Windows.Forms.ComboBox
$ComboBox1.text                  = "Certificate List"
$ComboBox1.width                 = 153
$ComboBox1.height                = 20
$ComboBox1.location              = New-Object System.Drawing.Point(416,155)
$ComboBox1.Font                  = 'Microsoft Sans Serif,10'

$tb_vaultname                    = New-Object system.Windows.Forms.TextBox
$tb_vaultname.multiline          = $false
$tb_vaultname.width              = 152
$tb_vaultname.height             = 20
$tb_vaultname.location           = New-Object System.Drawing.Point(200,192)
$tb_vaultname.Font               = 'Microsoft Sans Serif,10'

$tb_subname                      = New-Object system.Windows.Forms.TextBox
$tb_subname.multiline            = $false
$tb_subname.width                = 153
$tb_subname.height               = 20
$tb_subname.location             = New-Object System.Drawing.Point(199,153)
$tb_subname.Font                 = 'Microsoft Sans Serif,10'

$subname                         = New-Object system.Windows.Forms.Label
$subname.text                    = "Subscription Name"
$subname.AutoSize                = $true
$subname.width                   = 25
$subname.height                  = 10
$subname.location                = New-Object System.Drawing.Point(59,157)
$subname.Font                    = 'Microsoft Sans Serif,10'

$rb_createcsr                    = New-Object system.Windows.Forms.RadioButton
$rb_createcsr.text               = "Create CSR"
$rb_createcsr.AutoSize           = $true
$rb_createcsr.width              = 104
$rb_createcsr.height             = 20
$rb_createcsr.location           = New-Object System.Drawing.Point(52,27)
$rb_createcsr.Font               = 'Microsoft Sans Serif,10'

$rb_completecsr                  = New-Object system.Windows.Forms.RadioButton
$rb_completecsr.text             = "Complete CSR"
$rb_completecsr.AutoSize         = $true
$rb_completecsr.width            = 104
$rb_completecsr.height           = 20
$rb_completecsr.location         = New-Object System.Drawing.Point(234,29)
$rb_completecsr.Font             = 'Microsoft Sans Serif,10'

$rb_exportcert                   = New-Object system.Windows.Forms.RadioButton
$rb_exportcert.text              = "Export Certificate"
$rb_exportcert.AutoSize          = $true
$rb_exportcert.width             = 104
$rb_exportcert.height            = 20
$rb_exportcert.location          = New-Object System.Drawing.Point(423,29)
$rb_exportcert.Font              = 'Microsoft Sans Serif,10'

$Button1                         = New-Object system.Windows.Forms.Button
$Button1.text                    = "Close"
$Button1.width                   = 60
$Button1.height                  = 30
$Button1.location                = New-Object System.Drawing.Point(529,499)
$Button1.Font                    = 'Microsoft Sans Serif,10'

$Label1                          = New-Object system.Windows.Forms.Label
$Label1.text                     = "Vault Name"
$Label1.AutoSize                 = $true
$Label1.width                    = 25
$Label1.height                   = 10
$Label1.location                 = New-Object System.Drawing.Point(60,193)
$Label1.Font                     = 'Microsoft Sans Serif,10'

$Button2                         = New-Object system.Windows.Forms.Button
$Button2.text                    = "Download"
$Button2.width                   = 70
$Button2.height                  = 30
$Button2.location                = New-Object System.Drawing.Point(495,196)
$Button2.Font                    = 'Microsoft Sans Serif,10'

$Button3                         = New-Object system.Windows.Forms.Button
$Button3.text                    = "Load"
$Button3.width                   = 60
$Button3.height                  = 30
$Button3.location                = New-Object System.Drawing.Point(415,196)
$Button3.Font                    = 'Microsoft Sans Serif,10'

$Button4                         = New-Object system.Windows.Forms.Button
$Button4.text                    = "Login"
$Button4.width                   = 60
$Button4.height                  = 30
$Button4.location                = New-Object System.Drawing.Point(59,89)
$Button4.Font                    = 'Microsoft Sans Serif,10'

$ListBox1                        = New-Object system.Windows.Forms.ListBox
$ListBox1.text                   = "listBox"
$ListBox1.width                  = 230
$ListBox1.height                 = 138
$ListBox1.location               = New-Object System.Drawing.Point(115,378)

$Label2                          = New-Object system.Windows.Forms.Label
$Label2.text                     = "SAN"
$Label2.AutoSize                 = $true
$Label2.width                    = 25
$Label2.height                   = 10
$Label2.location                 = New-Object System.Drawing.Point(25,345)
$Label2.Font                     = 'Microsoft Sans Serif,10'

$TextBox1                        = New-Object system.Windows.Forms.TextBox
$TextBox1.multiline              = $false
$TextBox1.width                  = 152
$TextBox1.height                 = 20
$TextBox1.location               = New-Object System.Drawing.Point(113,345)
$TextBox1.Font                   = 'Microsoft Sans Serif,10'

$Button5                         = New-Object system.Windows.Forms.Button
$Button5.text                    = "Add"
$Button5.width                   = 60
$Button5.height                  = 30
$Button5.location                = New-Object System.Drawing.Point(286,341)
$Button5.Font                    = 'Microsoft Sans Serif,10'

$Label3                          = New-Object system.Windows.Forms.Label
$Label3.text                     = "Certificate Friendly Name"
$Label3.AutoSize                 = $true
$Label3.width                    = 25
$Label3.height                   = 10
$Label3.location                 = New-Object System.Drawing.Point(24,281)
$Label3.Font                     = 'Microsoft Sans Serif,10'

$TextBox2                        = New-Object system.Windows.Forms.TextBox
$TextBox2.multiline              = $false
$TextBox2.width                  = 144
$TextBox2.height                 = 20
$TextBox2.location               = New-Object System.Drawing.Point(201,281)
$TextBox2.Font                   = 'Microsoft Sans Serif,10'

$Label4                          = New-Object system.Windows.Forms.Label
$Label4.text                     = "Certificate Length"
$Label4.AutoSize                 = $true
$Label4.width                    = 25
$Label4.height                   = 10
$Label4.location                 = New-Object System.Drawing.Point(26,314)
$Label4.Font                     = 'Microsoft Sans Serif,10'

$ComboBox2                       = New-Object system.Windows.Forms.ComboBox
$ComboBox2.text                  = "comboBox"
$ComboBox2.width                 = 100
$ComboBox2.height                = 20
$ComboBox2.location              = New-Object System.Drawing.Point(245,314)
$ComboBox2.Font                  = 'Microsoft Sans Serif,10'

$Label5                          = New-Object system.Windows.Forms.Label
$Label5.text                     = "label"
$Label5.AutoSize                 = $true
$Label5.width                    = 25
$Label5.height                   = 10
$Label5.location                 = New-Object System.Drawing.Point(381,344)
$Label5.Font                     = 'Microsoft Sans Serif,10'

$Button6                         = New-Object system.Windows.Forms.Button
$Button6.text                    = "Upload"
$Button6.width                   = 60
$Button6.height                  = 30
$Button6.location                = New-Object System.Drawing.Point(512,383)
$Button6.Font                    = 'Microsoft Sans Serif,10'

$Button7                         = New-Object system.Windows.Forms.Button
$Button7.text                    = "select file"
$Button7.width                   = 60
$Button7.height                  = 30
$Button7.location                = New-Object System.Drawing.Point(438,382)
$Button7.Font                    = 'Microsoft Sans Serif,10'

$TextBox3                        = New-Object system.Windows.Forms.TextBox
$TextBox3.multiline              = $false
$TextBox3.width                  = 136
$TextBox3.height                 = 20
$TextBox3.location               = New-Object System.Drawing.Point(435,345)
$TextBox3.Font                   = 'Microsoft Sans Serif,10'

$CertificateManager.controls.AddRange(@($ComboBox1,$tb_vaultname,$tb_subname,$subname,$rb_createcsr,$rb_completecsr,$rb_exportcert,$Button1,$Label1,$Button2,$Button3,$Button4,$ListBox1,$Label2,$TextBox1,$Button5,$Label3,$TextBox2,$Label4,$ComboBox2,$Label5,$Button6,$Button7,$TextBox3))




#Write your logic code here

[void]$CertificateManager.ShowDialog()