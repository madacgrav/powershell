$webhook = 'https://outlook.office.com/webhook/d1beb2fd-a894-468d-9dea-6994897a12c0@36da45f1-dd2c-4d1f-af13-5abe46b99921/IncomingWebhook/5464fb3d70874e829f5b05372c9c6cd7/7c5c8193-dd8c-4774-b312-77b6b1360e56'

$body1 = @{
        'text'= 'Hello World! from PowerShell'
}

$body2 = @"
{
    "@context": "https://schema.org/extensions",
    "@type": "MessageCard",
    "potentialAction": [
        {
            "@type": "OpenUri",
            "name": "View All Tweets",
            "targets": [
                {
                    "os": "default",
                    "uri": "https://twitter.com/search?q=%23MicrosoftTeams"
                }
            ]
        }
    ],
    "sections": [
        {
            "facts": [
                {
                    "name": "Posted By:",
                    "value": ""
                },
                {
                    "name": "Posted At:",
                    "value": ""
                },
                {
                    "name": "Tweet:",
                    "value": ""
                }
            ],
            "text": "A tweet with #MicrosoftTeams has been posted:"
        }
    ],
    "summary": "Tweet Posted",
    "themeColor": "0072C6",
    "title": "Tweet Posted"
}
"@

$body3 = @{
    "@context"        = "https://schema.org/extensions"
    "@type"           = "MessageCard"
    "potentialAction" = @{
        "@type"   = "OpenUri"
        "name"    = "View All Tweets"
        "targets" = @{
            "os"  = "default"
            "uri" = "https://portal.azure.com/#@deloitte.onmicrosoft.com/resource/" + "resource id"
        }
        
    }
    "sections"        = @{
        "facts" = @(
            @{
                "KeyVaultCertName" = "Posted By:"
                "value"            = ""
            },
            @{
                "KeyVaultName" = "Posted At:"
                "value"        = ""
            },
            @{
                "KeyVaultCertEnabled" = "Tweet:"
                "value"               = ""
            },
            @{
                "KeyVaultCertExpiryDate" = "Tweet:"
                "value"                  = ""
            }
        )
    }
    "summary"         = "Expired Certs in KeyVault"
    "themeColor"      = "0072C6"
    "title"           = "Expired Certs"
}


$params = @{
    Headers = @{'accept'='application/json'}
    Body = $body3 | convertto-json
    Method = 'Post'
    URI = $webhook 
}

Invoke-RestMethod @params