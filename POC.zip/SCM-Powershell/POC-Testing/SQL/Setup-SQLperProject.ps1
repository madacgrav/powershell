param (
    [string]$sqlserver = "con-dassql1-dev-eus.database.windows.net",
    [string]$dbname = "DCMDB",
    [string]$webAppName = "depf-eus",
    [string]$env = "dev"
)



$sql_command_create = "SELECT TOP (10) [Id],[Code],[ISO2],[ISO3],[Name]FROM [geo].[Country]"

$creds = Get-Credential
$Username = $creds.UserName
$Password = $creds.Password

$constr = "Data Source=$sqlserver;initial catalog=$dbname;User ID=$Username;password=$Password;authentication=Active Directory Password"

#Invoke-Sqlcmd -Query $sql_command_create -ServerInstance $sqlserver -Database $dbname -Credential $creds

Invoke-Sqlcmd -Query $sql_command_create -ConnectionString $constr






switch ($env) {
    "dev" {

    }
    "qas" {

    }
    "loa" {

    }
    "stg" {

    }
    "prd" {

    }
    "bcp" {

    }

}