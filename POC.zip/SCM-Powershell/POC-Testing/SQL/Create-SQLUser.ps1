param (
    [Parameter(Mandatory=$true)]
    [string]$sqlserver = "servername here",
    [Parameter(Mandatory=$true)]
    [string]$dbname = "database name here here",
    [Parameter(Mandatory=$true)]
    [string]$user = "adagraves@deloitte.com",
    [ValidateSet("AZAD","SQL")] 
    [string]$usertype = "SQL",
    [boolean]$azvalidation = $false,
    [string]$dbaccess = "read"
)

switch ($usertype) {
    "SQL" {
        $gooduser = $true
        $sql_command_create = "CREATE USER " + $user + " FROM LOGIN " + $user + ";"
    }
    "AZAD" {
        #this can be a SPN to make more dynamic
        if ($azvalidation) {
            try {
                Login-AzureRmAccount
                #connect to azure AD
                $currentAzureContext = Get-AzureRmContext
                $tenantId = $currentAzureContext.Tenant.Id
                $accountId = $currentAzureContext.Account.Id
                Connect-AzureAD -TenantId $tenantId -AccountId $accountId
                #check to see if AD user exists
                if (Get-AzureADUser -ObjectId $user) {
                    $gooduser = $true
                }
                else {
                    $gooduser = $false
                }
            }
            catch {
                $ErrorMessage = $_.Exception.Message
                write-host ("Error!! - " + $ErrorMessage)
                exit 1
            }

        }
        else {
            $gooduser = $true
        }
        #This command should work for user accounts + groups
        $sql_command_create = "CREATE USER [" + $user + "] FROM EXTERNAL PROVIDER;"
    }
}

switch ($dbaccess) {
    "read" {
        $sql_commands = @("EXEC sp_addrolemember 'db_datareader', '" + $user + "'")
    }
    "write" {
        #find correct role for write
        $sql_commands = @(
            "EXEC sp_addrolemember 'db_datawriter', '" + $user + "'",
            "EXEC sp_addrolemember 'db_datareader', '" + $user + "'"
            )
    }
    "admin" {
        #find correct role for admin
        $sql_commands = @(
            "EXEC sp_addrolemember 'db_datareader', '" + $user + "'",
            "EXEC sp_addrolemember 'db_datawriter', '" + $user + "'",
            "EXEC sp_addrolemember 'db_ddladmin', '" + $user + "'"
        )
    }
    default {
        #if value outside of bounds - grant read access
        $sql_commands = @("EXEC sp_addrolemember 'db_datareader', '" + $user + "'")
    }

}

if ($gooduser) {
    #Test SQL connection and then if ok run SQL commands
    #find better way to send credentials
    #verify this works for azure dbs not just regular sql
    if (Test-SqlConnection -ServerName $sqlserver -DatabaseName $dbname -Credential (Get-Credential)) {
        try {
            # check Add-SQLLogin command
            Invoke-Sqlcmd -Query $sql_command_create -ServerName $sqlserver -DatabaseName $dbname -Credential (Get-Credential)
            foreach ($sql_command_access in $sql_commands) {
                # check out this command Add-RoleMember -MemberName "foo\user1" -Database "DB1" -RoleName "myRole"
                Invoke-Sqlcmd -Query $sql_command_access -ServerName $sqlserver -DatabaseName $dbname -Credential (Get-Credential)
            }
        }
        catch {
            $ErrorMessage = $_.Exception.Message
            write-host ("Error!! - " + $ErrorMessage)
            exit 1
        }

    }
    else {
        write-host "Bad SQL connection"
    }
}
else {
    write-host "Invalid AAD user or group, please verify user or group exists in AAD"
}