param (
    [Parameter(Mandatory=$true)]
    [string]$sqlserver = "servername here",
    [Parameter(Mandatory=$true)]
    [string]$dbname = "database name here here",
    [Parameter(Mandatory=$true)]
    [string]$rg = "resourcegroup",
    [date]$restorepoint,
    [ValidateSet("restore","delete")] 
    [string]$action = "restore"
)


#The AZ module is required.

switch ($action) {
    "restore" {
         try {
            if ($restorepoint) {
                $Database = Get-AzSqlDatabase -ResourceGroupName $rg -ServerName $sqlserver -DatabaseName $dbname
                $tempdbname = $dbname + "_temp"
                Restore-AzSqlDatabase -FromPointInTimeBackup -PointInTime UTCDateTime -ResourceGroupName $Database.ResourceGroupName -ServerName $Database.ServerName -TargetDatabaseName $tempdbname -ResourceId $Database.ResourceID -ElasticPoolName $Database.ElasticPoolName
                Set-AzureSqlDatabase -ServerName $sqlserver -DatabaseName $dbname -NewDatabaseName ($dbname + "_old") 
                Set-AzureSqlDatabase -ServerName $sqlserver -DatabaseName $tempdbname -NewDatabaseName $dbname 
                #Test-SqlConnection -ServerName $sqlserver -DatabaseName $dbname -Credential (Get-Credential)
            }
            else {
                write-host "No restore point date time specified.  Restore action skipped"
            }

        }
        catch {
            $ErrorMessage = $_.Exception.Message
            write-host ("Error!! - " + $ErrorMessage)
            exit 1
        }
    }
    "delete" {
        try {
            Remove-AzSqlDatabase -ResourceGroupName $rg -ServerName $sqlserver -DatabaseName $dbname
        }
        catch {
            $ErrorMessage = $_.Exception.Message
            write-host ("Error!! - " + $ErrorMessage)
            exit 1  
        }
    }
}
