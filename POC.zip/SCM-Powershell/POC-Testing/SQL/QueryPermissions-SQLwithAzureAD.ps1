# Pass in the variables or just update them directly here.
#possiby pass in values from ARM output.
param(
    $appName = "ddcm-eus",
    $sqlServer ="con-dassql1-dev-eus.database.windows.net",
    $sqlDBname = "DCMDB"
)



$query = "SELECT DP1.name AS DatabaseRoleName,
isnull (DP2.name, 'No members') AS DatabaseUserName
FROM sys.database_role_members AS DRM
RIGHT OUTER JOIN sys.database_principals AS DP1
ON DRM.role_principal_id = DP1.principal_id
LEFT OUTER JOIN sys.database_principals AS DP2
ON DRM.member_principal_id = DP2.principal_id
WHERE DP1.type = 'R'
AND DP2.name = 'ddcm-eus'
ORDER BY DP1.name;"

$user = "usa-adagraves@deloitte.com"
$pass = "7wL1J9o)EPxPVQXvl>09gVK"
$con = "Data Source=$sqlServer;Initial Catalog=$sqlDBname;User ID=$user;Password='$pass';Connect Timeout=30;Encrypt=False;Authentication='Active Directory Password'"

#write-host $query
Invoke-Sqlcmd -Query $query -ConnectionString $con


