# Pass in the variables or just update them directly here.
#possiby pass in values from ARM output.
param(
    $appName = "ddcm-eus",
    $sqlServer ="con-dassql1-prd-eus.database.windows.net",
    $sqlDBname = "DCMDB"
)



$queries =@(
    "CREATE USER [" + $appName + "] FROM EXTERNAL PROVIDER", 
    "CREATE ROLE db_executor", 
    "GRANT EXECUTE TO db_executor",
    "EXEC sp_addrolemember 'db_executor', '" + $appName + "'",
    "EXEC sp_addrolemember 'db_datareader', '" + $appName + "'",
    "EXEC sp_addrolemember 'db_datawriter', '" + $appName + "'"
    "EXEC sp_addrolemember 'db_owner', '" + $appName + "'"
)

$user = "usa-adagraves@deloitte.com"
$pass = "uy70qmccaE4Sd_fwPWb%>wI"
#$con = "Data Source=$sqlServer;Initial Catalog=$sqlDBname;User ID=$user;Password='$pass';Connect Timeout=30;Encrypt=False;Authentication='Active Directory Password'"
$con = " Data Source=use-svc-sql1-dev.database.windows.net;Initial Catalog=glass;User ID=usa-adagraves@deloitte.com;Password='*MPM2#Zf2mk<*EjDhZ!b';Connect Timeout=30;Encrypt=False;Authentication='Active Directory Password'"

foreach ($query in $queries) {
    Invoke-Sqlcmd -Query $query -ConnectionString $con -ErrorAction SilentlyContinue
}

