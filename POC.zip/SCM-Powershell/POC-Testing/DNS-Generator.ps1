param (
    $prdurl = "ascm.deloitte.com",
    $projectcode = "dcm",
    $functioncode = "con",
    $primaryregion = "eus"
)

$rootappurl = ".app.deloitte.com"
$rootaseurl = ".ase.deloitet.com"

$envs = @("d","q","l","s","p")
$preprodhosts = @()
$prodhosts = @()
$stagehosts = @()

switch ($primaryregion) {
    "eus" {
        $partnerregion = "wus"
    }
    "wus" {
        $partnerregion = "eus"
    }
    "default" {
        $partnerregion = "wus"
    }
}

foreach ($env in $envs) {
    if ($env -eq "p") {
        $prodhosts +=  $prdurl
        $prodhosts +=  $projectcode + "-" + $primaryregion + "." + $functioncode + $rootappurl
        $prodhosts +=  $projectcode + "-" +  $partnerregion + "." + $functioncode + $rootappurl
        $prodhosts +=  $projectcode + "-" + $primaryregion + ".scm." + $functioncode + $rootaseurl
        $prodhosts +=  $projectcode + "-" +  $partnerregion + ".scm." + $functioncode + $rootaseurl
    }
    elseif ($env -eq "s")  {
        $stagehosts += $env + $prdurl
        $stagehosts += $env + $projectcode + "-" + $primaryregion + "." + $functioncode + $rootappurl
        $stagehosts += $env + $projectcode + "-" + $primaryregion + ".scm." + $functioncode + $rootaseurl
        $stagehosts += $env + $projectcode + "-" +  $partnerregion + "." + $functioncode + $rootappurl
        $stagehosts += $env + $projectcode + "-" +  $partnerregion + ".scm." + $functioncode + $rootaseurl
    }
    else {
        $preprodhosts += $env + $prdurl
        $preprodhosts += $env + $projectcode + "-" + $primaryregion + "." + $functioncode + $rootappurl
        $preprodhosts += $env + $projectcode + "-" + $primaryregion + ".scm." + $functioncode + $rootaseurl
    }
}

write-host "`n`n"
write-host "PreProd Hosts:"
write-host "-------------------"
$preprodhosts
write-host "`n`n"
write-host "Stage Hosts:"
write-host "-------------------"
$stagehosts
write-host "`n`n"
write-host "Prod Hosts:"
write-host "-------------------"
$prodhosts
write-host "`n`n"