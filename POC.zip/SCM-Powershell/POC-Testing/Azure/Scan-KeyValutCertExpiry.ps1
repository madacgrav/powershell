
param (
    [Parameter(Mandatory=$true)]
    [string[]]$subscriptions = "US-AZSUB-AME-ITS-DAS-RnD"
)


#To do all subscritions some code could be added here to grab the list of available subscriptions and then iterate through them
foreach ($subName in $subscriptions) {
    # Gets all KeyValuts in a subscription
    $expirationtime = 50

    try {
        Select-AzureRmSubscription -SubscriptionName $subName
        $KeyVaults = Get-AzureRMKeyVault
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        write-host ("Error !! - " + $ErrorMessage)
    }

    foreach ($KeyVault in $KeyVaults) {
        write-host $KeyVault.Name
        try {
            $AllKeyVaultCerts = $KeyVault | Get-AzureKeyVaultCertificate
            $result = @()
            $result += "KeyVaultCertName, KeyVaultName, KeyVaultCertEnabled, KeyVaultCertExpiryDate"
            foreach($KeyVaultCert in $AllKeyVaultCerts){
                $KeyVaultName = $KeyVaultCert.VaultName
                $KeyVaultCertName = $KeyVaultCert.Name
                $KeyVaultCertEnabled = $KeyVaultCert.Enabled
                $KeyVaultCertExpiryDate = $KeyVaultCert.expires
                if($KeyVaultCertExpiryDate -lt ((Get-Date).AddDays($expirationtime))){
                    $result+="$KeyVaultCertName, $KeyVaultName, $KeyVaultCertEnabled, $KeyVaultCertExpiryDate"
                }
            }
            #Export this somewhere helpful or better yet email it out to someone.
            # or even better post to Teams.
            $result | ConvertFrom-Csv
        }
        catch {
            $ErrorMessage = $_.Exception.Message
            write-host ("Error !! - " + $ErrorMessage)
            # also email out if there is an error or better yet create a ticket or post to teams
        }

    }
}