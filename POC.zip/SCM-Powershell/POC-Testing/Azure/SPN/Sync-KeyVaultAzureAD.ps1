$kvName = "scm-kv-npd-eus"   
#import-module AzureAD


$KeyVault = Get-AzureRMKeyVault -VaultName $kvName
$AllKeyVaultSecrets = $KeyVault | Get-AzureKeyVaultSecret | Where-Object { $_.ContentType -eq "Azure App Registration" } | Sort-Object -Property Expires
foreach ($secret in $AllKeyVaultSecrets) {
    if ($secret.tags.AzureSPNname) {
        $spnName = $secret.tags.AzureSPNname
    }
    if ($secret.tags.AzureSPNName) {
        $spnName = $secret.tags.AzureSPNName
    }
    $spndata = Get-AzurermADApplication -DisplayName $spnName
    $spnCount = $spndata.Count
    foreach ($spn in $spndata) {
        $appinfo = Get-AzureADApplicationPasswordCredential -objectID $spn.ObjectId
        [datetime]$enddate = (Get-Date).AddDays(1)
        foreach ($app in $appinfo) {
            # write-host $app.KeyId -ForegroundColor red
            # write-host $app.EndDate -ForegroundColor red
            if ($app.EndDate -gt $enddate) {
                #  write-host "this is new" -ForegroundColor green
                $enddate = $app.EndDate
            }
        }
        #  write-host $enddate -ForegroundColor yellow
        $Tags = @{ 'objID' = $spn.ObjectID; 'AppID' = $spn.ApplicationID; 'AzureSPNname' = $spn.DisplayName }
        $ContentType = 'Azure App Registration'
        if ($spnCount -eq 1) {
            write-host "updating SPN in keyvault"
            write-host "Name: " $secret.Name
          #  write-host "Tags: " $Tags
          $tags
          #  write-host "Exipire Date: " $enddate
          #  write-host "Content Type: " $ContentType
            #Update-AzureKeyVaultSecret -VaultName $kvName -Name $secret.Name -Expires $enddate -ContentType $ContentType -Tags $Tags
        }
        else {
            write-host "Multiple responses for same SPN name.  Manually check each one" -foreground red
            write-host $spn.DisplayName -foreground yellow
            write-host "Name in kKeyVault: " -NoNewline -foreground red
            write-host $secret.Name -foreground yellow
            write-host "Application ID: " -NoNewline -foreground red
            write-host $spn.ApplicationID -foreground yellow
        }
    }
}