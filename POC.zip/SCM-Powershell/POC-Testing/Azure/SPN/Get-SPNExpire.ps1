$SPNdata = Import-CSV -Path ".\MasterSPNList.csv"

$allsecrets = @()

foreach ($spn in $SPNdata) {
    $secret = New-Object -TypeName psobject 
    $secret | Add-Member -MemberType NoteProperty -Name Name -Value $spn.KeyVaultSecretName
    $secret | Add-Member -MemberType NoteProperty -Name KeyVaultName -Value $spn.KeyVaultName
    $secret | Add-Member -MemberType NoteProperty -Name Subscription -Value $spn.Subscription
    $secret | Add-Member -MemberType NoteProperty -Name ApplicationID -Value $spn.ApplicationID
    $secret | Add-Member -MemberType NoteProperty -Name AzureSPNName -Value $spn.AzureSPNName

    $newName = ($spn.AzureSPNName).replace(" ", "-")
    $secret | Add-Member -MemberType NoteProperty -Name NewKeyVaultSecretName -Value $newName

    $adreponse =  Get-AzureADApplication -SearchString $spn.AzureSPNName
    $spnExpire = $adreponse.PasswordCredentials.EndDate
    $spnobjID = $adreponse.ObjectID
    $secret | Add-Member -MemberType NoteProperty -Name ExpireDate -Value $spnExpire
    $secret | Add-Member -MemberType NoteProperty -Name ObjectID -Value $spnobjID
    $secret
    $allsecrets += $secret
}

 #$allsecrets
 $allsecrets | Export-Csv -Path ".\UpdatedList.csv"