$kvList = @(
    @{
        functionName   = "CONSULTING"
        kvName         = "consult-kv-preprod-eus"
        kvsubscription = "US_CONSULTING_PREPROD"
    },
    @{
        functionName   = "CONSULTING"
        kvName         = "consult-kv-prod-eus"
        kvsubscription = "US_CONSULTING_PROD"
    },
    @{
        functionName = "ENABLING_AREAS"
        kvName = "enabling-kv-preprod-eus"
        kvsubscription = "US_ENABLING_AREAS_PREPROD"
    },
    @{
        functionName = "ENABLING_AREAS"
        kvName = "enabling-kv-prod-eus"
        kvsubscription = "US_ENABLING_AREAS_PROD"
    },
    # @{
    #     functionName = "ADVISORY"
    #     kvName = "advisory-kv-preprod-eus"
    #     kvsubscription = "US_ADVISORY_PREPROD"
    # },
    # @{
    #     functionName = "ADVISORY"
    #     kvName = "advisory-kv-prod-eus"
    #     kvsubscription = "US_ADVISORY_PROD"
    # },
    @{
        functionName = "TAX"
        kvName = "tax-kv-preprod-eus"
        kvsubscription = "US_TAX_PREPROD"
    },
    @{
        functionName = "TAX"
        kvName = "tax-kv-prod-eus"
        kvsubscription = "US_TAX_PROD"
    }
)

#password
#cert

$allsecrets = @()
foreach ($kv in $kvList) {
    try {
        Select-AzureRmSubscription -SubscriptionName $kv.kvsubscription
        $KeyVault = Get-AzureRMKeyVault -VaultName $kv.kvName
        $AllKeyVaultCerts = $KeyVault | Get-AzureKeyVaultSecret
        foreach ($KeyVaultSecret in $AllKeyVaultCerts) {
            if ((($KeyVaultSecret.Name).tolower() -notlike "*password*" ) -and (($KeyVaultSecret.Name).tolower() -notlike "*cert*" )) {
               # $extrainfo = Get-AzureKeyVaultSecret -VaultName $kv.kvName -Name $KeyVaultSecret.Name
                $secret = New-Object -TypeName psobject 
                $secret | Add-Member -MemberType NoteProperty -Name Name -Value $KeyVaultSecret.Name
                #$secret | Add-Member -MemberType NoteProperty -Name Key -Value $extrainfo.SecretValueText
                $secret | Add-Member -MemberType NoteProperty -Name KeyVaultName -Value $kv.kvName
                $secret | Add-Member -MemberType NoteProperty -Name Subscription -Value $kv.kvsubscription
                $secret | Add-Member -MemberType NoteProperty -Name ExpireDate -Value $KeyVaultSecret.expires
                $allsecrets += $secret
                Clear-Variable -Name "secret"
            }
        }
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        write-host ("Error !! - " + $ErrorMessage)
        # also email out if there is an error or better yet create a ticket or post to teams
    }
}
$allsecrets | Export-Csv -Path ".\SPNList.csv"