#Import data from csv file
$SPNdata = Import-CSV -Path ".\MasterSPNList.csv"
#sets number of days to expire
$expirationtime = 30


#Iterates through each SPN -- columns in CSV need to match Expires and Name
foreach ($spn in $SPNdata) {
    if($spn.Expires -lt ((Get-Date).AddDays($expirationtime))){
        $KeyVaultSecretName = $spn.Name
        $KeyVaultSecretExpiryDate = $spn.Expires
        #Add content to html string to output to teams
        $teamstext += "<tr><td>$KeyVaultSecretName</td><td>$KeyVaultSecretExpiryDate</td></tr>"
    }
}
$teamstext += "</table>"

#outputs html string
$teamstext