$kvName = "scm-kv-npd-eus"
$subID = "e8d1eb9b-46cf-46b0-9b02-3e133288c4ef"
$link = "https://portal.azure.com/#@deloitte.onmicrosoft.com/resource/subscriptions/e8d1eb9b-46cf-46b0-9b02-3e133288c4ef/resourceGroups/AZRG-USE-SVC-KV-NPD/providers/Microsoft.KeyVault/vaults/scm-kv-npd-eus/secrets"

$expirationtime = 30

function Post-Teams ($bodytext) {
    $webhook = 'https://outlook.office.com/webhook/d1beb2fd-a894-468d-9dea-6994897a12c0@36da45f1-dd2c-4d1f-af13-5abe46b99921/IncomingWebhook/81da8929a4704f42a6a08f26f13b9cf6/7c5c8193-dd8c-4774-b312-77b6b1360e56'
    $formattedBody = @{
        'text' = $bodytext
    }
    $params = @{
        Headers = @{'accept' = 'application/json' }
        Body    = $formattedBody | convertto-json
        Method  = 'Post'
        URI     = $webhook 
    }
    $api = Invoke-RestMethod @params
}

try {
    write-output "Connecting"
   # $login = Connect-AzAccount -Credential $Credential -Tenant "36da45f1-dd2c-4d1f-af13-5abe46b99921" -ServicePrincipal
    $selectedsub = Set-AzContext -SubscriptionId $subID
    write-output "Querying"
    $KeyVault = Get-AzKeyVault -VaultName $kvName
    $AllKeyVaultSecrets = $KeyVault | Get-AzKeyVaultSecret | Sort-Object -Property Expires
    $teamstext = "<table><th>Expired AppReg/SPNs for <a href='$link'>$kvName </a></th><tr><td><b>Name</b></td><td><b>Expire Date</b></td></tr>"
    foreach ($secret in $AllKeyVaultSecrets) {
        if(($secret.Expires -lt ((Get-Date).AddDays($expirationtime))) -and $secret.ContentType -eq "Azure App Registration"){
            $KeyVaultSecretName = $secret.Name
            $KeyVaultSecretExpiryDate = $secret.Expires
            $teamstext += "<tr><td>$KeyVaultSecretName</td><td>$KeyVaultSecretExpiryDate</td></tr>"
        }
    }
    $teamstext += "</table>"
    Post-Teams -bodytext $teamstext

}
catch {
    $ErrorMessage = $_.Exception.Message
    write-host ("Error !! - " + $ErrorMessage)
    # also email out if there is an error or better yet create a ticket or post to teams
}

