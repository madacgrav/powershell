$SPNdata = Import-CSV -Path ".\SPN-Names.csv"

foreach ($spn in $SPNdata) {
    Get-AzureRmADServicePrincipal -ObjectId $spn.objID | Update-AzureRmADServicePrincipal -DisplayName $spn.NewDisplayName
}

