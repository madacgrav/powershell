$kvName = "scm-kv-npd-eus"
$subID = "e8d1eb9b-46cf-46b0-9b02-3e133288c4ef"

# Name                  : US-My-Compliance-Dashboard-Mobile-PROD
# KeyVaultName          : enabling-kv-prod-eus
# Subscription          : US_ENABLING_AREAS_PROD
# ApplicationID         : fdad3339-1c2b-4005-a4fc-7f0cc5c6ad7a
# AzureSPNName          : US My Compliance Dashboard Mobile PROD
# NewKeyVaultSecretName : US-My-Compliance-Dashboard-Mobile-PROD
# ExpireDate            : 7/17/2021 9:25
# ObjectID              : c99db4f0-20b4-4713-9cb5-86a466370361

Select-AzureRmSubscription $subID

$allsecrets = @()
$KeyVault = Get-AzureRMKeyVault -VaultName $kvName
$AllKeyVaultCerts = $KeyVault | Get-AzureKeyVaultSecret
foreach ($KeyVaultSecret in $AllKeyVaultCerts) {
    if ($KeyVaultSecret.Tags.Item("objID")) {
        $secret = New-Object -TypeName psobject 
        $secret | Add-Member -MemberType NoteProperty -Name Name -Value $KeyVaultSecret.Name
        $secret | Add-Member -MemberType NoteProperty -Name objID -Value $KeyVaultSecret.Tags.Item("objID")
        $secret | Add-Member -MemberType NoteProperty -Name AzureSPNname -Value $KeyVaultSecret.Tags.Item("AzureSPNname")
        $allsecrets += $secret
        Clear-Variable -Name "secret"
    }
}


$allsecrets | Export-Csv -Path ".\SPN-Names.csv"