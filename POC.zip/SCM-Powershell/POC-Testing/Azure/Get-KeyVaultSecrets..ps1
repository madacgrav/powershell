$functionName = "CONSULTING"
$kvName = "consult-kv-preprod-eus"
$kvsubscription = "US_CONSULTING_PREPROD"




# Get-AzureADServicePrincipal
#    [-All <Boolean>]
#    [-Top <Int32>]
#    [-Filter <String>]
#    [<CommonParameters>]
# PowerShell

# Copy
# Get-AzureADServicePrincipal
#    [-SearchString <String>]
#    [-All <Boolean>]
#    [<CommonParameters>]


