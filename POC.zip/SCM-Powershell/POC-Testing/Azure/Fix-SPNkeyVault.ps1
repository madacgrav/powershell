$secrets = Import-Csv -Path ".\SPNList_Input.csv"

foreach ($secret in $secrets) {
    $key = ConvertTo-SecureString -String $secret.key -AsPlainText -Force
    Set-AzureKeyVaultSecret -VaultName $secret.KeyVaultName -Name $secret.NewName -SecretValue $key
    Remove-AzureKeyVaultSecret -VaultName $secret.KeyVaultName  -Name $secret.Name -PassThru -Force
}