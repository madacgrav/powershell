####### Query DB for list of items, dump into custom object.


$subscriptionResources = @{
    type = 'storageAccount'
    name = 'app-SA'
    secretName = 'secret'
    keyvaultName = 'KVname'
    resourceGroup = 'rgname'
}


function Rotate-StorageAccountKey ($item){
    
    
    Update-AzureKeyVaultSecret -VaultName $item.keyvaultName -Name $item.secretName -Expires $Expires -NotBefore $Nbf -ContentType $ContentType -Enable $True -Tag $Tags -PassThr
    
}




foreach ($resource in $subscriptionResources) {
    switch ($resource.type) {
        "storageAccount" {
            $newKey = (Get-AzStorageAccountKey -ResourceGroupName $resource.resourceGroup -Name $resource.Name).Value[0]
        }
        "serviceBus" {
    
        }
        "redisCache" {
    
        }
    }
    $Expires = (Get-Date).AddMonths(3).ToUniversalTime()
    Set-AzureKeyVaultSecret -VaultName $resource.keyvaultName -Name $resource.secretName -SecretValue $newKey-Expires $Expires

}
