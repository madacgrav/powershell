param (
    [Parameter(Mandatory=$true)]
    [string[]]$subscriptions = "US-AZSUB-AME-ITS-DAS-RnD",
    [Parameter(Mandatory=$true)]
    [String[]]$rgs = "AZRG-USE-ENA-LINKT-DEV",    
    [int]$months = -8
)

#Access Azure -- this can be changed to use a SPN and stored in credential section of Azure Automation
foreach ($subName in $subscriptions) {
    Select-AzureRmSubscription -SubscriptionName $subName
    foreach ($rg in $rgs) {
        #  Single Command to remove deployments older than number of months for a resource group
        try {
            Get-AzureRmResourceGroupDeployment $rg | Where-Object -Property TimeStamp  -LE -Value ((Get-Date).AddMonths($months)) | Remove-AzureRmResourceGroupDeployment -ResourceGroupName $rg
        }
        catch {
            $ErrorMessage = $_.Exception.Message
            write-host ("Error !! - " + $ErrorMessage)
        }
    }
}

