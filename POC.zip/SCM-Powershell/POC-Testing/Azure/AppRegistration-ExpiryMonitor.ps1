﻿#Variable
$SmtpServerName = "smtp.deloitte.com"

#Get All Azure App Registration start with US 
$AzureApps = Get-AzureRmADApplication -DisplayNameStartWith US
#$AzureApps = Get-AzADApplication -DisplayNameStartWith US

$Apps = $AzureApps | Where-Object {$_.DisplayName.EndsWith('NONPROD') -or $_.DisplayName.EndsWith('PROD')} 

$NearExpiryApps = @()
$Expired = @()
$Date = Get-Date

foreach($App in $Apps){
    #Write-Host "App Registration: $($App.DisplayName)" -ForegroundColor Cyan
    #$AppDetail = Get-AzADAppCredential -ApplicationId $App.ApplicationId 
    $AppDetail = Get-AzureRmADAppCredential -ApplicationId $App.ApplicationId 
    $AppDetail = $AppDetail | Where-Object {$_.Type -eq 'Password'} | Sort-Object EndDate | Select-Object -First 1
    if($AppDetail){
        $NumberOfDays = ([datetime]$AppDetail.EndDate - $Date).Days
        if($NumberOfDays -le 15 -and $NumberOfDays -ge 1){
            $AppObject = New-Object PSObject -Property @{
                DisplayName      = $App.DisplayName
                ApplicationId    = $App.ApplicationId
                ExpiryDate       = $AppDetail.EndDate
            }
            $NearExpiryApps += $AppObject
        }
        if($NumberOfDays -le 0){
            $AppObject = New-Object PSObject -Property @{
                DisplayName      = $App.DisplayName
                ApplicationId    = $App.ApplicationId
                ExpiryDate       = $AppDetail.EndDate
            }
            $Expired += $AppObject
        }
    }
}

# Style for results table
$style = "<style>BODY{font-family: Calibri; font-size: 11pt;}"
$style = $style + "TABLE{border: 1px solid black; border-collapse: collapse;}"
$style = $style + "TH{border: 1px solid black; background: #dddddd; padding: 5px; }"
$style = $style + "TD{border: 1px solid black; padding: 5px; }"
$style = $style + "</style>"

# Near Expiry
$messageBody = "</br><div>Hello Team, The below are the some of Azure App Registration may need your attention</div></br>"
$messageBody = "$messageBody </br><div>============= Total Number of App Registration <span style='color:green'>$($NearExpiryApps.Count)</span>, Needs Attention ==============</div></br>"
$messageBody = $messageBody + ($NearExpiryApps | Select-Object ApplicationId, DisplayName, ExpiryDate | ConvertTo-HTML -head $style | Out-String)

# Expiry App Registration
$messageBody = "$messageBody </br><div>============= Total Number of App Registration <span style='color:green'>$($Expired.Count)</span>, Needs Immediate Attention =============</div></br>"
$messageBody = $messageBody + ($Expired | Select-Object ApplicationId, DisplayName, ExpiryDate | ConvertTo-HTML -head $style | Out-String)
#$messageBody = $messageBody -replace "<td>ExpiryDate</td>","<td style='color: red'>ExpiryDate</td>"

Send-MailMessage -From 'ravikumar298@deloitte.com' -To 'ravikumar298@deloitte.com' -SmtpServer $SmtpServerName -Body $messageBody.ToString() -Subject "Azure App Registrations Status - $($Date.ToString("yyyy-MM-ddTHH:MM:ss"))" -BodyAsHtml


