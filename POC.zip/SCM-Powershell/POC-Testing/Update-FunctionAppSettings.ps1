
param (
    [string]$rg,
    [string]$functionName,
    [string]$functionslot,
    [hashtable]$parameters
)



function UpdateAppSettings {
    param( [string]$ResourceGroup, [string]$FunctionAppName, [string]$Slot, [hashtable]$AppSettings )
        try {
            Write-Host "Loading Existing AppSettings"
            $webApp = Get-AzureRmWebAppSlot -ResourceGroupName  $ResourceGroup -Name $FunctionAppName -Slot $Slot
        
            Write-Host "Applying New AppSettings"
            $hash = @{}
            ForEach ($kvp in $webApp.SiteConfig.AppSettings) {
                $hash[$kvp.Name] = $kvp.Value
            }
            ForEach ($key in $AppSettings.Keys) {
                $hash[$key] = $AppSettings[$key]
            }
            Write-Host "Saving AppSettings"
            Set-AzureRMWebAppSlot -ResourceGroupName $ResourceGroup -Name $FunctionAppName -AppSettings $hash -Slot $Slot | Out-Null
            Write-Host "AppSettings Updated"
        }
        catch {
            $ErrorMessage = $_.Exception.Message
            write-host ("Error !! - " + $ErrorMessage)
        }

}
   

UpdateAppSettings -AppSettings $parameters -ResourceGroup $rg -FunctionAppName $functionName -Slot $functionslot

#or a more manual way -- create the hashtable as you go.

#UpdateAppSettings -AppSettings @{"appsetting1" = "appvalue1"; "appsetting2" = "appvalue2"} `
#    -ResourceGroup $rg -FunctionAppName $functionName -Slot $slot


