function Add-ARMparams([string[]]$masterlist, $paramsfromfile) {
    $returnparams = @()
    $paramsfromfile.PSObject.Properties | foreach-object {
        $name = $_.Name 
        $value = $_.value
        $item = "$name : $value"
        $duplicate = $false
        foreach ($str in $masterlist) {
            if ($item -eq $str) {
                $duplicate = $true
                #write-host "duplicate"
            }
        }
        if (!($duplicate)) {
            $returnparams += $item
            #write-host "item added"
        }
        
    }
    return $returnparams
}


$template_file1 = "C:\Source\SCM-Powershell\POC-Testing\ARMTemplate\function.json"
$template_file2 = "C:\Source\SCM-Powershell\POC-Testing\ARMTemplate\storageAccount.json"

$template1 = Get-Content -Raw -Path $template_file1 | ConvertFrom-Json
$template2 = Get-Content -Raw -Path $template_file2 | ConvertFrom-Json

$ARM = @()

$ARM += "{"
$ARM += '"$schema": "https://schema.management.azure.com/schemas/2015-01-01/deploymentTemplate.json#",'
$ARM += '"contentVersion": "1.0",'
$ArARMm += '"parameters": {'

$ARMparams = @()
$ARMparams += Add-ARMparams -masterlist $ARMparams -paramsfromfile $template1.parameters
$ARMparams += Add-ARMparams -masterlist $ARMparams -paramsfromfile $template2.parameters
$ARM += '"parameters": {' + $ARMparams + "},"
$ARMparams








#$ARMparams += Add-ARMparams -masterlist $ARMparams -paramsfromfile $template2.parameters


$Arm | Out-file -FilePath ".\arm.json"