$subs = Get-AzureRmSubscription

$file = ".\AppList.csv"

$allapps = @()
foreach ($sub in $subs) {
    write-host "Subscription: " -NoNewline -ForegroundColor Red
    write-host  $sub.Name -ForegroundColor Green
    $hide = Select-AzureRmSubscription $sub.id
    $webs = Get-AzureRmWebApp
    foreach($web in $webs) {
        if (!([string]::IsNullOrEmpty($web.HostingEnvironmentProfile.Name))) {
            $appName = $web.Name
            $aseName = ($web.HostingEnvironmentProfile.Name).tostring()
            #$aseInfo = Get-AzureRmResource -name $aseName

           # $rgName = $aseInfo.ResourceGroupName
            if (!([string]::IsNullOrEmpty($web.Tags.BILLINGCODE))) {
                $billingcode = $web.Tags.BILLINGCODE
            }
            else {
                $billingcode = "none"
            }
            $myObject = New-Object System.Object
            $myObject | Add-Member -type NoteProperty -name AppName -Value $appName
            $myObject | Add-Member -type NoteProperty -name AseName -Value $aseName
            $myObject | Add-Member -type NoteProperty -name BillCode -Value $billingcode
            $myObject | Add-Member -type NoteProperty -name ResourceGroup -Value "placeholder"
            $myObject | Add-Member -type NoteProperty -name subscription -Value $sub
            write-host "AppServiceName: " -NoNewline -ForegroundColor Yellow
            write-host $appName -ForegroundColor Green
            write-host "ASE Name: " -NoNewline -ForegroundColor Yellow
            write-host $aseName -ForegroundColor Green
            write-host "ASE RG: " -NoNewline -ForegroundColor Yellow
            write-host "placeholder" -ForegroundColor Green
            write-host "BillingCode: " -NoNewline -ForegroundColor Yellow
            write-host $billingcode -ForegroundColor Green
            write-host
        }
        
        #$AppInfo.GetEnumerator() | ConvertTo-Csv -NoTypeInformation
        $allapps += $myObject
    }
    $myObject | Export-Csv -Path '.\file.csv'
    
}
write-host "App Scan finished" -ForegroundColor Blue
$aselist = @()
$aseobjects = @()
foreach ($app in $allapps) {
    if ($aselist -notcontains $app.AseName) {
        write-host ("Adding ASE " + $app.AseName + " to list")
        $hide = Select-AzureRmSubscription $app.subscription
        $aselist += $app.AseName
        $aseInfo = get-azurermResource -Name $app.AseName
        $myObject = New-Object System.Object
        $myObject | Add-Member -type NoteProperty -name AseName -Value $app.AseName
        $myObject | Add-Member -type NoteProperty -name ResourceGroup -Value $aseInfo.ResourceGroupName
        $aseobjects += $myObject 
    }
}


$allapps | ForEach-Object {
    foreach($obj in $aseobjects) {
        if ($obj.AseName -eq $_.AseName) {
            $_.ResourceGroup = $obj.ResourceGroup
        }

    }
}
$allapps | Export-Csv -Path '.\TagsForAses2.csv'
