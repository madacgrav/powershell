[CmdletBinding()]
Param(
    [Parameter(Mandatory = $True)]
    [string]$storageAccountName,
	
    [Parameter(Mandatory = $True)]
    [string]$resourceGroupName,

    [Parameter(Mandatory = $True)]
    [string]$keyVaultName,

    [Parameter(Mandatory = $False)]
    [int]$regenerationPeriodDays,

    [Parameter(Mandatory = $False)]
    [string]$StorageAccountKey,

    [Parameter(Mandatory = $True)]
    [string]$operation
)
if (!$regenerationPeriodDays) { $regenerationPeriodDays = 1 }
if (!$StorageAccountKey) { $StorageAccountKey = "key2" }

$regenerationPeriod = New-TimeSpan -Days $regenerationPeriodDays
$storageAccountId = (Get-AzureRmStorageAccount -Name $StorageAccountName -ResourceGroupName $resourceGroupName).Id
#$storageAccountId = (Get-AzureRmResource | Where-Object {($_.ResourceGroupName -eq "$resourceGroupName") -and ($_.ResourceType -eq "Microsoft.Storage/storageAccounts") -and ($_.Name -eq "$StorageAccountName")}).ResourceId

if ($operation -eq 'add') {
    $keyCheck = Get-AzureKeyVaultManagedStorageAccount -VaultName $keyVaultName -AccountName $StorageAccountName -ErrorAction SilentlyContinue
    if (!$keyCheck) {
        Write-Host "Creating Azure KeyVault Managed Storage Account, Account Name:" $StorageAccountName
        Add-AzureKeyVaultManagedStorageAccount -VaultName $keyVaultName -AccountResourceId $storageAccountId -AccountName $StorageAccountName -ActiveKeyName $StorageAccountKey -RegenerationPeriod $regenerationPeriod
    }
    else {
        Write-Host "Azure KeyVault Managed Storage Account exists, Account Name:" $StorageAccountName
    }
}
elseif ($operation -eq 'update') {
    throw "Feature is not implemented yet"
}
elseif ($operation -eq 'remove') {
    throw "Feature is not implemented yet"
}
else {
    throw "operation is incorrect, use add, update or remove"
}