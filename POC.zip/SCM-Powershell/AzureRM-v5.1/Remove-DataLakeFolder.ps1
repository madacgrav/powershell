[CmdletBinding()]
Param(
   # [Parameter(Mandatory = $True)]
    #[ValidateScript({Test-Path $_})]
    [string]$csvFile = "C:\!IT\RemovePermissions.csv",
    [string]$datalakeName = "dslabadlssbx.azuredatalakestore.net"
)

$entries = Import-Csv $csvFile

foreach ($entry in $entries) {
   if (Test-AzureRmDataLakeStoreItem -AccountName $datalakeName -Path $entry.Path) {
        $acls = Get-AzureRmDataLakeStoreItemAclEntry -Account $datalakeName -Path $entry.Path
        $permFound = $false
        foreach ($acl in $acls) {
            if ($acl.Id -eq $entry.ObjectID) {
                $permFound = $true
                try {
                    write-host "Path : " $entry.path
                    write-host "Removing ACL from datalake"
                    switch ($acl.Type) {
                        "User" {
                            if ($entry.recurse -eq "TRUE") {
                                Remove-AzureRmDataLakeStoreItemAclEntry -AccountName $datalakeName -Path $entry.Path -AceType User -Id $entry.ObjectID -Recurse
                            }
                            else {
                                Remove-AzureRmDataLakeStoreItemAclEntry -AccountName $datalakeName -Path $entry.Path -AceType User -Id $entry.ObjectID
                            }
                        } 
                        "Group" {
                            if ($entry.recurse -eq "TRUE") {
                                Remove-AzureRmDataLakeStoreItemAclEntry -AccountName $datalakeName -Path $entry.Path -AceType Group -Id $entry.ObjectID -Recurse
                            }
                            else {
                                Remove-AzureRmDataLakeStoreItemAclEntry -AccountName $datalakeName -Path $entry.Path -AceType Group -Id $entry.ObjectID
                            }
                        }
                    }
                }
                catch {
                    throw $_.Exception.Message
                }
                $acl
            }
        }
        if (-not ($permfound)) {
            write-host $entry.ObjectdId "not found"
        }
   }
   else {
        throw ( "Invalid path: " + $entry.Path + " or invalid datalake name " + $datalakeName)
   }
}