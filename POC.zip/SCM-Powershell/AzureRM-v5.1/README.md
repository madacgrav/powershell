# Introduction 
This folder is for scripts that use the AzureRM commands and should be Powershell (normal) scripts

Powershell 5.1 or below