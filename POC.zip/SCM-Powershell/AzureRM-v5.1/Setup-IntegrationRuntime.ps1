$ResourceGroupName = "AZRG-ENA-DASDSLAB-DEV"
$SharedDataFactoryName = "ddslabdf-eus2"
$SharedIntegrationRuntimeName = "ddslab-onpremiseir"
$secondDataFactoryName = "ddslabdf2-eus2"
$LinkedIntegrationRuntimeDescription = "dev ddslab-onpremiseirIntegration Runtime Engine"

$factory = Get-AzureRmDataFactoryV2 -ResourceGroupName $ResourceGroupName -Name $secondDataFactoryName
Get-AzureRmDataFactoryV2IntegrationRuntimeKey -ResourceGroupName $ResourceGroupName -DataFactoryName $SharedDataFactoryName -Name $SharedIntegrationRuntimeName
$SharedIR = Get-AzureRmDataFactoryV2IntegrationRuntime -ResourceGroupName $ResourceGroupName -DataFactoryName $SharedDataFactoryName -Name $SharedIntegrationRuntimeName



#New-AzureRmRoleAssignment -ObjectId $factory.Identity.PrincipalId -RoleDefinitionId 'b24988ac-6180-42a0-ab88-20f7382dd24c' -Scope $SharedIR.Id

Set-AzureRmDataFactoryV2IntegrationRuntime `
    -ResourceGroupName $ResourceGroupName `
    -DataFactoryName $secondDataFactoryName `
    -Name $SharedIntegrationRuntimeName `
    -Type SelfHosted `
    -SharedIntegrationRuntimeResourceId $SharedIR.Id `
    -Description $LinkedIntegrationRuntimeDescription