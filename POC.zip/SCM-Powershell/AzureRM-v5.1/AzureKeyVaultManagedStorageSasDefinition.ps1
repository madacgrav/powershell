[CmdletBinding()]
Param(
    [Parameter(Mandatory = $True)]
    [string]$storageAccountName,
	
    [Parameter(Mandatory = $True)]
    [string]$keyVaultName,

    [Parameter(Mandatory = $True)]
    [string]$sasDefinitionName,

    [Parameter(Mandatory = $True)]
    [ValidateSet("Blob", "File", "Queue", "Table")]
    [string[]]$storageAccountService,
    
    [Parameter(Mandatory = $True)]
    [ValidateSet("Service", "Container", "Object")]
    [string[]]$storageAccountResourceType,

    [Parameter(Mandatory = $True)]
    [ValidateSet("Add", "Create", "Delete", "List", "Process", "Read", "Query", "Update", "Write")]
    [string[]]$sasPermissions,

    [Parameter(Mandatory = $False)]
    [int]$regenerationPeriodDays,

    [Parameter(Mandatory = $True)]
    [string]$variableSubstituteName,

    [Parameter(Mandatory = $True)]
    [string]$operation
)
if (!$regenerationPeriodDays) { $regenerationPeriodDays = 1 }

$regenerationPeriod = New-TimeSpan -Days $regenerationPeriodDays

if ($operation -eq 'set') {
        Write-Host "Creating Azure KeyVault Managed SAS Defintion Key, Key Name:" $sasDefinitionName
        Set-AzureKeyVaultManagedStorageSasDefinition -Service $storageAccountService -ResourceType $storageAccountResourceType -VaultName $keyVaultName -AccountName $StorageAccountName -Name $sasDefinitionName -Protocol HttpsOnly -ValidityPeriod $regenerationPeriod -Permission $sasPermissions
        $sasSecretId = (Get-AzureKeyVaultManagedStorageSasDefinition -VaultName $keyVaultName -AccountName $StorageAccountName -Name $sasDefinitionName).Sid
        Write-Output ("##vso[task.setvariable variable=$variableSubstituteName;]$sasSecretId")
}
elseif ($operation -eq 'remove') {
    throw "Feature is not implemented yet"
}
else {
    throw "operation is incorrect, use set, or remove"
}