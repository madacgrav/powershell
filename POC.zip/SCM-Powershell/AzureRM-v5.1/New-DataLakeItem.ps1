[CmdletBinding()]
Param(
    # [Parameter(Mandatory = $True)]
    #[ValidateScript({Test-Path $_})]
    [string]$csvFile = "C:\!IT\NewItem.csv",
    [string]$datalakeName = "dslabadlssbx.azuredatalakestore.net"
)

$entries = Import-Csv $csvFile

foreach ($entry in $entries) {
    if (-Not (Test-AzureRmDataLakeStoreItem -AccountName $datalakeName -Path $entry.Item)) {
        try {
            if ($entry.Type -eq "Folder") {
                New-AzureRmDataLakeStoreItem -AccountName $datalakeName -Path $entry.Item -Folder
            }
            else {
                New-AzureRmDataLakeStoreItem -AccountName $datalakeName -Path $entry.Item
            }
        }
        catch {
           throw $_.Exception.Message
        }
    }
    else {
        throw ( "Item already exists : " + $entry.Item + " or invalid datalake name " + $datalakeName)
    }
}