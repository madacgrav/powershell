# Introduction 
This folder is for scripts that use the AZ commands and should be Powershell Core scripts

Powershell 6 or above.