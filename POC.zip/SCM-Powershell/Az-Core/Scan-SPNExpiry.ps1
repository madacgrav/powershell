
function Post-Teams ($bodytext) {
    $webhook = 'https://outlook.office.com/webhook/d1beb2fd-a894-468d-9dea-6994897a12c0@36da45f1-dd2c-4d1f-af13-5abe46b99921/IncomingWebhook/5464fb3d70874e829f5b05372c9c6cd7/7c5c8193-dd8c-4774-b312-77b6b1360e56'
    $formattedBody = @{
        'text' = $bodytext
    }
    $params = @{
        Headers = @{'accept' = 'application/json' }
        Body    = $formattedBody | convertto-json
        Method  = 'Post'
        URI     = $webhook 
    }
    $api = Invoke-RestMethod @params
}

$kvList = @(
    @{
        functionName = "CONSULTING"
        kvName = "consult-kv-preprod-eus"
        kvsubscription = "US_CONSULTING_PREPROD"
    },
    @{
        functionName = "CONSULTING"
        kvName = "consult-kv-prod-eus"
        kvsubscription = "US_CONSULTING_PROD"
    }#,
    # @{
    #     functionName = "ENABLING_AREAS"
    #     kvName = "enabling-kv-preprod-eus"
    #     kvsubscription = "US_ENABLING_AREAS_PREPROD"
    # },
    # @{
    #     functionName = "ENABLING_AREAS"
    #     kvName = "enabling-kv-prod-eus"
    #     kvsubscription = "US_ENABLING_AREAS_PROD"
    # },
    # @{
    #     functionName = "ADVISORY"
    #     kvName = "advisory-kv-preprod-eus"
    #     kvsubscription = "US_ADVISORY_PREPROD"
    # },
    # @{
    #     functionName = "ADVISORY"
    #     kvName = "advisory-kv-prod-eus"
    #     kvsubscription = "US_ADVISORY_PROD"
    # },
    # @{
    #     functionName = "TAX"
    #     kvName = "tax-kv-preprod-eus"
    #     kvsubscription = "US_TAX_PREPROD"
    # },
    # @{
    #     functionName = "TAX"
    #     kvName = "tax-kv-prod-eus"
    #     kvsubscription = "US_TAX_PROD"
    # }
)

foreach ($kv in $kvList) {
    try {
        Select-AzSubscription -SubscriptionName $kv.kvsubscription
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        write-host ("Error !! - " + $ErrorMessage)
    }
    try {
        $KeyVault = Get-AzKeyVault  -VaultName $kv.kvName
        $AllKeyVaultSecrets = $KeyVault | Get-AzKeyVaultSecret -Name "AppReg*"
        $link = "https://portal.azure.com/#@deloitte.onmicrosoft.com" + $KeyVault.ResourceID + "/secrets"
        $kvName = $kv.kvName
        $teamstext = "<table><th>Expired AppReg/SPNs for <a href='$link'>$kvName </a></th><tr><td><b>Name</b></td><td><b>Expire Date</b></td></tr>"
        $expiredcertsfound = $false
        foreach ($KeyVaultSecret in $AllKeyVaultSecrets) {
            $KeyVaultSecretName = $KeyVaultSecret.Name
            $KeyVaultSecretEnabled = $KeyVaultSecret.Enabled
            $KeyVaultSecretExpiryDate = $KeyVaultSecret.expires
#            if (($KeyVaultSecretExpiryDate -lt ((Get-Date).AddDays($expirationtime))) -and $KeyVaultSecretEnabled -and $KeyVaultSecretExpiryDate) {
                $teamstext += "<tr><td>$KeyVaultSecretName</td><td>$KeyVaultSecretExpiryDate</td></tr>"
                $expiredcertsfound = $true
 #           }
        }
        $teamstext += "</table>"
        if ($expiredcertsfound) {
            Post-Teams -bodytext $teamstext
        }
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        write-host ("Error !! - " + $ErrorMessage)
    }
}

