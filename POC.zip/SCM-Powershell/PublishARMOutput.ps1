[CmdletBinding()]
Param(
    [Parameter(Mandatory = $True)]
    [String]$variables,

    [Parameter(Mandatory = $false)]
    [String]$substituteVariablejsonConfigFile
)

#Convert ARM template output json to VSTS variables
$variablesHash = @{}
($Variables | ConvertFrom-Json).psobject.properties | Foreach { $variablesHash[$_.Name] = $_.Value.value }
$variablesHash.GetEnumerator() | ForEach-Object {
    $variableName = $_.Name
    $variableValue = $_.Value

    Write-verbose "Creating new variable: $variableName $variableValue"
    Write-Output ("##vso[task.setvariable variable=$variableName;]$variableValue")
}

#Subtitute VSTS variables with the output values of the ARM template outputs
if ($substituteVariablejsonConfigFile) {
    $substituteVariablejsonConfig = Get-Content $substituteVariablejsonConfigFile | Out-String

    ($substituteVariablejsonConfig | ConvertFrom-Json).psobject.properties | Foreach { 
        $substitutevariableName = $_.Value.armOutputVariable
    
        $tempVariableHash = $variablesHash.GetEnumerator() | Where-Object {$_.Name -eq $substitutevariableName}

        $substitutevariableName = $_.Value.substituteVariable
        $substitutevariableValue = $tempVariableHash.Value

        Write-verbose "Creating new variable: $substitutevariableName $substitutevariableValue"
        Write-Output ("##vso[task.setvariable variable=$substitutevariableName;]$substitutevariableValue")
    }
}

