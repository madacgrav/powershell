﻿[CmdletBinding()]
Param(
    [string]$region = "eastus",
    [string]$function = "SVC",
    [string]$RGNameSeqNo = "002",
    [string]$subId = "e8d1eb9b-46cf-46b0-9b02-3e133288c4ef",
    [string]$Friendlyname = "AdamTest",
    [string]$env = "DEV"
)
function Get-Token () {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    ### Get Token
    $secretKVsubid = "bfc7eac2-0d08-4251-921e-5fe25ba65b98"
    $tokenobj = @{}
    try {
        $subinfo = Select-AzSubscription $secretKVsubid
        write-host "Getting auth token to query API" -ForegroundColor Blue
        $client_Id = 'f9dd81aa-288d-405c-824e-37e7f3328fb1'
        $client_Secret =  Get-AzKeyVaultSecret -VaultName "enabling-kv-prod-eus" -Name "SPN-US-DAS-SCM-OneCloudAPI-Client-PROD"
        $resource_id = '9f11e6db-715d-45a7-887e-01e00b9bc968'
        $requestBody = "client_id=$client_id&client_secret=$($client_Secret.SecretValueText)&grant_type=client_credentials&resource=$resource_id"
        $req = Invoke-RestMethod -Uri "https://login.microsoftonline.com/36da45f1-dd2c-4d1f-af13-5abe46b99921/oauth2/token" -Method Post -Body $requestBody -ContentType "application/x-www-form-urlencoded"
        #return $req.access_token
        $authtoken = $req.access_token
        $tokenobj = @{
            status = "success"
            response = $authtoken
        }
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        Write-Error $ErrorMessage -ForegroundColor Red
         $tokenobj = @{
             status = "failure"
             response = $ErrorMessage
         }
    }
    $o = New-Object psobject -Property $tokenobj; $o
    return $tokenobj
}

$ErrorActionPreference = "Stop"

$reqBody= @"
{
    "SubscriptionId":"$($subId)",
    "RGNameSeqNo":"$($RGNameSeqNo)",
    "Region":"$($region)",
    "Function":"$($function)",
    "Friendlyname":"$($Friendlyname)",
    "Tags": {
        "GROUPCONTACT":"usscmplatformmgmt@deloitte.com",
        "PRIMARYCONTACT":"ahaliburton@deloitte.com",
        "SECONDCONTACT":"usscmplatformmgmt@deloitte.com",
        "BUSINESSOWNER":"smcqueen@deloitte.com",
        "APPID":"CI45391308",
        "CLASSIFICATION": "CON",
        "TYPE": "Deloitte",
        "QUALIFIER": "Intellectual Property",
        "ENVIRONMENT": "$($env)",
        "BILLINGCODE" : "TPX00553-01-01-AZ-5619"
    },
    "RoleAssignments": [
            { "Role":"Contributor", "Principal":"SG-US SCM PM"},
    ],
    "NotifyTo": ["kevjordan@deloitte.com"]
}
"@


$baseUri = "https://onecloudapi.deloitte.com"
$rgApi= $baseUri + "/resourcegroup/20190815/CreateResourceGroup_HttpStart"
$token = Get-Token
if($token[0].status -eq "success") {
    $subinfo = Select-AzSubscription $subId
    $Headers = @{"Authorization"="$($token[0].response)"}
    write-verbose $token[0].response
    write-host "Attempting to create RG" -ForegroundColor Blue
    try {
        $req = Invoke-RestMethod -Uri $rgApi -Method Post -Body $reqBody -Headers $Headers
        write-host "Resource Group creation request sent." -ForegroundColor Green
        $stopwatch =  [system.diagnostics.stopwatch]::StartNew()
        do {
            $rg = Get-AzResourceGroup -Name ($req.resourceGroupName + "*")
            write-verbose ("Time elapsed: " + $stopwatch.Elapsed.TotalSeconds)
            Start-Sleep -Seconds 5
        }while (($stopwatch.Elapsed.TotalSeconds -lt 120) -and !($rg))
        if ($rg) {
            write-host "Resource Group validated." -ForegroundColor Green
        }
        else {
            write-host "Resource Group validation timedout." -ForegroundColor Red
        }
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        write-host "Request failed." -ForegroundColor Red
        write-host $ErrorMessage -ForegroundColor Red
    }
}
else {
    write-host $token.response
}







