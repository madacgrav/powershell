
$templateParameterObject = @{
    priority              = 1
    trafficManagerDnsName = "dev-alex2-tm"
    EndpointLocation      = "East Us"
    EndpointTarget        = "www.google.com"
}

$splatNewAzRgDeployment = @{
    ResourceGroupName       = "AZRG-USE-SVC-ADAMTEST-DEV-001"
    TemplateFile            = ".\TrafficManagerEndPoint.json"
    TemplateParameterObject = $templateParameterObject        
}

Test-AzureRmResourceGroupDeployment -ResourceGroupName "AZRG-USE-SVC-ADAMTEST-DEV-001" -TemplateFile ".\TrafficManagerEndPoint.json" -TemplateParameterObject $templateParameterObject 