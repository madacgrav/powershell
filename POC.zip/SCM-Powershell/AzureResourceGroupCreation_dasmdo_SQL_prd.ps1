﻿$reqBody= @"
{
                "SubscriptionId":"b92be06b-7b5e-41fb-8c61-faae8e3eef28",
                "RGNameSeqNo":"SQL",
                "Region":"eastus",
                "Function":"SVC",
                "Friendlyname":"DASMDO",
                "Tags": {
                                "GROUPCONTACT":"usscmplatformmgmt@deloitte.com",
                                "PRIMARYCONTACT":"ahaliburton@deloitte.com",
                                "SECONDCONTACT":"usscmplatformmgmt@deloitte.com",
                                "BUSINESSOWNER":"smcqueen@deloitte.com",
                                "APPID":"CI45391308",
                                "CLASSIFICATION": "CON",
                                "TYPE": "Deloitte",
                                "QUALIFIER": "Intellectual Property",
                                "ENVIRONMENT": "PRD",
                                "BILLINGCODE" : "TPX00553-01-01-AZ-5619"
    },
    "RoleAssignments": [
                                { "Role":"Contributor", "Principal":"SG-US SCM PM"},
    ],
   "NotifyTo": ["kevjordan@deloitte.com"]
}



"@

$ErrorActionPreference = "Stop"

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
### Get Token
$baseUri = "https://onecloudapi.deloitte.com"
$client_Id = 'f9dd81aa-288d-405c-824e-37e7f3328fb1'
$client_Secret =  Get-AzureKeyVaultSecret -VaultName "enabling-kv-prod-eus" -Name "SPN-US-DAS-SCM-OneCloudAPI-Client-PROD"
$resource_id = '9f11e6db-715d-45a7-887e-01e00b9bc968'

$requestBody = “client_id=$client_id&client_secret=$($client_Secret.SecretValueText)&grant_type=client_credentials&resource=$resource_id"
$req = Invoke-RestMethod -Uri "https://login.microsoftonline.com/36da45f1-dd2c-4d1f-af13-5abe46b99921/oauth2/token" -Method Post -Body $requestBody -ContentType “application/x-www-form-urlencoded”

if($($req.access_token) -eq $null) {
    Write-Error "Did not get token"
    return
}
$Headers = @{"Authorization"="$($req.access_token)"}



### Create RG

$rgApi= $baseUri + "/resourcegroup/20190815/CreateResourceGroup_HttpStart"
$req = Invoke-RestMethod -Uri $rgApi -Method Post -Body $reqBody -ContentType “application/json” -Headers $Headers





### Poll Status

$instanceId = $req.instanceId
$statusApi = $baseUri + "/bot/20190515/Orchestrator/" + $instanceId


$stopwatch =  [system.diagnostics.stopwatch]::StartNew()
while ($stopwatch.Elapsed.TotalSeconds -lt 120) {
    Write-Output("`n Polling status API...........")
    $req = Invoke-RestMethod -Uri $statusApi -Method Get -Headers $Headers
    $req
    if($req.isCompleted -like "true"){ 
        return
    }

    Start-Sleep -Seconds 5
}