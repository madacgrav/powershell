$subs = Get-AzureRmSubscription

$file = ".\AppList.csv"

$allsubInfo = @()
foreach ($sub in $subs) {
    write-host "Subscription: " -NoNewline -ForegroundColor Red
    write-host  $sub.Name -ForegroundColor Green
    $hide = Select-AzureRmSubscription $sub.id
    $rgs = Get-AzureRmResourceGroup
    $allRGInfo = @()
    foreach ($rg in $rgs) {
        write-host "ResourceGroup : " -NoNewline -ForegroundColor Blue
        write-host $rg.ResourceGroupName -ForegroundColor Green
        $resources = Get-AzureRmResource | Where-Object {$_.ResourceGroupName -eq $rg.ResourceGroupName}
        foreach ($resource in $resources) {
            write-host "Name: " -NoNewline -ForegroundColor Yellow
            write-host $resource.Name -ForegroundColor Green
            if (!([string]::IsNullOrEmpty($resource.Tags.BILLINGCODE))) {
                $billingcode = $resource.Tags.BILLINGCODE
            }
            else {
                $billingcode = "none"
            }
            write-host "BillingCode: " -NoNewline -ForegroundColor Yellow
            write-host $billingcode -ForegroundColor Green
            $myObject = New-Object System.Object
            $myObject | Add-Member -type NoteProperty -name ResourceGroup -Value $rg.ResourceGroupName
            $myObject | Add-Member -type NoteProperty -name Name -Value $resource.Name
            $myObject | Add-Member -type NoteProperty -name Type -Value $resource.ResourceType
            $myObject | Add-Member -type NoteProperty -name BillCode -Value $billingcode
            $myObject | Add-Member -type NoteProperty -name subscription -Value $sub.Name
        }
       # $myObject
        $allRGInfo += $myObject
    }
   # $allRGInfo
    $allRGInfo | Export-Csv -Path '.\TagsForOneSub.csv'
    $allsubInfo += $allRGInfo
}

$allsubInfo | Export-Csv -Path '.\TagsForAllSubs.csv'

