param (
    $prdurl = "ascm.deloitte.com",
    $projectcode = "dcm",
    $functioncode = "con",
    $primaryregion = "eus",
    [string[]]$envs = ("d","q","l","s","p", "b")
)


#resource group names, names for cert SAN, cert name, name of ARM repo, create ARM repo, get ASE ips, generate CSRs, create spreadsheet for internal dns request

function Genereate-RGNames ([string]$project, [string]$function) {
    $rgs = @()
    foreach ($env in $envs) {
        switch ($env) {
            "d" {
                $rgs += "azrg-" + $function + "-das" + $project + "-dev"
            }
            "q" {
                $rgs += "azrg-" + $function + "-das" + $project + "-qas"
            }
            "l" {
                $rgs += "azrg-" + $function + "-das" + $project + "-loa"
            }
            "s" {
                $rgs += "azrg-" + $function + "-das" + $project + "-stg"
            }
            "p" {
                $rgs += "azrg-" + $function + "-das" + $project + "-prd"
            }
            "b" {
                $rgs += "azrg-" + $function + "-das" + $project + "-bcp"
            }
        }
    }
    return $rgs
}


function Create-CSR ([string]$certificateName, [string]$certificateCommonName, [string[]]$certificateSan, [string]$filename, [string]$VaultName) {
    #need to add Azure login and set the correct subscription
    

    $certificateSan += $certificateCommonName
    $certificateSubjectName = "CN=" + $certificateCommonName + ",OU=SCM,O=Deloitte and Touche LLP,l=Hermitage,S=Tennessee,C=US"
    $CertificateLength = "24"
  
    #Create the cert policy variable
    if ($certificateSan)
    {           
        $manualPolicy = New-AzureKeyVaultCertificatePolicy -SubjectName $certificateSubjectName -DnsNames $certificateSan -ValidityInMonths $CertificateLength -ReuseKeyOnRenewal -EmailAtNumberOfDaysBeforeExpiry 30 -IssuerName Unknown 
    }
    elseif (!$certificateSan)
    {
        $manualPolicy = New-AzureKeyVaultCertificatePolicy -SubjectName $certificateSubjectName -ValidityInMonths $CertificateLength -ReuseKeyOnRenewal -EmailAtNumberOfDaysBeforeExpiry 30 -IssuerName Unknown 
    }
    #Create the empty cert with the policy settings above (Need Try and Catch)
    try {
        $certificateOperation = Add-AzureKeyVaultCertificate -VaultName $VaultName -Name $certificateName -CertificatePolicy $manualPolicy

        $csr = "-----BEGIN CERTIFICATE REQUEST-----`n" + $certificateOperation.CertificateSigningRequest + "`n-----END CERTIFICATE REQUEST-----"
        
        $csr | Out-File -FilePath $filename
    
        write-Output "`nCertificate Information - Keep for your records" $manualPolicy | Format-List @{Expression={$certificateName};Label="Certificate Name"},@{Expression={$_.SubjectName};Label="Subject Name"}, @{Expression={$_.KeySize};Label="Key Siz"}, @{Expression={$certificateOperation.RequestId};Label="Request Id"}
        Write-Output "The CSR has been saved to a file`n"
    
        Clear-Variable certificateName, certificateCommonName, certificateSan, CertificateLocality, CertificateLength, certificateSubjectName, manualPolicy, certificateOperation, csr

    }
    catch {
        $ErrorMessage = $_.Exception.Message
        write-host ("Error with CSR generation !! - " + $ErrorMessage)
        exit 1
    }

}


function Genereate-HostNames ([string]$prdurl, [string]$primary_region, [string]$partner_region, [string]$project, [string]$function) {
    $rootappurl = ".app.deloitte.com"
    $rootaseurl = ".ase.deloitte.com"
    $preprodhosts = @()
    $prodhosts = @()
    $stagehosts = @()    
    foreach ($env in $envs) {
        switch -Regex ($env) {
            '[p]' {
                $prodhosts +=  $prdurl
                $prodhosts +=  $project + "-" + $primary_region + "." + $function + $rootappurl
                $prodhosts +=  $project + "-" +  $partner_region + "." + $function + $rootappurl
                $prodhosts +=  $project + "-" + $primary_region + ".scm." + $function + $rootaseurl
                $prodhosts +=  $project + "-" +  $partner_region + ".scm." + $function + $rootaseurl
            }
            '[s]' {
                $stagehosts += $env + $prdurl
                $stagehosts += $env + $project + "-" + $primary_region + "." + $function + $rootappurl
                $stagehosts += $env + $project + "-" +  $partner_region + "." + $function + $rootappurl
                $stagehosts += $env + $project + "-" + $primary_region + ".scm." + $function + $rootaseurl
                $stagehosts += $env + $project + "-" +  $partner_region + ".scm." + $function + $rootaseurl
            }
            '[dql]' {
                $preprodhosts += $env + $prdurl
                $preprodhosts += $env + $project + "-" + $primary_region + "." + $function + $rootappurl
                $preprodhosts += $env + $project + "-" + $primary_region + ".scm." + $function + $rootaseurl
            }
        }
    }
    $allhosts = New-Object -TypeName psobject
    $allhosts | Add-Member -MemberType NoteProperty -Name preprod -Value $preprodhosts
    $allhosts | Add-Member -MemberType NoteProperty -Name stage -Value $stagehosts
    $allhosts | Add-Member -MemberType NoteProperty -Name prod -Value $prodhosts
    return $allhosts
}


switch ($primaryregion) {
    "eus" {
        $partnerregion = "wus"
    }
    "wus" {
        $partnerregion = "eus"
    }
    "default" {
        $partnerregion = "wus"
    }
}


switch ($functioncode) {
    "con" {
        $channelName = "Consulting"
    }
    "adv" {
        $channelName = "Advisory"
    }
}


Prompt for login
Try
{
    $login = az login -u "usa-account" -p "usa password"
}
Catch
{
    $ErrorMessage = $_.Exception.Message
    Write-Output "AzureRM Login Failed with error message:" $ErrorMessage -ForegroundColor Red
    Break
}


function Get-ASElbIP ([string]$subName, [string]$rg, [string]$aseName) {
    az account set --subscription $subName
    $subId = az account show --subscription $subName --query "id"
    $subId = $subId.replace('"',"")
    $ip =  az resource show --ids "/subscriptions/$subId/resourceGroups/$rg/providers/Microsoft.Web/hostingEnvironments/$aseName/capacities/virtualip" --query "internalIpAddress"
    $ip = $ip.replace('"',"")
    return $ip
}


$output = ".\NewProject-$projectcode.txt"

"" | Out-FIle -FilePath $output


$armRepo = "ARM-" + $channelName + "-" + $projectcode
"ARM repo name" | Out-FIle -FilePath $output -Append
$armRepo | Out-FIle -FilePath $output -Append
"`n" | Out-FIle -FilePath $output -Append

$SPNGroup = "SG-US " + $projectcode + " Devlopment"
"SPN Group name" | Out-FIle -FilePath $output -Append
$SPNGroup | Out-FIle -FilePath $output -Append
"`n" | Out-FIle -FilePath $output -Append

$resourcegroups = Genereate-RGNames $projectcode $functioncode

"Resource Groups" | Out-FIle -FilePath $output -Append
$resourcegroups | Out-FIle -FilePath $output -Append
"`n" | Out-FIle -FilePath $output -Append

"Certificate Friendly Name" | Out-FIle -FilePath $output -Append
"PreProd" | Out-FIle -FilePath $output -Append
$certName = $functioncode + "-das" + $projectcode + "-preprod-appcert-eus"
$certName | Out-FIle -FilePath $output -Append
"`n" | Out-FIle -FilePath $output -Append

"Prod" | Out-FIle -FilePath $output -Append
$certName = $functioncode + "-das" + $projectcode + "-prod-appcert-eus"
$certName | Out-FIle -FilePath $output -Append
"`n" | Out-FIle -FilePath $output -Append
"Stage" | Out-FIle -FilePath $output -Append
$certName = $functioncode + "-das" + $projectcode + "-stage-appcert-eus"
$certName | Out-FIle -FilePath $output -Append
"`n" | Out-FIle -FilePath $output -Append


$hosts = Genereate-HostNames $prdurl $primaryregion $partnerregion $projectcode $functioncode

"Urls for Certs (ignore SCM names)" | Out-FIle -FilePath $output -Append
"preprod" | Out-FIle -FilePath $output -Append
foreach ($hostname in $hosts.preprod) {
    if ($hostname -notlike "*.scm.*") {
        $hostname| Out-FIle -FilePath $output -Append
    }
}
"`n" | Out-FIle -FilePath $output -Append
"prod" | Out-FIle -FilePath $output -Append
foreach ($hostname in $hosts.prod) {
    if ($hostname -notlike "*.scm.*") {
        $hostname| Out-FIle -FilePath $output -Append
    }
}
"`n" | Out-FIle -FilePath $output -Append
"stage" | Out-FIle -FilePath $output -Append
foreach ($hostname in $hosts.stage) {
    if ($hostname -notlike "*.scm.*") {
        $hostname| Out-FIle -FilePath $output -Append
    }
}

#write-host "Creating CSRs"
#Create-CSR [string]$certificateName, [string]$certificateCommonName, [string[]]$certificateSan, [string]$filename)
"`n" | Out-FIle -FilePath $output -Append
"DNS Requests" | Out-FIle -FilePath $output -Append

"preprod A records:" | Out-FIle -FilePath $output -Append
$preprodASEip = Get-ASElbIP -subName ("US_" + $channelName + "_PREPROD") -rg ("AZRG-" + $functioncode + "-DAS-ASE-PREPROD-EUS") -aseName ($channelName + "-das-ase-preprod-eus")
foreach ($hostname in $hosts.preprod) {
    ($hostname + "   ->  " + $preprodASEip) | Out-FIle -FilePath $output -Append
}
"`n" | Out-FIle -FilePath $output -Append

"stage A records:" | Out-FIle -FilePath $output -Append
$prodASEip = Get-ASElbIP -subName ("US_" + $channelName + "PROD") -rg ("AZRG-" + $functioncode + "DAS-ASE-PROD-EUS") -aseName ($channelName + "-das-ase-prod-eus")
foreach ($hostname in $hosts.stage) {
    ($hostname + "   ->  " + $prodASEip) | Out-FIle -FilePath $output -Append
}
"`n" | Out-FIle -FilePath $output -Append

#$prodASEip = Get-ASElbIP -subName ("US_" + $channelName + "PROD") -rg ("AZRG-" + $functioncode + "DAS-ASE-PROD-EUS") -aseName ($channelName + "-das-ase-prod-eus")
#$bcpASEip = Get-ASElbIP -subName ("US_" + $channelName + "PROD") -rg ("AZRG-" + $functioncode + "DAS-ASE-PROD-WUS") -aseName ($channelName + "-das-ase-prod-wus")