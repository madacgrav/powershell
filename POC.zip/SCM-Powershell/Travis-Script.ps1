$resourceGroupName = 'tmas'
$storageAccountName = 'tmas'
$storageAccountKey = 'key2'
$keyVaultName = 'tmas'
$subscriptionId = "44ab435b-26ff-44f9-baa9-4b06cdbc55de"

$sctx = New-AzureStorageContext -StorageAccountName $storageAccountName -Protocol Https -StorageAccountKey $storageAccountKey
$start = [System.DateTime]::Now.AddDays(-1)
$end = [System.DateTime]::Now.AddDays(1)


New-AzureStorageShareStoredAccessPolicy -ShareName "blue" -Policy "app1Policy" -Permission "r" -Context $sctx
New-AzureStorageShareStoredAccessPolicy -ShareName "app2" -Policy "app2Policy" -Permission "r" -Context $sctx

$sasToken1 = New-AzureStorageShareSASToken -Policy app1Policy -Protocol HttpsOnly -FullUri -ShareName app1 -Context $sctx
$sasToken2 = New-AzureStorageShareSASToken -Policy app2Policy -Protocol HttpsOnly -FullUri -ShareName app2 -Context $sctx
Set-AzureKeyVaultManagedStorageSasDefinition -AccountName $storageAccountName -VaultName $keyVaultName -Name 'rttmasSasWebApp1' -TemplateUri $sasToken1 -SasType 'service' -ValidityPeriod ([System.Timespan]::FromDays(1)) -Verbose
Set-AzureKeyVaultManagedStorageSasDefinition -AccountName $storageAccountName -VaultName $keyVaultName -Name 'rttmasSasWebApp2' -TemplateUri $sasToken2 -SasType 'service' -ValidityPeriod ([System.Timespan]::FromDays(1)) -Verbose


$sasTokenFile1 = New-AzureStorageFileSASToken -ShareName test -Path app1 -Permission 'rlwcd' -StartTime $start -ExpiryTime $end -Protocol HttpsOnly -Context $sctx -FullUri
$sasTokenFile2 = New-AzureStorageFileSASToken -ShareName test -Path app2 -Permission 'rlwcd' -StartTime $start -ExpiryTime $end -Protocol HttpsOnly -Context $sctx -FullUri
Set-AzureKeyVaultManagedStorageSasDefinition -AccountName $storageAccountName -VaultName $keyVaultName -Name 'rttmasSasWebTestApp1' -TemplateUri $sasTokenFile1 -SasType 'service' -ValidityPeriod ([System.Timespan]::FromDays(1)) -Verbose
Set-AzureKeyVaultManagedStorageSasDefinition -AccountName $storageAccountName -VaultName $keyVaultName -Name 'rttmasSasWebTestApp2' -TemplateUri $sasTokenFile2 -SasType 'service' -ValidityPeriod ([System.Timespan]::FromDays(1)) -Verbose

Get-AzureKeyVaultManagedStorageSasDefinition -VaultName $keyVaultName 


Set-AzureRmKeyVaultAccessPolicy -VaultName $keyVaultName -UserPrincipalName $azureProfile.Context.Account.Id -PermissionsToStorage get, list, listsas, delete, set, update, regeneratekey, recover, backup, restore, purge, setsas
Set-AzureRmKeyVaultAccessPolicy -VaultName $keyVaultName -UserPrincipalName $azureProfile.Context.Account.Id -PermissionsToStorage get, list, delete, set, update, regeneratekey, getsas, listsas, deletesas, setsas, recover, backup, restore, purge