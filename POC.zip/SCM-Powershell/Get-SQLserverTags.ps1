$subs = Get-AzureRmSubscription

$file = ".\AppList.csv"

$allSQLinfoInfo = @()
foreach ($sub in $subs) {
    Write-Host "Subscription: " -NoNewline -ForegroundColor Red
    Write-Host  $sub.Name -ForegroundColor Green
    $hide = Select-AzureRmSubscription $sub.id
    $sqlServers = Get-AzureRmSqlServer
    $sqlRGINfo = @()
    foreach ($sql in $sqlServers) {
        Write-Host "ResourceGroup: " -NoNewline -ForegroundColor Blue
        Write-Host  $sql.ResourceGroupName -ForegroundColor Green
        Write-Host "SQL Server Name: " -NoNewline -ForegroundColor Yellow
        Write-Host $sql.ServerName -ForegroundColor Green
        $rgresources  = Get-AzureRmResource -ResourceGroupName $sql.ResourceGroupName
        $resourceInfo = @()
        foreach ($resource in $rgresources) {
            if ($resource.ResourceType -ne "Microsoft.Sql/servers") {
                if (!([string]::IsNullOrEmpty($resource.Tags.BILLINGCODE))) {
                    $billingcode = $resource.Tags.BILLINGCODE
                }
                else {
                    $billingcode = "none"
                }
                write-host "Name: " -NoNewline -ForegroundColor Yellow
                write-host $resource.Name -ForegroundColor Green
                write-host "BillingCode: " -NoNewline -ForegroundColor Yellow
                write-host $billingcode -ForegroundColor Green
                write-host "Type: " -NoNewline -ForegroundColor Yellow
                write-host $resource.ResourceType -ForegroundColor Green
                $myObject1 = New-Object System.Object
                $myObject1 | Add-Member -type NoteProperty -name Name -Value $resource.Name
                $myObject1 | Add-Member -type NoteProperty -name BillCode -Value $billingcode
                $myObject1 | Add-Member -type NoteProperty -name ResourceGroupName -Value $sql.ResourceGroupName
                #$myOjbect1 | Add-Member -type NoteProperty -name RGType -Value "Not SQL"
                $myObject1| Add-Member -type NoteProperty -name subscription -Value $sub.Name
                $resourceInfo += $myObject1
            }
        }
        $allSQLinfoInfo += $resourceInfo
        if (!([string]::IsNullOrEmpty($sql.Tags.BILLINGCODE))) {
            $billingcode = $sql.Tags.BILLINGCODE
        }
        else {
            $billingcode = "none"
        }
        Write-Host "ResourceGroup: " -NoNewline -ForegroundColor Yellow
        Write-Host $sql.ResourceGroupName -ForegroundColor Green
        Write-Host "BillingCode: " -NoNewline -ForegroundColor Yellow
        Write-Host $billingcode -ForegroundColor Green
        $myObject = New-Object System.Object
        $myObject | Add-Member -type NoteProperty -name Name -Value $sql.ServerName
        $myObject | Add-Member -type NoteProperty -name BillCode -Value $billingcode
        $myObject | Add-Member -type NoteProperty -name ResourceGroupName -Value $sql.ResourceGroupName
        #$myOjbect | Add-Member -type NoteProperty -name RGType -Value "SQL Server"
        $myObject | Add-Member -type NoteProperty -name subscription -Value $sub.Name
        $sqlRGINfo += $myObject
    }
    $allSQLinfoInfo += $sqlRGINfo
}

$allSQLinfoInfo | Export-Csv -Path '.\TagsForAllSQL.csv'

