

$uri = "https://management.azure.com/subscriptions/0e9717d5-1108-4e40-9243-ed45faa93751/resourceGroups/AZRG-CON-DAS-ASE-PREPROD-EUS/providers/Microsoft.Web/hostingEnvironments/consulting-das-ase-preprod-eus?api-version=2016-09-01"
Write-Host "URL: $uri"

$kv = "consult-kv-preprod-eus"
$rg = "AZRG-CON-KV-PREPROD-EUS"
$sub = "0e9717d5-1108-4e40-9243-ed45faa93751"

$uri = "https://management.azure.com/subscriptions/" + $sub + "/resourceGroups/" + $rg + "/providers/Microsoft.KeyVault/vaults/" + $kv + "?api-version=2018-02-14"

$token = ("Bearer " + $Env:system_accesstoken)
$token 
$params = @{
    ContentType = 'application/json'
    Headers     = @{
      'authorization' = $token
    }
    Method      = 'Get'
    URI         = $Uri
    Body        = $body
  }

Invoke-RestMethod @params



Get-VstsInput -Name ConnectedServiceNameSelector -Default 'ConnectedServiceName'

$Env:system_accesstoken



$params = @{
  ContentType = 'application/json'
  Headers     = @{
    'authorization' = "Bearer $($token.Access_Token)"
  }
  Method      = 'Put'
  URI         = $Uri
  Body        = $body
}

Invoke-RestMethod @params -OutVariable Runbook
$Runbook.properties