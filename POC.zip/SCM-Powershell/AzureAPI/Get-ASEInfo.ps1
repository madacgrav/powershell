$tennantID = "36da45f1-dd2c-4d1f-af13-5abe46b99921"
$subID = ""
$appID = "31aa0d09-0e67-4b2a-a37e-d8a325726acd"
$appkey = ""

$tokenEndPoint = "https://login.windows.net/" + $tennantID + "/oauth2/token"
$armResource = "https://management.core.windows.net/"

$body = @{
            'resource' = $armResource
            'client_id' = $appID
            'grant_type' = 'client_credentials'
            'client_secret' = $appkey
        }

$params = @{
    ContentType = 'application/x-www-form-urlencoded'
    Headers = @{'accept'='application/json'}
    Body = $body
    Method = 'Post'
    URI = $tokenEndPoint 
}


$token = Invoke-RestMethod @params

$token.access_token

