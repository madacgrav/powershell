﻿param {
    [string]$SubId = "0e9717d5-1108-4e40-9243-ed45faa93751",
    [string]$VaultName = "AZRG-ADV-KV-PREPROD-EUS",
    [string]$projectcode = "dcm",
    [string]$environment = "preprod"
}




#Flag Variables
$SelectionNum = 0
$completed = $false
$authenticated = $False
$csrfile = ".\" + $projectcode + "-" + $environment + "_csr.txt"

Prompt for login
Try
{
    $login= Login-AzureRmAccount -SubscriptionId $SubId -ErrorAction Stop
}
Catch
{
    $ErrorMessage = $_.Exception.Message
    Write-Output "AzureRM Login Failed with error message:" $ErrorMessage -ForegroundColor Red
    Break
}

#Hash Variables
$Selections = @("Create New CSR","Complete an existing CSR","Export PFX", "Exit App")
#Create Selections Hash Table
foreach ($Selection in $Selections)
{
	$SelectionNum = $SelectionNum + 1
	$SelectionHash = $SelectionHash + @{"$SelectionNum" = $Selection}
}

#Print Selection Hash Table
$SelectionHash.GetEnumerator() | Sort-Object -Property Name | Format-Table @{Expression={$_.Name};Label="Number"},@{Expression={$_.Value};Label="Selection"}

#Start Application While Loop
while (-not $completed) 
    {
    $selectionConfirmation = Read-Host -Prompt 'Input the number of the selection from the list above'
    switch ($selectionConfirmation)
        {
            1   {
                    $certificateName = Read-Host -Prompt 'Provide a friendly name for your key/certificate'
                    $certificateCommonName = Read-Host -Prompt 'provide the common name for your certificate'

                    Write-Output "Provide Subject Alternative Name(s). Leave empty if no SAN"
                    $certificateSan = @()
                    $sanInputNum = 1
                    do {
                        $sanInput = (Read-Host -prompt "SAN $sanInputNum")
                        $sanInputNum += 1
                        if ($sanInput -ne '') {$certificateSan += $sanInput}
                    }
                    until ($sanInput -eq '')
       
                    #$certificateSan = Read-Host -Prompt 'Provide Subject Alternative Name(s), comma separated for multiple SANs. Leave empty if no SAN'
                    $certificateSan += $certificateCommonName
                    $CertificateLength -ne "24"
                    $certificateSubjectName = "CN=" + $certificateCommonName + ",OU=SCM,O=Deloitte and Touche LLP,l=Hermitage,S=Tennessee,C=US"

                    #Create the cert policy variable
                    if ($certificateSan)
                    {           
                    $manualPolicy = New-AzureKeyVaultCertificatePolicy -SubjectName $certificateSubjectName -DnsNames $certificateSan -ValidityInMonths $CertificateLength -ReuseKeyOnRenewal -EmailAtNumberOfDaysBeforeExpiry 30 -IssuerName Unknown 
                    }
                    elseif (!$certificateSan)
                    {
                    $manualPolicy = New-AzureKeyVaultCertificatePolicy -SubjectName $certificateSubjectName -ValidityInMonths $CertificateLength -ReuseKeyOnRenewal -EmailAtNumberOfDaysBeforeExpiry 30 -IssuerName Unknown 
                    }
                    #Create the empty cert with the policy settings above (Need Try and Catch)
                    $certificateOperation = Add-AzureKeyVaultCertificate -VaultName $VaultName -Name $certificateName -CertificatePolicy $manualPolicy

                    $csr = "-----BEGIN CERTIFICATE REQUEST-----`n" + $certificateOperation.CertificateSigningRequest + "`n-----END CERTIFICATE REQUEST-----"
                    
                    $csr | Out-File -FilePath $csrfile
                     Write-Output "The CSR has been copied to your filesystem - $csrfile`n"

                    Clear-Variable certificateName, certificateCommonName, certificateSan, CertificateLocality, CertificateLength, certificateSubjectName, manualPolicy, certificateOperation, csr
                    #Print Selection Hash Table
                    $SelectionHash.GetEnumerator() | Sort-Object -Property Name | Format-Table @{Expression={$_.Name};Label="Number"},@{Expression={$_.Value};Label="Selection"}		
			    }
            2   {
                    $certificateNameInput = Read-Host -Prompt 'Provide a friendly name for your key/certificate'
                    

                    Add-Type -AssemblyName System.Windows.Forms
                    $FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{
                        Title = "Choose certificate file for the CSR $certificateNameInput"
                        Multiselect = $false # Multiple files can be chosen
	                    Filter = 'Certificate files (*.cer, *.crt, *.p7b)|*.cer;*.crt;*.p7b|All files (*.*)|*.*' # Specified file types
                    }
 
                    [void]$FileBrowser.ShowDialog()

                    $file = $FileBrowser.FileName;

                    If($FileBrowser.FileNames -like "*\*") {

	                    # Do something 
	                    #$FileBrowser.FileName #Lists selected files (optional)
	
                    }

                    else {
                        Write-Host "Cancelled by user"
                        $SelectionHash.GetEnumerator() | Sort-Object -Property Name | Format-Table @{Expression={$_.Name};Label="Number"},@{Expression={$_.Value};Label="Selection"}
                        break;
                    }

                    #After the CSR has been signed by the CA, import the completed cert to Key Vault
                    Import-AzureKeyVaultCertificate -VaultName $vaultName -Name $certificateNameInput -FilePath $file

                    Clear-Variable certificateNameInput, FileBrowser, file

                    $SelectionHash.GetEnumerator() | Sort-Object -Property Name | Format-Table @{Expression={$_.Name};Label="Number"},@{Expression={$_.Value};Label="Selection"}
                }
            3   {
                    #Export a PFX
                    $pfxPassword = Read-Host -Prompt 'Provide a challenge password for the pfx'
                    $certificateName = Read-Host -Prompt 'Provide the friendly name of key/certificate'

                    $kvSecret = Get-AzureKeyVaultSecret -VaultName $vaultName -Name $certificateName
                    $kvSecretBytes = [System.Convert]::FromBase64String($kvSecret.SecretValueText)
                    $certCollection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
                    $certCollection.Import($kvSecretBytes,$null,[System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)

                    #Get the file created
                    $protectedCertificateBytes = $certCollection.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Pkcs12, $pfxPassword)
                    
                    #$pfxPath = [Environment]::GetFolderPath("Desktop") + "\$certificateName-" + [DateTime]::Now.ToString("yyMMddHHmmss") + ".pfx"
                    #[System.IO.File]::WriteAllBytes($pfxPath, $protectedCertificateBytes)

                    Add-Type -AssemblyName System.Windows.Forms
                    $saveFileDialog = New-Object System.Windows.Forms.SaveFileDialog -Property @{
                        initialDirectory = [System.IO.Directory]::GetCurrentDirectory()
                        Title = "save $certificateName to disk"
                        ShowHelp = $True
	                    Filter = 'pfx files (*.pfx)|*.pfx' # Specified file types
                    }
 
                    $result = $saveFileDialog.ShowDialog()

                     if($result -eq "OK")    {    
                        Write-Host "Selected File and Location:"  -ForegroundColor Green  
                        $SaveFileDialog.filename
                        [System.IO.File]::WriteAllBytes($SaveFileDialog.filename, $protectedCertificateBytes)
                     
                     } 
                    else { 
                        Write-Host "File Save Dialog Cancelled!" -ForegroundColor Yellow
                        Clear-Variable pfxPassword, certificateName, kvSecret, kvSecretBytes, certCollection, protectedCertificateBytes, saveFileDialog, result
                        $SelectionHash.GetEnumerator() | Sort-Object -Property Name | Format-Table @{Expression={$_.Name};Label="Number"},@{Expression={$_.Value};Label="Selection"}
                        break;
                    } 
                    
                    Clear-Variable pfxPassword, certificateName, kvSecret, kvSecretBytes, certCollection, protectedCertificateBytes, saveFileDialog, result
                    $SelectionHash.GetEnumerator() | Sort-Object -Property Name | Format-Table @{Expression={$_.Name};Label="Number"},@{Expression={$_.Value};Label="Selection"}
                }
            4   {
                    $completed = $true
                }
		    default 
                {
                    Write-Output "Incorrect Selection, Try again`n"
                }
	    }
    }


