
$ClientID       = "**app id**" #ApplicationID
$ClientSecret   = "** SPN key**"  #key from Application
$tennantid      = "36da45f1-dd2c-4d1f-af13-5abe46b99921"

#region Get Access Token
$TokenEndpoint = "https://login.windows.net/36da45f1-dd2c-4d1f-af13-5abe46b99921/oauth2/token"
$ARMResource = "https://management.core.windows.net/";

$Body = @{
        'resource'= $ARMResource
        'client_id' = $ClientID
        'grant_type' = 'client_credentials'
        'client_secret' = $ClientSecret
}

$params = @{
    ContentType = 'application/x-www-form-urlencoded'
    Headers = @{'accept'='application/json'}
    Body = $Body
    Method = 'Post'
    URI = $TokenEndpoint
}

$token = Invoke-RestMethod @params