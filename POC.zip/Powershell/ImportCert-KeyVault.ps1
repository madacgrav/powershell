$SubId = "a0df36e3-db4d-4a7d-aafb-2b39fa03af34"
$login= Login-AzureRmAccount -SubscriptionId $SubId -ErrorAction Stop

$VaultName = "consult-kv-prod-eus"
$certificateNameInput = "con-dasdcm-stg-appcert-eus"
$Password = ConvertTo-SecureString -String "CONDCMcert1!" -AsPlainText -Force
$file = "C:\!Projects\DCM\consult-kv-prod-eus-con-dasdcm-stage-appcert-eus-20190814.pfx"
Import-AzureKeyVaultCertificate -VaultName $vaultName -Name $certificateNameInput -FilePath $file -Password $Password