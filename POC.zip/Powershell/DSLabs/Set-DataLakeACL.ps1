# Set lakestore name
$adlsname = "ddslabdlseus2"

# Get SPN Ids for DSLAB management PRQ team
$spn_datamgmt = 'US Cloud-DSLab-DataManagement-PRQ-D NONPROD'
$spn_datamgmt_id = (get-azurermadserviceprincipal -SearchString $spn_datamgmt).Id 

#Add any paths for a specific permission here.  Comman seperated.
$folderpaths = @(
    '/dtus/core/cp3/engagement/consulting/parquet',
    '/dtus/core/cp3/forecast_managed/consulting/parquet',
    '/dtus/core/cp3/forecast_staffed/consulting/parquet',
    '/dtus/core/cp3/pricing_managed/consulting/parquet',
    '/dtus/core/cp3/pricing_staffed/consulting/parquet',
    '/dtus/core/cp3/project/consulting/parquet',
    '/dtus/core/cp3/snapshot/consulting/parquet'
)

#This will iterate through each path and apply the permission specified.  Create a new script for each permission level.
foreach ($path in $folderpaths) {
    if (Test-AzureRmDataLakeStoreItem -AccountName $adlsname -Path $path) {
        Set-AzureRmDataLakeStoreItemAclEntry -AccountName $adlsname -Path $path -AceType User -Id $spn_datamgmt_id -Permissions All -Recurse
        Set-AzureRmDataLakeStoreItemAclEntry -AccountName $adlsname -Path $path -AceType User -Id $spn_datamgmt_id -Permissions All -Recurse -Default
    }
    else {
        write-host "$path is invalid."
    }
}
