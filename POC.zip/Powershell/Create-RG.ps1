$resourceGroupName = "AZRG-ENA-DASRDS-SBX"
$resourceGroupLocation = "East US"
$subscriptionId = "a538b62c-01c0-4fd3-acc4-e3b725f57982"
$spnID = "b71a3a56-e7d0-4c10-a323-02f457c8a3aa"
$scmGroupID = "97ece1e6-eddc-4861-a6d9-80f14630cf50"

Select-AzureRmSubscription -SubscriptionId $subscriptionId
$rgCheck = Get-AzureRmResourceGroup | Where-Object {$_.ResourceGroupName -eq $resourceGroupName}
if (!$rgCheck) {
    Write-Host "Creating Resource Group " $resourceGroupName
    New-AzureRmResourceGroup -Name $resourceGroupName -Location $resourceGroupLocation -Tag $tag
    New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
}
else {
    $scopeID = "/subscriptions/" + $subscriptionId + "/resourceGroups/" + $resourceGroupName
    $roleAssignment = Get-AzureRmRoleAssignment -ResourceGroupName $resourceGroupName | Where-Object {$_.Scope -eq $scopeID}
    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).ObjectId -ne $spnID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }

    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).ObjectId -ne $scmGroupID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }
}

$resourceGroupName = "AZRG-ENA-DASRDS-SBX"
$resourceGroupLocation = "East US"
$GroupID = "c21cd254-2994-4faf-b1b6-e8a676ce6af5"
Select-AzureRmSubscription -SubscriptionId $subscriptionId
New-AzureRmRoleAssignment -ObjectId $GroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName