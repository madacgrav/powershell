[CmdletBinding()]
Param(
    #[Parameter(Mandatory = $True)]
    [string]$resourceGroup = "rgName",

    #[Parameter(Mandatory = $True)]
    [string]$dataFactoryName = "adfName",

    #[Parameter(Mandatory = $True)]
    [string]$datasetFolder= "..\dataset",

    #[Parameter(Mandatory = $True)]
    [string]$pipelineFolder = "..\pipeline"
)

if (Test-Path -Path $datasetFolder) {
    $datasetFiles = Get-ChildItem -path $datasetFolder
    foreach ($dsFile in $datasetFiles) {
        $dsName = $dsFile -replace ".json",""
        write-host ("Starting dataset deployment for : " + $dsName)
        try {
            #Set-AzureRmDataFactoryV2Dataset -ResourceGroupName $resourceGroup -DataFactoryName $dataFactoryName -Name $dsName -DefinitionFile $dsFile.FullName
            write-host ("Dataset deployment complete")
        }
        catch {
            write-host ("failed to deploy dataset : " + $dsName )
        }
    }
}
else {
    write-host "Dataset folder not found. Skipping datasets."
}

if (Test-Path -Path $pipelineFolder) {
    $pipelineFiles = Get-ChildItem -Path $pipelineFolder
    foreach ($pFile in $pipelineFiles) {
        $pName = $pFile -replace ".json",""
        write-host ("Starting Pipeline deployment for : " + $pName)
        try {
            #Set-AzureRmDataFactoryV2Pipeline -ResourceGroupName $resourceGroup -Name $pName -DataFactoryName $dataFactoryName -File $pFile.FullName
            write-host ("Pipeline deployment complete")
        }
        catch {
            write-host ("failed to deploy dataset : " + $pName )
        }
    }
}
else {
    write-host "Pipeline folder not found. Skipping pipelines."
}