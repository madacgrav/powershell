[CmdletBinding()]
Param(
    [Parameter(Mandatory = $True)]
    [string]$jsonFilePath,

    [Parameter(Mandatory = $True)]
    [string]$datalakeStoreName
)


function Get-JsonFileContent {
    Param(
        [Parameter(Mandatory = $True)]
        [string]$path,

        [Parameter(Mandatory = $True)]
        [ValidateSet("raw", "array")]
        [string]$returnType
    )
    try {
        if ($returnType -eq "raw") {
            $content = Get-content -Raw $path 
        }
        elseif ($returnType -eq "array") {
            $content = Get-content $path 
            # Parse the JSON content
            $content = $content | ConvertFrom-Json 
        }
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        Write-Output "Failed with Error:  $ErrorMessage"
        
    }
    return $content
}

function Get-DatalakeFolders {
    Param(
        [Parameter(Mandatory = $True)]
        [string]$datalakeStoreName,

        [Parameter(Mandatory = $True)]
        [string]$path
    )
    try {
        $datalakeFolders = @()
        $datalakeChildItems = Get-AzureRmDataLakeStoreChildItem -Account $datalakeStoreName -Path $path | Select-Object Type, Path | Where-Object {$_.Type -eq "DIRECTORY" }
        foreach ($item in $datalakeChildItems) {
            $datalakeFolders += $item
            if ($item.type -eq "DIRECTORY") {
                Get-DatalakeFolders $datalakeStoreName $item.path
            }
        }
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        Write-Output "Failed with Error:  $ErrorMessage"
    
    }
    return $datalakeFolders
}

function Verify-EntryExistInArray {
    Param(
        [Parameter(Mandatory = $True)]
        [string]$entry,

        [Parameter(Mandatory = $True)]
        [array]$array
    )
    try {
        [bool]$entryExistFlag = $False
        $entryExist = $entry | Where-Object {$array -match $entry}
        if ($entryExist) {
            $entryExistFlag = $True
        }
        else {
            $entryExistFlag = $False
        }
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        Write-Output "Failed with Error:  $ErrorMessage"

    }
    return $entryExistFlag
}

function Get-Permissions {
    Param(
        [Parameter(Mandatory = $True)]
        $permissionArray
    )
    [string]$permissions = ""

    if ($permissionArray -match "Read") {
        $permissions = $permissions.insert(0, "r")

    }
    else {
        $permissions = $permissions.insert(0, "-")
    }

    if ($permissionArray -match "Write") {
        $permissions = $permissions.insert(1, "w")

    }
    else {
        $permissions = $permissions.insert(1, "-")
    }

    if ($permissionArray -match "Execute") {
        $permissions = $permissions.insert(2, "x")

    }
    else {
        $permissions = $permissions.insert(2, "-")
    }

    return $permissions
}

function Compare-ACL
(
    $referenceObjectArray,
    $differenceObjectArray
) {
    $diffFound = $false

    #check count
    if ($referenceObjectArray.count -ne $differenceObjectArray.count) {
        $diffFound = $true
        Write-Verbose "Diff found in Count"
    }

    #check entries in referenceObjectArray
    foreach ($entry in $referenceObjectArray) {
        $referenceObjectEntryScope = $entry.Scope
        $referenceObjectEntryType = $entry.Type
        $referenceObjectEntryID = ($entry.Id).Trim()
        $referenceObjectEntryPermission = $entry.Permission

        $differenceObjectEntry = $differenceObjectArray | Where-Object {($_.Scope -eq $referenceObjectEntryScope) -and ($_.Type -eq $referenceObjectEntryType) -and (($_.Id).trim() -eq $referenceObjectEntryID)}

        if ($differenceObjectEntry) {
            $differenceObjectEntryPermission = $differenceObjectEntry.Permission
            if ($referenceObjectEntryPermission -ne $differenceObjectEntryPermission) {
                $diffFound = $true
                Write-Verbose "Diff found in Permissions"
            }
        }
        else {
            $diffFound = $true
            Write-Verbose "Diff found in ACLs Entries"
        }
    }

    #check entries in differenceObjectArray
    foreach ($entry in $differenceObjectArray) {
        $differenceObjectEntryScope = $entry.Scope
        $differenceObjectEntryType = $entry.Type
        $differenceObjectEntryID = ($entry.Id).Trim()
        $differenceObjectEntryPermission = $entry.Permission

        $referenceObjectEntry = $referenceObjectArray | Where-Object {($_.Scope -eq $differenceObjectEntryScope) -and ($_.Type -eq $differenceObjectEntryType) -and (($_.Id).trim() -eq $differenceObjectEntryID)}

        if ($referenceObjectEntry) {
            $referenceObjectEntryPermission = $referenceObjectEntry.Permission
            if (!$differenceObjectEntryPermission -eq $referenceObjectEntryPermission) {
                $diffFound = $true
                Write-Verbose "Diff found in Permissions"
            }
        }
        else {
            $diffFound = $true
            Write-Verbose "Diff found in ACLs Entries"
        }
    }
    return $diffFound
}

function Compare-Owner
(
    $referenceObjectArray,
    $differenceObjectArray
) {
    $diffFound = $false

    #check count
    if ($referenceObjectArray.count -ne $differenceObjectArray.count) {
        $diffFound = $true
        Write-Verbose "Diff found in Count"
    }
    #check entries in referenceObjectArray
    foreach ($entry in $referenceObjectArray) {
        $referenceObjectEntryType = $entry.Type
        $referenceObjectEntryID = ($entry.Id).Trim()
        $differenceObjectEntry = $differenceObjectArray | Where-Object {$_.Type -eq $referenceObjectEntryType}
        if ($differenceObjectEntry) {
            $differenceObjectEntryID = ($differenceObjectEntry.Id).Trim()
            if ($referenceObjectEntryID -ne $differenceObjectEntryID) {
                $diffFound = $true
                Write-Verbose "Diff found in Permissions"
            }
        }
        else {
            $diffFound = $true
            Write-Verbose "Diff found in ACLs Entries"
        }
    }
    return $diffFound
}

function Set-OwnerRec
(
    [string] $account,
    [string] $path,
    [Guid] $id,
    [string] $entityType
) {
    $itemList = Get-AzureRMDataLakeStoreChildItem -Account $account -Path $path;

    foreach ($item in $itemList) {
        $pathToSet = Join-Path -Path $path -ChildPath $item.PathSuffix;
        $pathToSet = $pathToSet.Replace("\", "/");
        
        Set-AzureRmDataLakeStoreItemOwner -Account $account -Path $pathToSet -Type $entityType -Id $id | Out-Null

        if ($item.Type -ieq "DIRECTORY") {
            Set-OwnerRec -Account $account -Path $pathToSet -Id $id -EntityType $entityType | Out-Null
        }
    }
}

#Get ACL Entries from json file
$jsonArrayContent = Get-JsonFileContent -path $jsonFilePath -returnType "array"
$jsonAclEntries = $jsonArrayContent.aclEntries



#Get all folders in datalake store
write-host "Getting datalake folders"
$datalakeFolders = Get-DatalakeFolders -datalakeStoreName $datalakeStoreName -path /
write-host $datalakeFolders
$datalakeFoldersPath = $datalakeFolders.Path


#Datalake structured Folders ACL
$datalakeStructuredFoldersACL = @()
foreach ($datalakefolder in $datalakeFoldersPath) {
    write-host ("folder: " + $datalakefolder)
    $acl = Get-AzureRmDataLakeStoreItemAclEntry -Account $datalakeStoreName -Path $datalakefolder

    #Onwers Permissions
    $datalakeFolderUserOwnerID = Get-AzureRmDataLakeStoreItemOwner $datalakeStoreName -Path $datalakefolder -Type "User"
    $datalakeFolderGroupOwnerID = Get-AzureRmDataLakeStoreItemOwner $datalakeStoreName -Path $datalakefolder -Type "Group"

    #Define ACL Array Variable
    $owners = @()

    #Add Owner ACL entries
    $ownerObject = New-Object -TypeName PSObject
    $ownerObject | Add-Member -MemberType NoteProperty -Name Type -Value "User"
    $ownerObject | Add-Member -MemberType NoteProperty -Name Id -Value $datalakeFolderUserOwnerID
    $owners += $ownerObject
    Clear-Variable ownerObject

    $ownerObject = New-Object -TypeName PSObject
    $ownerObject | Add-Member -MemberType NoteProperty -Name Type -Value "Group"
    $ownerObject | Add-Member -MemberType NoteProperty -Name Id -Value $datalakeFolderGroupOwnerID
    $owners += $ownerObject
    Clear-Variable ownerObject

    #Add ACLs and Path to the datalake structure folders ACL
    $datalakeStructuredFoldersACLObject = New-Object -TypeName PSObject
    $datalakeStructuredFoldersACLObject | Add-Member -MemberType NoteProperty -Name Path -Value $datalakefolder
    $datalakeStructuredFoldersACLObject | Add-Member -MemberType NoteProperty -Name ACL -Value $acl
    $datalakeStructuredFoldersACLObject | Add-Member -MemberType NoteProperty -Name Owner -Value $owners
    $datalakeStructuredFoldersACL += $datalakeStructuredFoldersACLObject

    Clear-Variable acl, datalakeFolderUserOwnerID, datalakeFolderGroupOwnerID, owners, datalakeStructuredFoldersACLObject, datalakefolder
}

#Define json Structured folders ACL Variable
$jsonStructuredFoldersACL = @()
foreach ($jsonAclEntry in $jsonAclEntries) {
    $jsonAclEntryPath = $jsonAclEntry.Path
    $jsonAclEntryRecurse = $jsonAclEntry.Recurse
    $verifyJsonAclEntryFlag = Verify-EntryExistInArray -entry $jsonAclEntryPath -array $datalakeFoldersPath

    if ($verifyJsonAclEntryFlag -eq $True) {
        Write-Verbose "Folder Path from Json file: $jsonAclEntryPath exist in DataLake Store"

        #Define ACL Array Variable
        $acl = @()

        #Loop through ACL and add them to an array object
        foreach ($aclEntry in $jsonAclEntry.ACL) {
            $permissions = Get-Permissions -permissionArray $aclEntry.Permissions
            #Check if Inheritance is set to true
            if ($aclEntry.Inheritance -eq $true) {
                $aclObject = New-Object -TypeName Microsoft.Azure.Commands.DataLakeStore.Models.DataLakeStoreItemAce ("Access", $aclEntry.ObjectType, $aclEntry.ObjectID, $permissions)
                $acl += $aclObject

                $aclObject = New-Object -TypeName Microsoft.Azure.Commands.DataLakeStore.Models.DataLakeStoreItemAce ("Default", $aclEntry.ObjectType, $aclEntry.ObjectID, $permissions)
                $acl += $aclObject
            }
            else {
                $aclObject = New-Object -TypeName Microsoft.Azure.Commands.DataLakeStore.Models.DataLakeStoreItemAce ("Access", $aclEntry.ObjectType, $aclEntry.ObjectID, $permissions)
                $acl += $aclObject
            }
            Clear-Variable permissions, aclObject, aclEntry
        }

        #Owners Permissions
        $owners = @()
        foreach ($owner in $jsonAclEntry.Owners) {
            $ownerObject = New-Object -TypeName PSObject
            $ownerObject | Add-Member -MemberType NoteProperty -Name Type -Value $owner.ObjectType
            $ownerObject | Add-Member -MemberType NoteProperty -Name Id -Value $owner.ObjectID
            $owners += $ownerObject
            Clear-Variable ownerObject, owner
        }
    
        #Mask Permissions
        $permissions = Get-Permissions -permissionArray $jsonAclEntry.Mask.Permissions
        if ($jsonAclEntry.Mask.Inheritance -eq $true) {
            $aclObject = New-Object -TypeName Microsoft.Azure.Commands.DataLakeStore.Models.DataLakeStoreItemAce ("Access", "Mask", "", $permissions)
            $acl += $aclObject
            Clear-Variable aclObject

            $aclObject = New-Object -TypeName Microsoft.Azure.Commands.DataLakeStore.Models.DataLakeStoreItemAce ("Default", "Mask", "", $permissions)
            $acl += $aclObject
            Clear-Variable aclObject
        }
        else {
            $aclObject = New-Object -TypeName Microsoft.Azure.Commands.DataLakeStore.Models.DataLakeStoreItemAce ("Access", "Mask", "", $permissions)
            $acl += $aclObject
            Clear-Variable aclObject
        }

        $aclObject = New-Object -TypeName Microsoft.Azure.Commands.DataLakeStore.Models.DataLakeStoreItemAce ("Access", "Other", "", "---")
        $acl += $aclObject
        Clear-Variable aclObject

        $aclObject = New-Object -TypeName Microsoft.Azure.Commands.DataLakeStore.Models.DataLakeStoreItemAce ("Default", "Other", "", "---")
        $acl += $aclObject
        Clear-Variable aclObject

        $aclObject = New-Object -TypeName Microsoft.Azure.Commands.DataLakeStore.Models.DataLakeStoreItemAce ("Access", "User", "", "rwx")
        $acl += $aclObject
        Clear-Variable aclObject

        $aclObject = New-Object -TypeName Microsoft.Azure.Commands.DataLakeStore.Models.DataLakeStoreItemAce ("Default", "User", "", "rwx")
        $acl += $aclObject
        Clear-Variable aclObject

        $aclObject = New-Object -TypeName Microsoft.Azure.Commands.DataLakeStore.Models.DataLakeStoreItemAce ("Access", "Group", "", "rwx")
        $acl += $aclObject
        Clear-Variable aclObject

        $aclObject = New-Object -TypeName Microsoft.Azure.Commands.DataLakeStore.Models.DataLakeStoreItemAce ("Default", "Group", "", "rwx")
        $acl += $aclObject
        Clear-Variable aclObject

        #Add ACLs and Path to the json structure folders ACL
        $jsonStructuredFoldersACLObject = New-Object -TypeName PSObject
        $jsonStructuredFoldersACLObject | Add-Member -MemberType NoteProperty -Name Path -Value $jsonAclEntryPath
        $jsonStructuredFoldersACLObject | Add-Member -MemberType NoteProperty -Name Recurse -Value $jsonAclEntryRecurse
        $jsonStructuredFoldersACLObject | Add-Member -MemberType NoteProperty -Name ACL -Value $acl
        $jsonStructuredFoldersACLObject | Add-Member -MemberType NoteProperty -Name Owner -Value $owners
        $jsonStructuredFoldersACL += $jsonStructuredFoldersACLObject
    }
    else {
        Write-Verbose "Folder Path from Json file: $jsonAclEntryPath doesn't exist in DataLake Store"
        throw "Folder Path from Json file: $jsonAclEntryPath doesn't exist in DataLake Store"
    }
    Clear-Variable jsonAclEntryPath, verifyJsonAclEntryFlag, acl, owners, permissions, jsonStructuredFoldersACLObject, jsonAclEntry
}



foreach ($entry in $jsonStructuredFoldersACL) {
    
    Write-Host "*****************************"
    $entry.Path = ($entry.Path).Replace("\", "")
    Write-Host "Path:" $entry.Path "-> Processing..."

    #Filter Datalake entry ACL
    $datalakeEntryACL = $datalakeStructuredFoldersACL | Where-Object {$_.Path -eq $entry.Path}

    #Compare Owners
    $ownerUpdateFlag = Compare-Owner -referenceObjectArray $entry.Owner -differenceObjectArray $datalakeEntryACL.Owner

    if ($ownerUpdateFlag) {
        Write-Host "Path:" $entry.Path "-> Owner Mismatch Found, Updating Owners"

        [Guid]$jsonOwnerUserId = ($entry.Owner | Where-Object {$_.Type -eq "User"}).Id
        #[Guid]$jsonOwnerGroupId = ($entry.Owner | Where-Object {$_.Type -eq "Group"}).Id

        write-host "This is the owner id " $jsonOwnerUserId
        if ($entry.Recurse) {
            write-host "Setting owner - recurse"
            Set-AzureRmDataLakeStoreItemOwner -Account $datalakeStoreName -Path $entry.Path -Type "User" -Id $jsonOwnerUserId
            Set-OwnerRec -account $datalakeStoreName -path $entry.Path -id $jsonOwnerUserId -entityType "User"
            Write-Host "Path:" $entry.Path "-> Owner Type User updated, with recurse"

          #  write-host "Owner Group ID " $jsonOwnerGroupId
          #  Set-AzureRmDataLakeStoreItemOwner -Account $datalakeStoreName -Path $entry.Path -Type "Group" -Id $jsonOwnerGroupId
          #  Set-OwnerRec -account $datalakeStoreName -path $entry.Path -id $jsonOwnerGroupId -entityType "Group"
          #  Write-Host "Path:" $entry.Path "-> Owner Type Group updated, with recurse"
        }
        else {
            write-host "Setting owner"
            Set-AzureRmDataLakeStoreItemOwner -Account $datalakeStoreName -Path $entry.Path -Type "User" -Id $jsonOwnerUserId
            Write-Host "Path:" $entry.Path "-> Owner Type User updated"

          #  Set-AzureRmDataLakeStoreItemOwner -Account $datalakeStoreName -Path $entry.Path -Type "Group" -Id $jsonOwnerGroupId
          #  Write-Host "Path:" $entry.Path "-> Owner Type Group updated" 
        }
    }
    else {
        Write-Host "Path:" $entry.Path "-> Skip Owners Update, Owners Matched"
    }

    #Compare ACLs
    $aclUpdateFlag = Compare-ACL -referenceObjectArray $entry.ACL -differenceObjectArray $datalakeEntryACL.ACL

    #### Remove ACL and then set ACL



    #Update ACLs
    if ($aclUpdateFlag) {
        Write-Host "Path:" $entry.Path "-> ACL Mismatch Found, Updating ACL"
        if ($entry.Recurse) {
            Set-AzureRmDataLakeStoreItemAcl -Account $datalakeStoreName -Path $entry.Path -Acl $entry.ACL -Recurse #-Concurrency 128
            Write-Host "Path:" $entry.Path "-> ACL updated, with recurse"
        }
        else {
            Set-AzureRmDataLakeStoreItemAcl -Account $datalakeStoreName -Path $entry.Path -Acl $entry.ACL #-Concurrency 128
            Write-Host "Path:" $entry.Path "-> ACL updated"
        }
    }
    else {
        Write-Host "Path:" $entry.Path "-> Skip ACL Update, ACL Matched"
    }
    Write-Host "Path:" $entry.Path "-> Processing Successfully Completed"
}


