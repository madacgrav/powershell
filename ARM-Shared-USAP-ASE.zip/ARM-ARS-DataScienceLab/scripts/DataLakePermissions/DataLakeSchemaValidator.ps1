[CmdletBinding()]
Param(
    [Parameter(Mandatory = $True)]
    [string]$jsonFilePath,

    [Parameter(Mandatory = $True)]
    [string]$jsonSchemaPath,

    [Parameter(Mandatory = $True)]
    [string]$newtonsoftJsonDllFilePath,

    [Parameter(Mandatory = $True)]
    [string]$newtonsoftJsonSchemaDllFilePath
)


function Get-JsonFileContent {
    Param(
        [Parameter(Mandatory = $True)]
        [string]$path,

        [Parameter(Mandatory = $True)]
        [ValidateSet("raw", "array")]
        [string]$returnType
    )
    try {
        if ($returnType -eq "raw") {
            $content = Get-content -Raw $path 
        }
        elseif ($returnType -eq "array") {
            $content = Get-content $path 
            # Parse the JSON content
            $content = $content | ConvertFrom-Json 
        }
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        Write-Output "Failed with Error:  $ErrorMessage"
        
    }
    return $content
}

function Verify-JsonSchema {
    Param(
        [Parameter(Mandatory = $True)]
        [string]$newtonsoftJsonDllPath,

        [Parameter(Mandatory = $True)]
        [string]$newtonsoftJsonSchemaDllPath,

        [Parameter(Mandatory = $True)]
        $jsonSchemaContent,

        [Parameter(Mandatory = $True)]
        $jsonFileContent
    )
    try {
        $newtonsoftJsonPath = Resolve-Path -Path $newtonsoftJsonDllPath
        $newtonsoftJsonSchemaPath = Resolve-Path -Path $newtonsoftJsonSchemaDllPath

        Unblock-File -Path $newtonsoftJsonPath
        Unblock-File -Path $newtonsoftJsonSchemaPath
        Add-Type -Path $newtonsoftJsonPath
        Add-Type -Path $newtonsoftJsonSchemaPath

        $source = @'
    public class Validator
    {
        public static System.Collections.Generic.IList<string> Validate(Newtonsoft.Json.Linq.JToken token, Newtonsoft.Json.Schema.JSchema schema)
        {
            System.Collections.Generic.IList<string> messages;
            Newtonsoft.Json.Schema.SchemaExtensions.IsValid(token, schema, out messages);

            return messages;
        }
    }
'@
        Add-Type -TypeDefinition $source -ReferencedAssemblies $NewtonsoftJsonPath, $NewtonsoftJsonSchemaPath

        Write-Verbose "========================="
        write-Verbose "Json.NET Schema Validator"
        write-Verbose "========================="

        $token = [Newtonsoft.Json.Linq.JToken]::Parse($jsonFileContent)
        $schema = [Newtonsoft.Json.Schema.JSchema]::Parse($jsonSchemaContent)

        $result = [Validator]::Validate($token, $schema)
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        Write-Output "Failed with Error:  $ErrorMessage"

    }
    return $result
}






#Script Logic

#Get json Schema Content
$jsonSchemaRawContent = Get-JsonFileContent -path $jsonSchemaPath -returnType "raw"

#Get json raw content
$jsonFileRawContent = Get-JsonFileContent -path $jsonFilePath -returnType "raw"

#Get ACL Entries from json file
$jsonArrayContent = Get-JsonFileContent -path $jsonFilePath -returnType "array"
$jsonAclEntries = $jsonArrayContent.aclEntries

#Validate json Schema
$jsonSchemaResults = Verify-JsonSchema -newtonsoftJsonDllPath $newtonsoftJsonDllFilePath -newtonsoftJsonSchemaDllPath $newtonsoftJsonSchemaDllFilePath -jsonSchemaContent $jsonSchemaRawContent -jsonFileContent $jsonFileRawContent

if ($jsonSchemaResults) {
    Write-Host "Json.NET Schema Validator failed" -foregroundcolor "red"
    write-host "-------------------------" -foregroundcolor "red"
    write-host "Validation Errors:" -foregroundcolor "red"
    foreach ($entry in $jsonSchemaResults) {
        write-host $entry -foregroundcolor "red"
    }
    throw "Json.NET Schema Validator failed"
}
else {
    write-host "Json.NET Schema Validator -> Successful" -foregroundcolor "green"
}
