[CmdletBinding()]
Param(
    [Parameter(Mandatory = $True)]
    [String]$armTemplateFile,

    [Parameter(Mandatory = $True)]
    [String]$resourceTypeString
)

try {
    $jsonFile = Get-Content $armTemplateFile | Out-String -ErrorAction Stop
    $armTemplateResources = ($jsonFile | ConvertFrom-Json).resources
    
    Foreach ($resource in $armTemplateResources) {
        $resourceType = $resource.type
        $resourceName = $resource.name
        if (!($resourceType -match $resourceTypeString)) {
            Write-Error -Exception ([System.Exception]::new("verification failed, Resource Type: $resourceType is not allowed, Resource Name: $resourceName")) -ErrorAction Stop
        }
        else {
            Write-Output "verification passed, Resource Type: $resourceType"
        }
    }
    Write-Output "ARM template: $armTemplateFile, passed validation for the resource type: $resourceTypeString"
}
catch [System.Exception] {
    $ErrorMessage = $_.Exception.Message
    throw $ErrorMessage
}
catch {
    $ErrorMessage = $_.Exception.Message
    throw "Script failed, with error message: $ErrorMessage"
}
