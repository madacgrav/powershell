#Create Key (Dynamically pull in VaultName?  Dynamically name the Key? Check for existing Key?)
Add-AzureKeyVaultKey -VaultName 'dslab-qsyem5c6jjadm' -Name 'dslabdlscus' -Destination 'HSM'

#Store the Key's Value to a variable ((Dynamically pull in VaultName?  Export version value to VSTS?)
$dataLakeAccountEncryptionKeyVersion = Get-AzureKeyVaultKey -VaultName 'sdslab-z55pskfjuvl4a' -Name 'sdslabdlseus2' | Select Version
