#Retrieve the Service Identity ID of the DataFactory
 $datafactoryserviceid = (Get-AzureRmDataFactoryV2 -ResourceGroupName "AZRG-ENA-DASDSLAB-QAS" -Name "qdslabdf-eus2").Identity | Select PrincipalId -outvariable $datafactoryprincipalid
 
#Grant DataFactory MSI access to DataLake via PowerShell with this command
#How to dynamically feed in $datafactoryprincipalid from previous PowerShell into Id?  How to dynamically feed in the DLS account name? 

Set-AzureRmDataLakeStoreItemAclEntry -AccountName "qdslabdlseus2" -Path / -AceType User -Id "$datafactoryprincipalid" -Permissions All -Recurse
Set-AzureRmDataLakeStoreItemAclEntry -AccountName "qdslabdlseus2" -Path / -AceType User -Id "$datafactoryprincipalid" -Permissions All -Recurse -Default
