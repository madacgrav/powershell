############################################################
############################################################
############################################################
##### THIS SCRIPT IS ONLY FOR A NON SHARED DATAFACTORY #####
############################################################
############################################################
############################################################
[CmdletBinding()]
Param(
    [Parameter(Mandatory = $True)]
    [string]$dataFactoryName,
	
    [Parameter(Mandatory = $True)]
    [string]$resourceGroupName,

    [Parameter(Mandatory = $True)]
    [string]$operation
)

Import-Module AzureRM.DataFactoryV2
try {
    $dataFactoryTriggers = Get-AzureRmDataFactoryV2Trigger -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName

    if ($dataFactoryTriggers) {

        foreach ($trigger in $dataFactoryTriggers) {
            $triggerName = $trigger.Name
            if ($operation -eq 'start') {
                Write-Output "Starting trigger: $triggerName"
                Start-AzureRmDataFactoryV2Trigger -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName -Name $triggerName -Force | Out-Null
            }
            elseif ($operation -eq 'stop') {
                Write-Output "Stopping trigger: $triggerName"
                Stop-AzureRmDataFactoryV2Trigger -ResourceGroupName $resourceGroupName -DataFactoryName $dataFactoryName -Name $triggerName -Force | Out-Null
            }
            else {
                throw "operation is incorrect, use start or stop"
            }
        }
    }
    else {
        Write-Output "No triggers are found"
    }
}

catch {
    $ErrorMessage = $_.Exception.Message
    throw "Script failed, with error message: $ErrorMessage"
}