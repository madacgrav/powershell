[CmdletBinding()]
Param(
    # [Parameter(Mandatory = $True)]
    #[ValidateScript({Test-Path $_})]
    [string]$csvFile = "C:\!IT\RemoveItem.csv",
    [string]$datalakeName = "dslabadlssbx.azuredatalakestore.net"
)

write-host "importing file"
$entries = Import-Csv $csvFile
write-host "Starting folder deletion"
foreach ($entry in $entries) {
    if (Test-AzureRmDataLakeStoreItem -AccountName $datalakeName -Path $entry.Item) {
        try {
            if ($entry.recurse -eq "TRUE") {
                write-host "Deleting " $entry.Item "recursively"
                Remove-AzureRmDataLakeStoreItem -AccountName $datalakeName -Path $entry.Item -recurse -force
            }
            else {
                write-host "Deleting single item " $entry.Item
                Remove-AzureRmDataLakeStoreItem -AccountName $datalakeName -Path $entry.Item -force
            }           
        }
        catch {
           throw $_.Exception.Message
        }
    }
    else {
        throw ( "Item already does not exist : " + $entry.Item + " or invalid datalake name " + $datalakeName)
    }
}