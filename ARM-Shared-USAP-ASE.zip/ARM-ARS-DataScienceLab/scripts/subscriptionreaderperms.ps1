#Command to add an Azure AD User or Group as a Subscription Reader to a specific Azure Data Lake Store
#Replace ObjectId with the ObjectId of the AD User/Group
#Replace Scope with the specific path of the Azure Data Lake Store

New-AzureRmRoleAssignment -ObjectId "<Object ID Here>" -RoleDefinitionName "Subscription Reader" -Scope "/subscriptions/<Subscription ID Here>/resourceGroups/<Resource Group Here>/providers/Microsoft.DataLakeStore/accounts/<Azure Data Lake Store Name Here>"