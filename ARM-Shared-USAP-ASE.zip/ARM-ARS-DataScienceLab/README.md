## IMPORTANT DEPLOYMENT SEQUENCING FOR FIRST TIME DEPLOYMENT OF AN ENVIRONMENT
1. Run the KeyVault ARM environment template 
2. Navigate to the new KeyVault and add in the secrets required for on-prem HANA
3. Create the Azure Data Lake Store (ADLS) Key in KV by updating and running the createdatalakestorekey.ps1 script
4. Update the APP ARM environment template with the new KeyVault ID as well as the current version of the ADLS key created in step 3
5. Manually run the APP ARM environment template
6. Update the KeyVault access policy in the KeyVault ARM environment template with the Service Identity ID of the ADLS
7. Manually run the KeyVault ARM environment template 
8. Manually run the APP ARM environment template (this will allow ADLS to pick up the key in KeyVault)
9. Update the DataBricks ARM environment template
10. Run the DataBricks ARM environment template (Do NOT run again as it will destroy existing workspaces in DataBricks)
11. Grant the DataFactory Service Identity ID (NOT the Service Identity Application ID) access to ADLS
12. Configure the on-prem SSIS IR
 12a. Log into the on-prem server and install the 64bit HANA drivers 
 12b. Log into Azure Portal, connect to the Data Factory, follow the steps to deploy Integration Runtime
13. Grant Subscription Reader access on just the environment's ADLS for the appropriate AD groups


#Manual deployment instructions:

1. Open Powershell
2. Install AzureRM module `Install-Module AzureRM`
3. Login to AzureRM `Login-AzureRmAccount`
4. Run code below based on environment

##DSLAB APP
```
$tag = @{
    MEMBERFIRM='US';
    COUNTRY= 'US';
    FUNCTION= 'ENA';
    CONTACTS='{"Group":"usscmplatformmgmt@deloitte.com","PrimaryContact":"ckennedy@deloitte.com","SecondaryContact":"aajensen@deloitte.com","BusinessOwner":"nipillai@deloitte.com"}';
    BILLINGCODE='TPX01513-04-00-01-7066'; 
    CS='CON (Confidential) : Deloitte : Personal Information (Note: includes PII); Financial Information; Competitive Intelligence';
    SUBFUNCTION= 'DAS-ARS';
    APPID= 'DASDSLAB';
    PORTFOLIO= ''
    }
```
###Deploying DSLAB APP to Enabling Subscription - DEV
```
$resourceGroupName = "AZRG-ENA-DASDSLAB-DEV"
$resourceGroupLocation = "East US 2"
$deploymentName = "dslab-app"
$templateFile = ".\app\dslab-app.json"
$templateParameterFile = ".\app\ddslab-app.parameters.json"
$subscriptionId = "a538b62c-01c0-4fd3-acc4-e3b725f57982"
$spnID = "b71a3a56-e7d0-4c10-a323-02f457c8a3aa"
$scmGroupID = "97ece1e6-eddc-4861-a6d9-80f14630cf50"

Select-AzureRmSubscription -SubscriptionId $subscriptionId
$rgCheck = Get-AzureRmResourceGroup | Where-Object {$_.ResourceGroupName -eq $resourceGroupName}
if (!$rgCheck) {
    Write-Host "Creating Resource Group " $resourceGroupName
    New-AzureRmResourceGroup -Name $resourceGroupName -Location $resourceGroupLocation -Tag $tag
    New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
}
else {
    $scopeID = "/subscriptions/" + $subscriptionId + "/resourceGroups/" + $resourceGroupName
    $roleAssignment = Get-AzureRmRoleAssignment -ResourceGroupName $resourceGroupName | Where-Object {$_.Scope -eq $scopeID}
    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).ObjectId -ne $spnID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }

    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).ObjectId -ne $scmGroupID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }
}
New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName `
-TemplateFile $templateFile `
-TemplateParameterFile $templateParameterFile
Clear-Variable resourceGroupName, resourceGroupLocation, deploymentName, templateFile, templateParameterFile, subscriptionId, spnID, scmGroupID, rgCheck, scopeID, roleAssignment
```

###Deploying DSLAB APP to Enabling Subscription - QAS
```
$resourceGroupName = "AZRG-ENA-DASDSLAB-QAS"
$resourceGroupLocation = "East US 2"
$deploymentName = "dslab-app"
$templateFile = ".\app\dslab-app.json"
$templateParameterFile = ".\app\qdslab-app.parameters.json"
$subscriptionId = "a538b62c-01c0-4fd3-acc4-e3b725f57982"
$spnID = "b71a3a56-e7d0-4c10-a323-02f457c8a3aa"
$scmGroupID = "97ece1e6-eddc-4861-a6d9-80f14630cf50"

Select-AzureRmSubscription -SubscriptionId $subscriptionId
$rgCheck = Get-AzureRmResourceGroup | Where-Object {$_.ResourceGroupName -eq $resourceGroupName}
if (!$rgCheck) {
    Write-Host "Creating Resource Group " $resourceGroupName
    New-AzureRmResourceGroup -Name $resourceGroupName -Location $resourceGroupLocation -Tag $tag
    New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
}
else {
    $scopeID = "/subscriptions/" + $subscriptionId + "/resourceGroups/" + $resourceGroupName
    $roleAssignment = Get-AzureRmRoleAssignment -ResourceGroupName $resourceGroupName | Where-Object {$_.Scope -eq $scopeID}
    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).ObjectId -ne $spnID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }

    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).ObjectId -ne $scmGroupID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }
}
New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName `
-TemplateFile $templateFile `
-TemplateParameterFile $templateParameterFile
Clear-Variable resourceGroupName, resourceGroupLocation, deploymentName, templateFile, templateParameterFile, subscriptionId, spnID, scmGroupID, rgCheck, scopeID, roleAssignment
```

###Deploying DSLAB APP to Enabling Subscription - STG
```
$resourceGroupName = "AZRG-ENA-DASDSLAB-STG"
$resourceGroupLocation = "East US 2"
$deploymentName = "dslab-app"
$templateFile = ".\app\dslab-app.json"
$templateParameterFile = ".\app\sdslab-app.parameters.json"
$subscriptionId = "bfc7eac2-0d08-4251-921e-5fe25ba65b98"
$spnID = "3042f2f4-880a-489d-9edf-7294d9c35eb6"
$scmGroupID = "97ece1e6-eddc-4861-a6d9-80f14630cf50"

Select-AzureRmSubscription -SubscriptionId $subscriptionId
$rgCheck = Get-AzureRmResourceGroup | Where-Object {$_.ResourceGroupName -eq $resourceGroupName}
if (!$rgCheck) {
    Write-Host "Creating Resource Group " $resourceGroupName
    New-AzureRmResourceGroup -Name $resourceGroupName -Location $resourceGroupLocation -Tag $tag
    New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
}
else {
    $scopeID = "/subscriptions/" + $subscriptionId + "/resourceGroups/" + $resourceGroupName
    $roleAssignment = Get-AzureRmRoleAssignment -ResourceGroupName $resourceGroupName | Where-Object {$_.Scope -eq $scopeID}
    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).ObjectId -ne $spnID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }

    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).ObjectId -ne $scmGroupID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }
}
New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName `
-TemplateFile $templateFile `
-TemplateParameterFile $templateParameterFile
Clear-Variable resourceGroupName, resourceGroupLocation, deploymentName, templateFile, templateParameterFile, subscriptionId, spnID, scmGroupID, rgCheck, scopeID, roleAssignment
```

###Deploying DSLAB APP to Enabling Subscription - PRD
```
$resourceGroupName = "AZRG-ENA-DASDSLAB-PRD"
$resourceGroupLocation = "East US 2"
$deploymentName = "dslab-app"
$templateFile = ".\app\dslab-app.json"
$templateParameterFile = ".\app\dslab-app.parameters.json"
$subscriptionId = "bfc7eac2-0d08-4251-921e-5fe25ba65b98"
$spnID = "3042f2f4-880a-489d-9edf-7294d9c35eb6"
$scmGroupID = "97ece1e6-eddc-4861-a6d9-80f14630cf50"

Select-AzureRmSubscription -SubscriptionId $subscriptionId
$rgCheck = Get-AzureRmResourceGroup | Where-Object {$_.ResourceGroupName -eq $resourceGroupName}
if (!$rgCheck) {
    Write-Host "Creating Resource Group " $resourceGroupName
    New-AzureRmResourceGroup -Name $resourceGroupName -Location $resourceGroupLocation -Tag $tag
    New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
}
else {
    $scopeID = "/subscriptions/" + $subscriptionId + "/resourceGroups/" + $resourceGroupName
    $roleAssignment = Get-AzureRmRoleAssignment -ResourceGroupName $resourceGroupName | Where-Object {$_.Scope -eq $scopeID}
    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).ObjectId -ne $spnID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }

    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).ObjectId -ne $scmGroupID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }
}
New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName `
-TemplateFile $templateFile `
-TemplateParameterFile $templateParameterFile
Clear-Variable resourceGroupName, resourceGroupLocation, deploymentName, templateFile, templateParameterFile, subscriptionId, spnID, scmGroupID, rgCheck, scopeID, roleAssignment
```

###Deploying DSLAB APP to Enabling Subscription - BCP
```
$resourceGroupName = "AZRG-ENA-DASDSLAB-PRD"
$resourceGroupLocation = "East US 2"
$deploymentName = "dslab-app"
$templateFile = ".\app\dslab-app.json"
$templateParameterFile = ".\app\bdslab-app.parameters.json"
$subscriptionId = "bfc7eac2-0d08-4251-921e-5fe25ba65b98"
$spnID = "3042f2f4-880a-489d-9edf-7294d9c35eb6"
$scmGroupID = "97ece1e6-eddc-4861-a6d9-80f14630cf50"

Select-AzureRmSubscription -SubscriptionId $subscriptionId
$rgCheck = Get-AzureRmResourceGroup | Where-Object {$_.ResourceGroupName -eq $resourceGroupName}
if (!$rgCheck) {
    Write-Host "Creating Resource Group " $resourceGroupName
    New-AzureRmResourceGroup -Name $resourceGroupName -Location $resourceGroupLocation -Tag $tag
    New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
}
else {
    $scopeID = "/subscriptions/" + $subscriptionId + "/resourceGroups/" + $resourceGroupName
    $roleAssignment = Get-AzureRmRoleAssignment -ResourceGroupName $resourceGroupName | Where-Object {$_.Scope -eq $scopeID}
    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).ObjectId -ne $spnID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }

    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).ObjectId -ne $scmGroupID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }
}
New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName `
-TemplateFile $templateFile `
-TemplateParameterFile $templateParameterFile
Clear-Variable resourceGroupName, resourceGroupLocation, deploymentName, templateFile, templateParameterFile, subscriptionId, spnID, scmGroupID, rgCheck, scopeID, roleAssignment
```

###Deploying DSLAB Databricks to Enabling Subscription - DEV
```
$resourceGroupName = "AZRG-ENA-DASDSLAB-DEV"
$resourceGroupLocation = "East US 2"
$deploymentName = "dslab-databricks"
$templateFile = ".\databricks\dslab-databricks.json"
$templateParameterFile = ".\databricks\ddslab-databricks.parameters.json"
$subscriptionId = "a538b62c-01c0-4fd3-acc4-e3b725f57982"
$spnID = "b71a3a56-e7d0-4c10-a323-02f457c8a3aa"
$scmGroupID = "97ece1e6-eddc-4861-a6d9-80f14630cf50"

Select-AzureRmSubscription -SubscriptionId $subscriptionId
$rgCheck = Get-AzureRmResourceGroup | Where-Object {$_.ResourceGroupName -eq $resourceGroupName}
if (!$rgCheck) {
    Write-Host "Creating Resource Group " $resourceGroupName
    New-AzureRmResourceGroup -Name $resourceGroupName -Location $resourceGroupLocation -Tag $tag
    New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
}
else {
    $scopeID = "/subscriptions/" + $subscriptionId + "/resourceGroups/" + $resourceGroupName
    $roleAssignment = Get-AzureRmRoleAssignment -ResourceGroupName $resourceGroupName | Where-Object {$_.Scope -eq $scopeID}
    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).ObjectId -ne $spnID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }

    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).ObjectId -ne $scmGroupID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }
}
New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName `
-TemplateFile $templateFile `
-TemplateParameterFile $templateParameterFile
Clear-Variable resourceGroupName, resourceGroupLocation, deploymentName, templateFile, templateParameterFile, subscriptionId, spnID, scmGroupID, rgCheck, scopeID, roleAssignment
```

###Deploying DSLAB Databricks to Enabling Subscription - QAS
```
$resourceGroupName = "AZRG-ENA-DASDSLAB-QAS"
$resourceGroupLocation = "East US 2"
$deploymentName = "dslab-databricks"
$templateFile = ".\databricks\dslab-databricks.json"
$templateParameterFile = ".\databricks\qdslab-databricks.parameters.json"
$subscriptionId = "a538b62c-01c0-4fd3-acc4-e3b725f57982"
$spnID = "b71a3a56-e7d0-4c10-a323-02f457c8a3aa"
$scmGroupID = "97ece1e6-eddc-4861-a6d9-80f14630cf50"

Select-AzureRmSubscription -SubscriptionId $subscriptionId
$rgCheck = Get-AzureRmResourceGroup | Where-Object {$_.ResourceGroupName -eq $resourceGroupName}
if (!$rgCheck) {
    Write-Host "Creating Resource Group " $resourceGroupName
    New-AzureRmResourceGroup -Name $resourceGroupName -Location $resourceGroupLocation -Tag $tag
    New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
}
else {
    $scopeID = "/subscriptions/" + $subscriptionId + "/resourceGroups/" + $resourceGroupName
    $roleAssignment = Get-AzureRmRoleAssignment -ResourceGroupName $resourceGroupName | Where-Object {$_.Scope -eq $scopeID}
    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).ObjectId -ne $spnID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }

    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).ObjectId -ne $scmGroupID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }
}
New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName `
-TemplateFile $templateFile `
-TemplateParameterFile $templateParameterFile
Clear-Variable resourceGroupName, resourceGroupLocation, deploymentName, templateFile, templateParameterFile, subscriptionId, spnID, scmGroupID, rgCheck, scopeID, roleAssignment
```

###Deploying DSLAB Databricks to Enabling Subscription - STG
```
$resourceGroupName = "AZRG-ENA-DASDSLAB-STG"
$resourceGroupLocation = "East US 2"
$deploymentName = "dslab-databricks"
$templateFile = ".\databricks\dslab-databricks.json"
$templateParameterFile = ".\databricks\sdslab-databricks.parameters.json"
$subscriptionId = "bfc7eac2-0d08-4251-921e-5fe25ba65b98"
$spnID = "3042f2f4-880a-489d-9edf-7294d9c35eb6"
$scmGroupID = "97ece1e6-eddc-4861-a6d9-80f14630cf50"

Select-AzureRmSubscription -SubscriptionId $subscriptionId
$rgCheck = Get-AzureRmResourceGroup | Where-Object {$_.ResourceGroupName -eq $resourceGroupName}
if (!$rgCheck) {
    Write-Host "Creating Resource Group " $resourceGroupName
    New-AzureRmResourceGroup -Name $resourceGroupName -Location $resourceGroupLocation -Tag $tag
    New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
}
else {
    $scopeID = "/subscriptions/" + $subscriptionId + "/resourceGroups/" + $resourceGroupName
    $roleAssignment = Get-AzureRmRoleAssignment -ResourceGroupName $resourceGroupName | Where-Object {$_.Scope -eq $scopeID}
    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).ObjectId -ne $spnID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }

    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).ObjectId -ne $scmGroupID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }
}
New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName `
-TemplateFile $templateFile `
-TemplateParameterFile $templateParameterFile
Clear-Variable resourceGroupName, resourceGroupLocation, deploymentName, templateFile, templateParameterFile, subscriptionId, spnID, scmGroupID, rgCheck, scopeID, roleAssignment
```

###Deploying DSLAB Databricks to Enabling Subscription - PRD
```
$resourceGroupName = "AZRG-ENA-DASDSLAB-PRD"
$resourceGroupLocation = "East US 2"
$deploymentName = "dslab-databricks"
$templateFile = ".\databricks\dslab-databricks.json"
$templateParameterFile = ".\databricks\dslab-databricks.parameters.json"
$subscriptionId = "bfc7eac2-0d08-4251-921e-5fe25ba65b98"
$spnID = "3042f2f4-880a-489d-9edf-7294d9c35eb6"
$scmGroupID = "97ece1e6-eddc-4861-a6d9-80f14630cf50"

Select-AzureRmSubscription -SubscriptionId $subscriptionId
$rgCheck = Get-AzureRmResourceGroup | Where-Object {$_.ResourceGroupName -eq $resourceGroupName}
if (!$rgCheck) {
    Write-Host "Creating Resource Group " $resourceGroupName
    New-AzureRmResourceGroup -Name $resourceGroupName -Location $resourceGroupLocation -Tag $tag
    New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
}
else {
    $scopeID = "/subscriptions/" + $subscriptionId + "/resourceGroups/" + $resourceGroupName
    $roleAssignment = Get-AzureRmRoleAssignment -ResourceGroupName $resourceGroupName | Where-Object {$_.Scope -eq $scopeID}
    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).ObjectId -ne $spnID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }

    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).ObjectId -ne $scmGroupID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }
}
New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName `
-TemplateFile $templateFile `
-TemplateParameterFile $templateParameterFile
Clear-Variable resourceGroupName, resourceGroupLocation, deploymentName, templateFile, templateParameterFile, subscriptionId, spnID, scmGroupID, rgCheck, scopeID, roleAssignment
```

###Deploying DSLAB Databricks to Enabling Subscription - BCP
```
$resourceGroupName = "AZRG-ENA-DASDSLAB-BCP"
$resourceGroupLocation = "Central US"
$deploymentName = "dslab-databricks"
$templateFile = ".\databricks\dslab-databricks.json"
$templateParameterFile = ".\databricks\bdslab-databricks.parameters.json"
$subscriptionId = "bfc7eac2-0d08-4251-921e-5fe25ba65b98"
$spnID = "3042f2f4-880a-489d-9edf-7294d9c35eb6"
$scmGroupID = "97ece1e6-eddc-4861-a6d9-80f14630cf50"

Select-AzureRmSubscription -SubscriptionId $subscriptionId
$rgCheck = Get-AzureRmResourceGroup | Where-Object {$_.ResourceGroupName -eq $resourceGroupName}
if (!$rgCheck) {
    Write-Host "Creating Resource Group " $resourceGroupName
    New-AzureRmResourceGroup -Name $resourceGroupName -Location $resourceGroupLocation -Tag $tag
    New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
}
else {
    $scopeID = "/subscriptions/" + $subscriptionId + "/resourceGroups/" + $resourceGroupName
    $roleAssignment = Get-AzureRmRoleAssignment -ResourceGroupName $resourceGroupName | Where-Object {$_.Scope -eq $scopeID}
    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).ObjectId -ne $spnID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }

    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).ObjectId -ne $scmGroupID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }
}
New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName `
-TemplateFile $templateFile `
-TemplateParameterFile $templateParameterFile
Clear-Variable resourceGroupName, resourceGroupLocation, deploymentName, templateFile, templateParameterFile, subscriptionId, spnID, scmGroupID, rgCheck, scopeID, roleAssignment
```
###Deploying DSLAB KeyVault to Enabling Subscription - DEV
```
$resourceGroupName = "AZRG-ENA-DASDSLAB-DEV"
$resourceGroupLocation = "East US 2"
$deploymentName = "dslab-kv"
$templateFile = ".\kv\dslab-kv.json"
$templateParameterFile = ".\kv\ddslab-kv.parameters.json"
$subscriptionId = "a538b62c-01c0-4fd3-acc4-e3b725f57982"
$spnID = "b71a3a56-e7d0-4c10-a323-02f457c8a3aa"
$scmGroupID = "97ece1e6-eddc-4861-a6d9-80f14630cf50"

Select-AzureRmSubscription -SubscriptionId $subscriptionId
$rgCheck = Get-AzureRmResourceGroup | Where-Object {$_.ResourceGroupName -eq $resourceGroupName}
if (!$rgCheck) {
    Write-Host "Creating Resource Group " $resourceGroupName
    New-AzureRmResourceGroup -Name $resourceGroupName -Location $resourceGroupLocation -Tag $tag
    New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
}
else {
    $scopeID = "/subscriptions/" + $subscriptionId + "/resourceGroups/" + $resourceGroupName
    $roleAssignment = Get-AzureRmRoleAssignment -ResourceGroupName $resourceGroupName | Where-Object {$_.Scope -eq $scopeID}
    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).ObjectId -ne $spnID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }

    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).ObjectId -ne $scmGroupID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }
}
New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName `
-TemplateFile $templateFile `
-TemplateParameterFile $templateParameterFile
Clear-Variable resourceGroupName, resourceGroupLocation, deploymentName, templateFile, templateParameterFile, subscriptionId, spnID, scmGroupID, rgCheck, scopeID, roleAssignment
```

###Deploying DSLAB KeyVault to Enabling Subscription - QAS
```
$resourceGroupName = "AZRG-ENA-DASDSLAB-QAS"
$resourceGroupLocation = "East US 2"
$deploymentName = "dslab-kv"
$templateFile = ".\kv\dslab-kv.json"
$templateParameterFile = ".\kv\qdslab-kv.parameters.json"
$subscriptionId = "a538b62c-01c0-4fd3-acc4-e3b725f57982"
$spnID = "b71a3a56-e7d0-4c10-a323-02f457c8a3aa"
$scmGroupID = "97ece1e6-eddc-4861-a6d9-80f14630cf50"

Select-AzureRmSubscription -SubscriptionId $subscriptionId
$rgCheck = Get-AzureRmResourceGroup | Where-Object {$_.ResourceGroupName -eq $resourceGroupName}
if (!$rgCheck) {
    Write-Host "Creating Resource Group " $resourceGroupName
    New-AzureRmResourceGroup -Name $resourceGroupName -Location $resourceGroupLocation -Tag $tag
    New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
}
else {
    $scopeID = "/subscriptions/" + $subscriptionId + "/resourceGroups/" + $resourceGroupName
    $roleAssignment = Get-AzureRmRoleAssignment -ResourceGroupName $resourceGroupName | Where-Object {$_.Scope -eq $scopeID}
    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).ObjectId -ne $spnID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }

    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).ObjectId -ne $scmGroupID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }
}
New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName `
-TemplateFile $templateFile `
-TemplateParameterFile $templateParameterFile
Clear-Variable resourceGroupName, resourceGroupLocation, deploymentName, templateFile, templateParameterFile, subscriptionId, spnID, scmGroupID, rgCheck, scopeID, roleAssignment
```

###Deploying DSLAB KeyVault to Enabling Subscription - STG
```
$resourceGroupName = "AZRG-ENA-DASDSLAB-STG"
$resourceGroupLocation = "East US 2"
$deploymentName = "dslab-kv"
$templateFile = ".\kv\dslab-kv.json"
$templateParameterFile = ".\kv\sdslab-kv.parameters.json"
$subscriptionId = "bfc7eac2-0d08-4251-921e-5fe25ba65b98"
$spnID = "3042f2f4-880a-489d-9edf-7294d9c35eb6"
$scmGroupID = "97ece1e6-eddc-4861-a6d9-80f14630cf50"

Select-AzureRmSubscription -SubscriptionId $subscriptionId
$rgCheck = Get-AzureRmResourceGroup | Where-Object {$_.ResourceGroupName -eq $resourceGroupName}
if (!$rgCheck) {
    Write-Host "Creating Resource Group " $resourceGroupName
    New-AzureRmResourceGroup -Name $resourceGroupName -Location $resourceGroupLocation -Tag $tag
    New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
}
else {
    $scopeID = "/subscriptions/" + $subscriptionId + "/resourceGroups/" + $resourceGroupName
    $roleAssignment = Get-AzureRmRoleAssignment -ResourceGroupName $resourceGroupName | Where-Object {$_.Scope -eq $scopeID}
    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).ObjectId -ne $spnID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }

    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).ObjectId -ne $scmGroupID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }
}
New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName `
-TemplateFile $templateFile `
-TemplateParameterFile $templateParameterFile
Clear-Variable resourceGroupName, resourceGroupLocation, deploymentName, templateFile, templateParameterFile, subscriptionId, spnID, scmGroupID, rgCheck, scopeID, roleAssignment
```

###Deploying DSLAB KeyVault to Enabling Subscription - PRD
```
$resourceGroupName = "AZRG-ENA-DASDSLAB-PRD"
$resourceGroupLocation = "East US 2"
$deploymentName = "dslab-kv"
$templateFile = ".\kv\dslab-kv.json"
$templateParameterFile = ".\kv\dslab-kv.parameters.json"
$subscriptionId = "bfc7eac2-0d08-4251-921e-5fe25ba65b98"
$spnID = "3042f2f4-880a-489d-9edf-7294d9c35eb6"
$scmGroupID = "97ece1e6-eddc-4861-a6d9-80f14630cf50"

Select-AzureRmSubscription -SubscriptionId $subscriptionId
$rgCheck = Get-AzureRmResourceGroup | Where-Object {$_.ResourceGroupName -eq $resourceGroupName}
if (!$rgCheck) {
    Write-Host "Creating Resource Group " $resourceGroupName
    New-AzureRmResourceGroup -Name $resourceGroupName -Location $resourceGroupLocation -Tag $tag
    New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
}
else {
    $scopeID = "/subscriptions/" + $subscriptionId + "/resourceGroups/" + $resourceGroupName
    $roleAssignment = Get-AzureRmRoleAssignment -ResourceGroupName $resourceGroupName | Where-Object {$_.Scope -eq $scopeID}
    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).ObjectId -ne $spnID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }

    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).ObjectId -ne $scmGroupID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }
}
New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName `
-TemplateFile $templateFile `
-TemplateParameterFile $templateParameterFile
Clear-Variable resourceGroupName, resourceGroupLocation, deploymentName, templateFile, templateParameterFile, subscriptionId, spnID, scmGroupID, rgCheck, scopeID, roleAssignment
```

###Deploying DSLAB KeyVault to Enabling Subscription - BCP
```
$resourceGroupName = "AZRG-ENA-DASDSLAB-BCP"
$resourceGroupLocation = "Central US"
$deploymentName = "dslab-kv"
$templateFile = ".\kv\dslab-kv.json"
$templateParameterFile = ".\kv\bdslab-kv.parameters.json"
$subscriptionId = "bfc7eac2-0d08-4251-921e-5fe25ba65b98"
$spnID = "3042f2f4-880a-489d-9edf-7294d9c35eb6"
$scmGroupID = "97ece1e6-eddc-4861-a6d9-80f14630cf50"

Select-AzureRmSubscription -SubscriptionId $subscriptionId
$rgCheck = Get-AzureRmResourceGroup | Where-Object {$_.ResourceGroupName -eq $resourceGroupName}
if (!$rgCheck) {
    Write-Host "Creating Resource Group " $resourceGroupName
    New-AzureRmResourceGroup -Name $resourceGroupName -Location $resourceGroupLocation -Tag $tag
    New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
}
else {
    $scopeID = "/subscriptions/" + $subscriptionId + "/resourceGroups/" + $resourceGroupName
    $roleAssignment = Get-AzureRmRoleAssignment -ResourceGroupName $resourceGroupName | Where-Object {$_.Scope -eq $scopeID}
    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).ObjectId -ne $spnID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $spnID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $spnID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }

    if ( (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).ObjectId -ne $scmGroupID) -or (($roleAssignment | Where-Object {$_.ObjectId -eq $scmGroupID}).RoleDefinitionName -ne "Contributor")) {
        New-AzureRmRoleAssignment -ObjectId $scmGroupID -RoleDefinitionName "Contributor" -ResourceGroupName $resourceGroupName
    }
}
New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName `
-TemplateFile $templateFile `
-TemplateParameterFile $templateParameterFile
Clear-Variable resourceGroupName, resourceGroupLocation, deploymentName, templateFile, templateParameterFile, subscriptionId, spnID, scmGroupID, rgCheck, scopeID, roleAssignment
```
