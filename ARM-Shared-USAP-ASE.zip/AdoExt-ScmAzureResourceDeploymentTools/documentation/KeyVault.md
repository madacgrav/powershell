#  Azure Resource Deployment: Keyvault 

[TOC]

## Overview

The Azure Resource Deployment Tool - Keyvault is used to create or update a [keyvault](https://docs.microsoft.com/en-us/azure/key-vault/) to a Deloitte Azure Resource Group.  The task works on a Deloitte on-premise Azure Pipeline agent running windows.


## Contact Information

Please report a problem at to the US SCM Platform Mgmt, <usscmplatformmgmt@deloitte.com>, if you are facing any issues with making this task work.  You can also share feedback about the task like, what more functionality should be added to the task, what other tasks you would like to have, at the same place.

## Pre-requisites for the task

The following pre-requisites need to be setup in the target machine(s) for the task to work properly.

##### Azure Subscription

To deploy to Azure, an Azure subscription has to be linked to Team Foundation Server or to Azure Pipelines using the Services tab in the Account Administration section. Add the Azure subscription to use in the Build or Release Management definition by opening the Account Administration screen (gear icon on the top-right of the screen) and then click on the Services Tab.

##### Azure Resource Group

To deploy a keyvault to Deloitte Azure you will need to already have a resource group created in the subscription deisred and you will need to know it's name.

## Deployment

### Parameters of the task
The task is used to deploy a Keyvault to Azure. The mandatory fields are highlighted with a *.

* **Azure RM Subscription\*:** Select the AzureRM Subscription. If none exists, then click on the **Manage** link, to navigate to the Services tab in the Administrators panel. In the tab click on **New Service Endpoint** and select **Azure Resource Manager** from the dropdown.

* **Resource Group\*:** Select the Azure Resource Group that will contain the Azure Keyvault.

* **Project Code\*:** Specify the name of the project code to be used by this application (3-6 characters)

* **Azure Region\*:** Select the Azure region where the Azure Keyvault will be created.

* **Azure Keyvault Type\*:** Select the type of Keyvault to be created - shared, secret or config.  A secret keyvault is used for those sensitive values that would normally be stored in a web.config.  A config keyvault is used for those values .... A shared keyvault is used for when multiple application share access to a single keyvault.

* **Log Retention Days:** Specify the number of days that the logs for this resource need to be kept.


### Output Variables



### FAQ

