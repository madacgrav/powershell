#  Azure Resource Deployment: Custom KeyVault Access Policy

[TOC]

## Overview

The Azure Resource Deployment Tool - Custom Keyvault Access policy is used to create or update an access policy for a keyvault.  Access policies are what controls who/what can be accessed inside a Keyvault (Secrets, Keys, Certificates, Storage)


## Contact Information

Please report a problem at to the US SCM Platform Mgmt, <usscmplatformmgmt@deloitte.com>, if you are facing any issues with making this task work.  You can also share feedback about the task like, what more functionality should be added to the task, what other tasks you would like to have, at the same place.

## Pre-requisites for the task

The following pre-requisites need to be setup in the target machine(s) for the task to work properly.

##### Azure Subscription

To deploy to Azure, an Azure subscription has to be linked to Team Foundation Server or to Azure Pipelines using the Services tab in the Account Administration section. Add the Azure subscription to use in the Build or Release Management definition by opening the Account Administration screen (gear icon on the top-right of the screen) and then click on the Services Tab.

##### Azure Resource Group

To deploy a custom access policy to Deloitte Azure you will need to already have a resource group created in the subscription deisred and you will need to know it's name.

##### Azure KeyVault

To deploy a custom access policy to Deloitte Azure you will need to already have a keyvault created in the subscription deisred and you will need to know it's name.

##### User/SPN/Group ObjectID

To deploy a custom access policy to Deloitte Azure you will need to have the objectId of an existing SPN, Azure AD user or group.

## Deployment

### Parameters of the task
The task is used to deploy a Web App Service to Azure. The mandatory fields are highlighted with a *.

* **Azure RM Subscription\*:** Select the AzureRM Subscription. If none exists, then click on the **Manage** link, to navigate to the Services tab in the Administrators panel. In the tab click on **New Service Endpoint** and select **Azure Resource Manager** from the dropdown.


* **Resource Group\*:** Select the Azure Resource Group that where the Keyvault is contained.


* **KeyVault Name\*:** Select the Azure KeyVault that where the custom access policy will be applied.


* **ObjectID\*:** Specify the objectID of the Service Principal Name, AD User or Group that will used to grant access to the KeyVault via the custom access policy.


* **Key Access\*:** Select the level of Key access the objectID will be granted on the KeyVault via the custom access policy.


* **Secret Access\*:** Select the level of Secret access the objectID will be granted on the KeyVault via the custom access policy.


* **Certificate Access\*:** Select the level of Certificate access the objectID will be granted on the KeyVault via the custom access policy.


* **Storage Access\*:** Select the level of Storage access the objectID will be granted on the KeyVault via the custom access policy.

### Output Variables



### FAQ

