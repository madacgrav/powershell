#  Azure Resource Deployment

[TOC]

## Overview

The Azure Resource Deployment Tool is used to create and update resources in Azure via the Azure DevOps pipelines.

## Contact Information

Please report a problem at to the US SCM Platform Mgmt, <usscmplatformmgmt@deloitte.com>, if you are facing any issues with making this task work.  You can also share feedback about the task like, what more functionality should be added to the task, what other tasks you would like to have, at the same place.



## Naming Standard

The following is the naming standard used by the DDI team to create resources within Azure using the DDI tool.

   **(env)-(projectcode)-(regioncode)-(resource type)**

#### Types

 - (env)  - dev, qas, loa, stg, prd, bcp
 - (projectcode) - defined by application team
 - (regioncode) - eus, eus2, wus , wus2 ....
 - (resource type)
    - KeyVault  - kvsecret, kvconfig, kvshared
    - Storage Account    - sa
    - AppService   - web
    - AppServicePlan  - asp
    - ASE - ase
    - FailoverGroup  -dbfg
    - ElasticPool   -dbpool
    - Traffic Manager - tm
    etc ...



#### Examples:

 - **Keyvault Secret** - dev-glass-eus-kvsecret
 - **Storage Account** - devglasseussa
 - **AppService** - dev-glass-eus-web

#### Exceptions:

 - **database** - just type in name of database - no pattern


*** **any resource that does not allow dashes in name will not included them - ie storage accounts**


## Available Tasks

* **[SqlDatabase](/sqlDatabase)**

    The Azure Resource Deployment Tool - sqlDatabase is used to create or update a [sql database](https://docs.microsoft.com/en-us/azure/sql-database//) to a Deloitte Azure Resource Group.  The task works on a Deloitte on-premise Azure Pipeline agent running windows.


* **[WebAppSvc](/WebAppSvc)**

    The Azure Resource Deployment Tool - Web App Service is used to create or update a [web app service](https://docs.microsoft.com/en-us/azure/app-service/), [web app service plan](https://docs.microsoft.com/en-us/azure/app-service/overview-hosting-plans), and [application insights](https://docs.microsoft.com/en-us/azure/azure-monitor/overview) utilizing an [application service environment](https://docs.microsoft.com/en-us/azure/app-service/environment/intro) to a Deloitte Azure Resource Group.  The task works on a Deloitte on-premise Azure Pipeline agent running windows.


* **[KeyVault](/KeyVault)**

    The Azure Resource Deployment Tool - Keyvault is used to create or update a [keyvault](https://docs.microsoft.com/en-us/azure/key-vault/) to a Deloitte Azure Resource Group.  The task works on a Deloitte on-premise Azure Pipeline agent running windows.

* **[KeyVault Custom Access Policy](/kvCustomAccessPolicy)**

    The Azure Resource Deployment Tool - Custom Keyvault Access policy is used to create or update an access policy for a keyvault.  Access policies are what controls who/what can be accessed inside a Keyvault (Secrets, Keys, Certificates, Storage)

* **[Storage Account](/storageaccount)**

    The Azure Resource Deployment Tool - Storage Account is used to create or update a [storage account](https://docs.microsoft.com/en-us/azure/storage/) to a Deloitte Azure Resource Group.  The task works on a Deloitte on-premise Azure Pipeline agent running windows.


* **[Certificate](/certificate)**

    The Azure Resource Deployment Tool - Certificate is used to create or update a [web app service](https://docs.microsoft.com/en-us/azure/app-service/) and [web app service plan](https://docs.microsoft.com/en-us/azure/app-service/overview-hosting-plans) with a certificate and custom host name. The task works on a Deloitte on-premise Azure Pipeline agent running windows.

* **[Traffic Manager](/trafficmanager)**

    The Azure Resource Deployment Tool - Traffic Manager is used to create or update a [traffic manager](https://docs.microsoft.com/en-us/azure/traffic-manager/traffic-manager-overview) to a Deloitte Azure Resource Group.  The task works on a Deloitte on-premise Azure Pipeline agent running windows.


* **[SQL Server](/sqlServer)** Preview

    The Azure Resource Deployment Tool - SQL Server ....

