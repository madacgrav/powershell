#  Azure Resource Deployment: sqlPermissions 

[TOC]

## Overview

The Azure Resource Deployment Tool - sql Permissions is used to update the permissions of a Azure PaaS SQL database with an Azure AD group or user.


## Contact Information

Please report a problem at to the US SCM Platform Mgmt, <usscmplatformmgmt@deloitte.com>, if you are facing any issues with making this task work.  You can also share feedback about the task like, what more functionality should be added to the task, what other tasks you would like to have, at the same place.

## Pre-requisites for the task

The following pre-requisites need to be setup in the target machine(s) for the task to work properly.

##### Permissions to SQL Server

To apply permissions to an existing sql server and database you will need a valid user account that has ability to create or update security options.

##### Azure SQL Server Name

To apply permissions to a database the SQL server and database need to already exist and be funtional in Azure.

##### Azure Account or SPN 

To apply permissions to be a database the account,spn or group needs to already exist within Azure Active Directory.

## Deployment

### Parameters of the task
The task is used to deploy a Keyvault to Azure. The mandatory fields are highlighted with a *.

* **User Account Name\*:** Specify the user, group or SPN name that will be granted access to the database.


* **User Name\*:** Specify the username with permmissions to make security changes to the database.


* **Password\*:** Specify the password of the user account with permissions to make security changes to the database.  It is highly suggested this value to be stored in a variable that is "secured".

* **Database Name\*:** Specify the name of the database that will have it's permissions updated.

* **SqlServer Name\*:** Specify the full host name of the SQL server hosting the database.


### Output Variables



### FAQ

