#  Azure Resource Deployment: Traffic Manager

[TOC] 

## Overview

The Azure Resource Deployment Tool - Traffic Manager is used to create or update a [traffic manager](https://docs.microsoft.com/en-us/azure/traffic-manager/traffic-manager-overview) to a Deloitte Azure Resource Group.  The task works on a Deloitte on-premise Azure Pipeline agent running windows.


## Contact Information

Please report a problem at to the US SCM Platform Mgmt, <usscmplatformmgmt@deloitte.com>, if you are facing any issues with making this task work.  You can also share feedback about the task like, what more functionality should be added to the task, what other tasks you would like to have, at the same place.

## Pre-requisites for the task

The following pre-requisites need to be setup in the target machine(s) for the task to work properly.

##### Azure Subscription

To deploy to Azure, an Azure subscription has to be linked to Team Foundation Server or to Azure Pipelines using the Services tab in the Account Administration section. Add the Azure subscription to use in the Build or Release Management definition by opening the Account Administration screen (gear icon on the top-right of the screen) and then click on the Services Tab.

##### Azure Resource Group

To deploy a traffic manager to Deloitte Azure you will need to already have a resource group created in the subscription deisred and you will need to know it's name.

##### EndPoint HostName (URL)

To deploy a traffic manager to Deloitte Azure you will need to already have the hostname for your application created in the subscription deisred and you will need to know it's name.

## Deployment

### Parameters of the task
The task is used to deploy a traffic manager to Azure. The mandatory fields are highlighted with a *.

* **Azure RM Subscription\*:** Select the AzureRM Subscription. If none exists, then click on the **Manage** link, to navigate to the Services tab in the Administrators panel. In the tab click on **New Service Endpoint** and select **Azure Resource Manager** from the dropdown.

* **Resource Group\*:** Select the Azure Resource Group that will contain the Azure App Service.

* **Project Code\*:** Specify the project code for this application. (3-6 characters)

* **EndPoint Location\*:** Select the EndPoint location (Azure Region) where the endpoint is pointed.

* **EndPoint Target\*:** Specify  one of the endpoints name (hostname) to configure the Traffic Manager.

* **Secondary EndPoint Location\*:** Select the secondary EndPoint location (Azure Region) where the endpoint is pointed.

* **Secondary EndPoint Target\*:** Specify th second endpoints name (hostname) to configure the Traffic Manager.






### Output Variables



### FAQ

