#  Azure Resource Deployment: SQL Database 

[TOC]

## Overview

The Azure Resource Deployment Tool - sqlDatabase is used to create or update a [sql database](https://docs.microsoft.com/en-us/azure/sql-database//) to a Deloitte Azure Resource Group.  The task works on a Deloitte on-premise Azure Pipeline agent running windows.


## Contact Information

Please report a problem at to the US SCM Platform Mgmt, <usscmplatformmgmt@deloitte.com>, if you are facing any issues with making this task work.  You can also share feedback about the task like, what more functionality should be added to the task, what other tasks you would like to have, at the same place.

## Pre-requisites for the task

The following pre-requisites need to be setup in the target machine(s) for the task to work properly.

##### Azure Subscription

To deploy to Azure, an Azure subscription has to be linked to Team Foundation Server or to Azure Pipelines using the Services tab in the Account Administration section. Add the Azure subscription to use in the Build or Release Management definition by opening the Account Administration screen (gear icon on the top-right of the screen) and then click on the Services Tab.

##### Azure Resource Group

To deploy a sql database to Deloitte Azure you will need to already have a resource group created in the subscription deisred and you will need to know it's name.

##### Azure Paas SQL Server

To deploy a sql database to Deloitte Azure you will need to already have a PaaS sql Server created in the subscription deisred and you will need to know it's name.

## Deployment

### Parameters of the task
The task is used to deploy a SQL database and Elastic Pool to Azure. The mandatory fields are highlighted with a *.

* **Azure RM Subscription\*:** Select the AzureRM Subscription. If none exists, then click on the **Manage** link, to navigate to the Services tab in the Administrators panel. In the tab click on **New Service Endpoint** and select **Azure Resource Manager** from the dropdown.


* **Resource Group\*:** Select the Azure Resource Group that is used by the SQL Server.


* **Azure SQL Server Name\*:** Specify the name of the sql server that the database will be deployed in Azure.

* **Azure SQL Database Namee\*:** Specify the name of the database that is to be created or updated in Azure.

* **SQL Database Collation:** Specify the name of the SQL collation.  It is set to *SQL_Latin1_General_CP1_CI_AS*, please leave default unless there is someting specifically needed.

* **Elastic Pool Edition\*:** Select the size/performance of the elastic pool to be used with the SQL database.

* **Elastic Pool DTU\*:** Select the number of DTUS to be used in the elastic pool.

* **Elastic Pool Database DTU Minimum\*:** Select the minimum DTU size for the database to utilize.

* **Elastic Pool Database DTU Maximum\*:** Select the maximum DTU size for the database to utilize.

* **Elastic Pool Database Storage\*:** Select the size of the storage to be used by the elastic pool.

* **Log Retention Days:** Specify the number of days that the logs for this resource need to be kept.

* **Workspace Id\*:** Specify the Azure ResourceId of the centralized OMS instance where all centralized logs are stored and managed.


### Output Variables



### FAQ

