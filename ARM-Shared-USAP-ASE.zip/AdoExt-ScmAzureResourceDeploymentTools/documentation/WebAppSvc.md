#  Azure Resource Deployment: Web Application Service 

[TOC]

## Overview

The Azure Resource Deployment Tool - Web App Service is used to create or update a [web app service](https://docs.microsoft.com/en-us/azure/app-service/), [web app service plan](https://docs.microsoft.com/en-us/azure/app-service/overview-hosting-plans), and [application insights](https://docs.microsoft.com/en-us/azure/azure-monitor/overview) utilizing an [application service environment](https://docs.microsoft.com/en-us/azure/app-service/environment/intro) to a Deloitte Azure Resource Group.  The task works on a Deloitte on-premise Azure Pipeline agent running windows.



## Contact Information

Please report a problem at to the US SCM Platform Mgmt, <usscmplatformmgmt@deloitte.com>, if you are facing any issues with making this task work.  You can also share feedback about the task like, what more functionality should be added to the task, what other tasks you would like to have, at the same place.

## Pre-requisites for the task

The following pre-requisites need to be setup in the target machine(s) for the task to work properly.

##### Azure Subscription

To deploy to Azure, an Azure subscription has to be linked to Team Foundation Server or to Azure Pipelines using the Services tab in the Account Administration section. Add the Azure subscription to use in the Build or Release Management definition by opening the Account Administration screen (gear icon on the top-right of the screen) and then click on the Services Tab.

##### Azure Resource Group

To deploy a webb app service to Deloitte Azure you will need to already have a resource group created in the subscription deisred and you will need to know it's name.

## Deployment

### Parameters of the task
The task is used to deploy a Web App Service to Azure. The mandatory fields are highlighted with a *.

* **Azure RM Subscription\*:** Select the AzureRM Subscription. If none exists, then click on the **Manage** link, to navigate to the Services tab in the Administrators panel. In the tab click on **New Service Endpoint** and select **Azure Resource Manager** from the dropdown.

* **App Service Name\*:** Specify the name of the web app service to be deployed to Azure.

* **Resource Group\*:** Select the Azure Resource Group that will contain the Azure App Service.

* **App Service Environment Resource Group\*:** Select the Azure ASE Resource Group that will contain the application service environment to be used by the web app service.

* **App Service Environment\*:** Select the Azure ASE name to be used by the web app service.

* **Azure Region\*:** Select the region where the web app service will be created. 

* **Worker Pool:** Select the worker type to be used for the app service plan. default: WP1

* **Number Of Workers From Worker Pool:** Specify the number of workers to be used in the pool. default: 1

 **Application Insights Enabled** Select if an instance of application insights is to be created along with web app service. default: checked

* **Log Retention Days:** Specify the number of days that the logs for this resource need to be kept.

* **Workspace Id\*:** Specify the Azure ResourceId of the centralized OMS instance where all centralized logs are stored and managed.


### Output Variables



### FAQ

