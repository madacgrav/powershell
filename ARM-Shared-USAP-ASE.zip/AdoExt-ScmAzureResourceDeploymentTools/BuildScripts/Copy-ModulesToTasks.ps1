
[CmdletBinding()]
param
()

$taskFolders = @(Get-ChildItem -Path $PSScriptRoot\..\Tasks -Depth 1).Where( { $_.Parent.Name -notlike 'Tasks' })

foreach ($folder in $taskFolders)
{
    $requiredModules = @(Select-String -Path "$($folder.FullName)\$($folder.Parent.Name).ps1" -Pattern 'Import-Module -Name ').Where( { $_ -notlike '*#*' })
    $modules = $requiredModules.ForEach( { $_.ToString().Split('\')[-1] })
    
    foreach ($module in $modules)
    {
        Write-Host "Copying Module "$module" contents to $($folder.Name)."
        $sourcePath = "$env:BUILD_ARTIFACTSTAGINGDIRECTORY\$module\"

        if (-not (Test-Path -Path $sourcePath))
        {
            throw "$sourcePath does not exist. Please verify module '$module' was saved to $env:BUILD_ARTIFACTSTAGINGDIRECTORY"
        }

        $destination = "$($folder.FullName)\ps_modules\$module\"
        $pathsToDelete = "$sourcePath\_rels", "$sourcePath\package", "$sourcePath\*.xml", "$sourcePath\*.nuspec"

        foreach ($path in $pathsToDelete)
        {
            if (Test-Path -Path $path)
            {
                Remove-Item -Path $path -Recurse -Force
            }
        }

        $splatCopyItem = @{
            Path        = $sourcePath
            Destination = $destination
            Include     = "*"
            Recurse     = $true
        }
        Copy-Item @splatCopyItem
    }
}

