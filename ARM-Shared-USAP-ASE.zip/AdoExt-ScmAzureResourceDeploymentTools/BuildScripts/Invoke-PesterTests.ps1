
[CmdletBinding()]
param
()

function Invoke-TestFailure
{
    param
    (
        [Parameter(Mandatory)]
        [ValidateSet('Unit', 'Integration', 'Acceptance')]
        [string]$TestType,

        [Parameter(Mandatory)]
        $PesterResults
    )

    if ($TestType -eq 'Unit') 
    {
        $errorID = 'UnitTestFailure'
    }
    elseif ($TestType -eq 'Integration')
    {
        $errorID = 'InetegrationTestFailure'
    }
    else
    {
        $errorID = 'AcceptanceTestFailure'
    }

    $errorCategory = [System.Management.Automation.ErrorCategory]::LimitsExceeded
    $errorMessage = "$TestType Test Failed: $($PesterResults.FailedCount) tests failed out of $($PesterResults.TotalCount) total test."
    $exception = New-Object -TypeName System.SystemException -ArgumentList $errorMessage
    $errorRecord = New-Object -TypeName System.Management.Automation.ErrorRecord -ArgumentList $exception, $errorID, $errorCategory, $null

    Write-Output "##vso[task.logissue type=error]Exception: $errorMessage"
    throw $errorRecord    
}

Import-Module -Name $env:BUILD_ARTIFACTSTAGINGDIRECTORY\Pester

$testsPath = (Resolve-Path "$PSScriptRoot\..\Tests").Path
$testResultsPath = "$testsPath\Results"

# Make sure Test Result location exists
New-Item $testResultsPath -ItemType Directory -Force

Write-Verbose "Starting unit tests..."
$pesterResults = Invoke-Pester -Path $testsPath -OutputFile "$testResultsPath\UnitTest.xml" -OutputFormat NUnitXml -PassThru

if ($pesterResults.FailedCount)
{
    Invoke-TestFailure -TestType Unit -PesterResults $pesterResults        
}
