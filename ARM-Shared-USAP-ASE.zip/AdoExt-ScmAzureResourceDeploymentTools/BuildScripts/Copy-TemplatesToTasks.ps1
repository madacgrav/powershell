
[CmdletBinding()]
param
()

$taskFolders = @(Get-ChildItem -Path $PSScriptRoot\..\Tasks -Depth 1).Where( { $_.Parent.Name -notlike 'Tasks' })

foreach ($folder in $taskFolders)
{
    $templateJson = Get-Content -Path "$($folder.FullName)\templates.json" -Raw -ErrorAction SilentlyContinue

    if (-not $templateJson)
    {
        Write-Host "Could not find a Template.json file for $($folder.name). No templates to copy to task."
        continue
    }
    
    $requiredTemplates = ConvertFrom-Json -InputObject $templateJson

    if (-not (Test-Path -Path "$($folder.FullName)\Templates" -PathType Container))
    {
        New-Item -ItemType Directory -Path $($folder.FullName) -Name Templates -Force -ErrorAction Stop
    }
    
    foreach ($template in $requiredTemplates)
    {
        $templateFileWithVersion = "$([System.IO.Path]::GetFileNameWithoutExtension($template.Name))_v$($template.version).json"
        $sourcePath = "$PSScriptRoot\..\Templates\$templateFileWithVersion"

        Write-Host "Copying Template $templateFileWithVersion to $($folder.Name)."        

        if (-not (Get-Item $sourcePath))
        {            
            throw "$sourcePath does not exist. Please verify template was saved to Extension Templates folder."
        }

        Copy-Item $sourcePath -Destination "$($folder.FullName)\Templates\$($template.Name)"
    }
}

