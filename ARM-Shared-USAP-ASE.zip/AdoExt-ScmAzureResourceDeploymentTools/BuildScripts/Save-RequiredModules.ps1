
[CmdletBinding()]
param
()

$modulesInfo = @(
    @{
        Name    = 'VstsTaskSdk'
        Version = '0.11.0'
    },
    @{
        Name    = 'Az.Accounts'
        Version = '1.6.2'
    },
    @{
        Name    = 'Az.Resources'
        Version = '1.6.2'
    },
    @{
        Name    = 'Az.ApplicationInsights'
        Version = '1.0.2'
    },
    @{
        Name    = 'Az.KeyVault'
        Version = '1.3.1'
    },
    @{
        Name    = 'Az.Websites'
        Version = '1.4.1'
    },
    @{
        Name    = 'Pester'
        Version = '4.4.2'
    },
    @{
        Name    = 'PSScriptAnalyzer'
        Version = '1.17.1'
    }
)
                
if (-not (Get-PSRepository -Name PSGallery))
{
    $spaltRegisterPSRepository = @{
        Name               = 'PSGallery'
        InstallationPolicy = 'Trusted'
        SourceLocation     = 'https://www.powershellgallery.com/api/v2'
        ErrorAction        = 'Stop'
    }
    Write-Host "Register-PSRepository @spaltRegisterPSRepository"
    Register-PSRepository @spaltRegisterPSRepository
}

if ((Get-PSRepository -Name PSGallery).InstallationPolicy -ne 'Trusted')
{
    Write-Host "Set-PSRepository -Name PSGallery -InstallationPolicy Trusted"
    Set-PSRepository -Name PSGallery -InstallationPolicy Trusted
}

foreach ($module in $modulesInfo)
{
    $modulePath = "$env:BUILD_ARTIFACTSTAGINGDIRECTORY\$($module.Name)"          
                  
    Write-Host "Saving module $($module.Name) with version $($module.Version)"
    Save-Module -Name $module.Name -Path "$env:BUILD_ARTIFACTSTAGINGDIRECTORY\" -Repository PSGallery -RequiredVersion $module.Version

    Write-Host "Moving $modulePath\$($module.Version)\* to $modulePath"
    Move-Item -Path "$modulePath\$($module.Version)\*" -Destination $modulePath -Force
                  
    Write-Host "Remove $modulePath\$($module.Version) directory"
    Remove-Item -Path "$modulePath\$($module.Version)" -Recurse -Force -Confirm:$false
}