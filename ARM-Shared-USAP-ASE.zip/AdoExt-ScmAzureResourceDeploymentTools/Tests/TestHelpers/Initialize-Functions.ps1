
[CmdletBinding()]
param
()

# Mock implementations for common Azure Pipelines task SDK functions.
function global:Get-VstsLocString
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory, Position = 1)]
        [string]$Key,
        [Parameter(Position = 2)]
        [object[]]$ArgumentList = @( )
    )

    $OFS = ' '
    "$Key$(if ($ArgumentList.Count) { " $ArgumentList" })"
}

function global:Import-VstsLocStrings
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory)]
        [string]$LiteralPath
    ) 
}

function global:Trace-VstsEnteringInvocation
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory)]
        [System.Management.Automation.InvocationInfo]$InvocationInfo,
        [string[]]$Parameter = '*'
    )

    Write-Verbose "Entering $(Get-VstsInvocationDescription__ $InvocationInfo)."
    $OFS = ", "
    if ($InvocationInfo.BoundParameters.Count -and $Parameter.Count)
    {
        if ($Parameter.Count -eq 1 -and $Parameter[0] -eq '*')
        {
            foreach ($key in $InvocationInfo.BoundParameters.Keys)
            {
                Write-Verbose " $($key): '$($InvocationInfo.BoundParameters[$key])'"
            }
        }
        else
        {
            foreach ($key in $InvocationInfo.BoundParameters.Keys)
            {
                foreach ($p in $Parameter)
                {
                    if ($key -like $p)
                    {
                        Write-Verbose " $($key): '$($InvocationInfo.BoundParameters[$key])'"
                        break
                    }
                }
            }
        }
    }

    if (@($InvocationInfo.UnboundArguments).Count)
    {
        for ($i = 0 ; $i -lt $InvocationInfo.UnboundArguments.Count ; $i++)
        {
            Write-Verbose " args[$i]: '$($InvocationInfo.UnboundArguments[$i])'"
        }
    }
}

function global:Trace-VstsLeavingInvocation
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory)]
        [System.Management.Automation.InvocationInfo]$InvocationInfo
    )

    Write-Verbose "Leaving $(Get-VstsInvocationDescription__ $InvocationInfo)."
}

function Get-VstsInvocationDescription__
{
    [CmdletBinding()]
    param
    (
        [System.Management.Automation.InvocationInfo]$InvocationInfo
    )

    if ($InvocationInfo.MyCommand.Path)
    {
        $InvocationInfo.MyCommand.Path
    }
    elseif ($InvocationInfo.MyCommand.Name)
    {
        $InvocationInfo.MyCommand.Name
    }
    else
    {
        $InvocationInfo.MyCommand.CommandType
    }
}

function global:Get-VstsInput
{
    [CmdletBinding(DefaultParameterSetName = 'Require')]
    param
    (
        [Parameter(Mandatory)]
        [string]$Name,
        [Parameter(ParameterSetName = 'Default')]
        $Default,
        [Parameter(ParameterSetName = 'Require')]
        [switch]$Require,
        [switch]$AsBool,
        [switch]$AsInt
    )

    if ($PSBoundParameters['Default'])
    {
        return $Default
    }

    $Name
}
function global:Get-VstsEndpoint { return @{auth = @{ scheme = "ServicePrincipal" } } }
function global:Get-AzOmsWorkspaceId { return 'SomeWorkspaceId' }
function global:Get-AzRegionCode { return 'eus' }

function global:New-AzResourceName { return @{Name = 'SomeResourceName' } }

function global:Update-PSModulePathForHostedAgent { }

function global:Initialize-AzSubscription { }

function global:New-AzResourceGroupDeployment { }

function global:Disconnect-AzSubscriptionAndClearContext { }
