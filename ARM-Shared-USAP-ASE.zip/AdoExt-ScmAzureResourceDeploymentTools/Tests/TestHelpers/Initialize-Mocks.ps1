
$cmdlets = 'Trace-VstsEnteringInvocation', 'Trace-VstsLeavingInvocation', 
'Update-PSModulePathForHostedAgent', 'Initialize-AzSubscription', 'New-AzResourceGroupDeployment',
'Disconnect-AzSubscriptionAndClearContext', 'Import-Module'

foreach ($cmdlet in $cmdlets)
{
    Mock -CommandName $cmdlet -MockWith { } -Verifiable
}

# Mock - Get-VstsInput -Name ConnectedServiceNameSelector -Default 'ConnectedServiceName'
$spaltMockParams = @{
    CommandName     = 'Get-VstsInput'
    MockWith        = { return 'connectedService:AzureRM' }
    Verifiable      = $true
    ParameterFilter = {
        $Name -eq 'ConnectedServiceNameSelector' -and $Default -eq 'ConnectedServiceName'
    }
}        
Mock @spaltMockParams

$serviceNameInput = Get-VstsInput -Name ConnectedServiceNameSelector -Default 'ConnectedServiceName'

# Mock - (Get-VstsInput -Name DeploymentEnvironmentName)
$spaltMockParams['MockWith'] = { return 'US-AZSUB-AME-ENA-DAS-SCM-NPD' }
$spaltMockParams['ParameterFilter'] = {
    $Name -eq 'DeploymentEnvironmentName'
}
Mock @spaltMockParams

# Mock - Get-VstsInput -Name $serviceNameInput -Default (Get-VstsInput -Name DeploymentEnvironmentName)
$spaltMockParams['MockWith'] = { return 'US-AZSUB-AME-ENA-DAS-SCM-NPD' }
$spaltMockParams['ParameterFilter'] = {
    $Name -eq $serviceNameInput -and $Default -eq 'US-AZSUB-AME-ENA-DAS-SCM-NPD'
}
Mock @spaltMockParams

# Mock - Get-VstsEndpoint -Name $serviceName -Require
$spaltMockParamsVstsEnpoint = @{
    CommandName     = 'Get-VstsEndpoint'
    MockWith        = { return @{auth = @{ scheme = "ServicePrincipal" } } }
    Verifiable      = $true
}        
Mock @spaltMockParamsVstsEnpoint

# Mock - Get-VstsInput -Name 'ResourceGroupName' -Require
$spaltMockParams['MockWith'] = { return 'someRgName' }
$spaltMockParams['ParameterFilter'] = {
    $Name -eq 'ResourceGroupName' -and $Require
}
Mock @spaltMockParams

# Mock - Get-VstsInput -Name 'AzureRegion' -Require
$spaltMockParams['MockWith'] = { return 'East US' }
$spaltMockParams['ParameterFilter'] = {
    $Name -eq 'AzureRegion' -and $Require
}
Mock @spaltMockParams

# Mock - Get-VstsInput -Name 'LogRetentionDays' -Require -AsInt
$spaltMockParams['MockWith'] = { return 90 }
$spaltMockParams['ParameterFilter'] = {
    $Name -eq 'LogRetentionDays' -and $Require -and $AsInt
}
Mock @spaltMockParams

# Mock - Get-VstsInput -Name 'ProjectCode' -Require
$spaltMockParams['MockWith'] = { return 'adoext' }
$spaltMockParams['ParameterFilter'] = {
    $Name -eq 'ProjectCode' -and $Require
}
Mock @spaltMockParams

# Mock - Get-VstsInput -Name 'ResourceUniqueId' -Require
$spaltMockParams['MockWith'] = { return 'svc01' }
$spaltMockParams['ParameterFilter'] = {
    $Name -eq 'ResourceUniqueId' -and $Require
}
Mock @spaltMockParams
