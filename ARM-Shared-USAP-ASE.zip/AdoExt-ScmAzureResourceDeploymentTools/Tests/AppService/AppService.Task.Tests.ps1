
$sut = Split-Path $MyInvocation.MyCommand.ScriptBlock.File -Leaf
$taskName = $sut.Split('.')[0]
$taskJsonPath = "$PSScriptRoot\..\..\Tasks\$taskName\$($taskName)V1\task.json"
$taskJson = Get-Content -Path $taskJsonPath -Raw
$task = Get-Item -Path $taskJsonPath

Describe "$($task.Name) for $taskName task" {
    
    $taskConvertedFromJson = ConvertFrom-Json -InputObject $taskJson
    
    BeforeAll {
        $ErrorActionPreference = 'SilentlyContinue'
    }
    
    AfterAll {
        $ErrorActionPreference = 'Stop'
    }

    Context "$($task.Name) Element Validation" {
        
        It 'Should have the correct Id' {
            $id = '5cb262b2-cc3b-4fc5-92f4-21336f37db97'
            $taskConvertedFromJson.id | Should -Be $id
        }

        It 'Should have the correct name' {
            $name = 'ScmAppService'
            $taskConvertedFromJson.name | Should -Be $name
        }
    }

    Context "$($task.Name) Inputs Validation" {

        It 'Should have correct inputs' {
            $inputs = @(
                @{
                    Name     = 'ConnectedServiceName'
                    Type     = 'connectedService:AzureRM'
                    required = $true
                },
                @{
                    Name     = 'ProjectCode'
                    Type     = 'string'
                    required = $true
                },
                @{
                    Name     = 'ResourceUniqueId'
                    Type     = 'string'
                    required = $true
                },
                @{
                    Name     = 'ResourceGroupName'
                    Type     = 'pickList'
                    required = $true
                },
                @{
                    Name     = 'AseResourceGroupName'
                    Type     = 'pickList'
                    required = $true
                },
                @{
                    Name     = 'AseName'
                    Type     = 'pickList'
                    required = $true
                },
                @{
                    Name     = 'AzureRegion'
                    Type     = 'pickList'
                    required = $true
                },
                @{
                    Name     = 'AppServiceType'
                    Type     = 'pickList'
                    required = $true
                },
                @{
                    Name     = 'CreateAppServicePlan'
                    Type     = 'boolean'
                    required = $false
                },
                @{
                    Name     = 'WorkerPool'
                    Type     = 'pickList'
                    required = $false
                },
                @{
                    Name     = 'NumberOfWorkersFromWorkerPool'
                    Type     = 'int'
                    required = $false
                },
                @{
                    Name     = 'AppServicePlanRgName'
                    Type     = 'pickList'
                    required = $true
                },
                @{
                    Name     = 'AppServicePlanName'
                    Type     = 'picklist'
                    required = $true
                },
                @{
                    Name     = 'AppInsightsName'
                    Type     = 'pickList'
                    required = $false
                },
                @{
                    Name     = 'LogRetentionDays'
                    Type     = 'int'
                    required = $false
                }
            )
            $taskInputs = $taskConvertedFromJson.inputs.name            

            foreach ($input in $inputs)
            {
                $taskInputs | Should -Contain $input['Name']
                $taskInput = @($taskConvertedFromJson.inputs).Where( { $_.name -eq $input['Name'] })
                $taskInput.type | Should -Be $input['Type']
                $taskInput.required | Should -Be $input['Required']
            }
        }
    }
}