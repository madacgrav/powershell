
$sut = Split-Path $MyInvocation.MyCommand.ScriptBlock.File -Leaf
$taskName = $sut.Split('.')[0]
$taskJsonPath = "$PSScriptRoot\..\..\Tasks\$taskName\$($taskName)V1\task.json"
$taskJson = Get-Content -Path $taskJsonPath -Raw
$task = Get-Item -Path $taskJsonPath

Describe "$($task.Name) for $taskName task" {
    
    $taskConvertedFromJson = ConvertFrom-Json -InputObject $taskJson
    
    BeforeAll {
        $ErrorActionPreference = 'SilentlyContinue'
    }
    
    AfterAll {
        $ErrorActionPreference = 'Stop'
    }

    Context "$($task.Name) Element Validation" {
        
        It 'Should have the correct Id' {
            $id = 'bf16d2aa-8a18-48c4-96db-eb85dba26183'
            $taskConvertedFromJson.id | Should -Be $id
        }

        It 'Should have the correct name' {
            $name = 'ScmCertificate'
            $taskConvertedFromJson.name | Should -Be $name
        }
    }

    Context "$($task.Name) Inputs Validation" {

        It 'Should have correct inputs' {
            $inputs = @(
                @{
                    Name     = 'ConnectedServiceName'
                    Type     = 'connectedService:AzureRM'
                    required = $true
                },
                @{
                    Name     = 'kvResourceGroupName'
                    Type     = 'pickList'
                    required = $true
                },
                @{
                    Name     = 'sharedKeyVault'
                    Type     = 'pickList'
                    required = $true
                },
                @{
                    Name     = 'ResourceGroupName'
                    Type     = 'pickList'
                    required = $true
                },
                @{
                    Name     = 'AppServiceOutput'
                    Type     = 'boolean'
                    required = $false
                },
                @{
                    Name     = 'certificateName'
                    Type     = 'string'
                    required = $true
                },
                @{
                    Name     = 'HostName'
                    Type     = 'string'
                    required = $true
                },
                @{
                    Name     = 'AppServiceName'
                    Type     = 'pickList'
                    required = $false
                },
                @{
                    Name     = 'AppServicePlan'
                    Type     = 'pickList'
                    required = $false
                },
                @{
                    Name     = 'AzureRegion'
                    Type     = 'pickList'
                    required = $false
                }
            )
            $taskInputs = $taskConvertedFromJson.inputs.name            

            foreach ($input in $inputs)
            {
                $taskInputs | Should -Contain $input['Name']
                $taskInput = @($taskConvertedFromJson.inputs).Where( { $_.name -eq $input['Name'] })
                $taskInput.type | Should -Be $input['Type']
                $taskInput.required | Should -Be $input['Required']
            }
        }
    }
}