
$sut = Split-Path $MyInvocation.MyCommand.ScriptBlock.File -Leaf
$armTemplateName = $sut.Split('.')[0]
$armTemplatePath = "$PSScriptRoot\..\..\Templates\$($armTemplateName)_v1.json"
$armTemplateJson = Get-Content -Path $armTemplatePath -Raw
$armTemplate = Get-Item -Path $armTemplatePath

Describe "ARM template $($armTemplate.Name)" {
    
    $template = ConvertFrom-Json -InputObject $armTemplateJson
    
    BeforeAll {
        $ErrorActionPreference = 'SilentlyContinue'
    }
    
    AfterAll {
        $ErrorActionPreference = 'Stop'
    }

    Context 'ARM Template Parameter Validation' {

        It 'Should have correct Parameters' {
            $parameters = @(
                @{
                    Name = 'aiName'
                    Type = 'string'
                },
                @{
                    Name = 'workspaceId'
                    Type = 'string'
                },
                @{
                    Name         = 'logsRetentionDays'                                        
                    Type         = 'int'
                    DefaultValue = 0
                }
            )
            $templateParams = $template.parameters.psobject.Properties.Name            

            foreach ($param in $parameters)
            {
                $templateParams | Should -Contain $param['Name']
                $template.parameters.$($param['Name']).type | Should -Be $param['Type']

                if ($param['DefaultValue'] -or $param['DefaultValue'] -eq '')
                {
                    $template.parameters.$($param['Name']).defaultValue | Should -Be $param['DefaultValue']
                }
            }
        }
    }

    Context 'ARM Template Output Validation' {

        It 'Should have correct Outputs' {
            $outputs = @(
                @{
                    Name = 'AppInsightsKey'
                    Type = 'string'
                },
                @{
                    Name = 'AppInsightsName'
                    Type = 'string'
                }
            )
            $templateOutputs = $template.outputs.psobject.Properties.Name            

            foreach ($output in $outputs)
            {
                $templateOutputs | Should -Contain $output['Name']
                $template.outputs.$($output['Name']).type | Should -Be $output['Type']
            }
        }
    }

    Context 'ARM Template Resource Validation' {

        It 'Should create the correct type of resource' {
            $types = 'Microsoft.Insights/components'

            foreach ($resourceType in $types)
            {
                $type = @($template.resources).Where( { $_.type -eq $resourceType }).type
                $type | Should -Be $resourceType
            }
        }
    }
}