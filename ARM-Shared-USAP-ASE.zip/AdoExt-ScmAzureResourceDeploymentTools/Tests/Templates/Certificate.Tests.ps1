
$sut = Split-Path $MyInvocation.MyCommand.ScriptBlock.File -Leaf
$armTemplateName = $sut.Split('.')[0]
$armTemplatePath = "$PSScriptRoot\..\..\Templates\$($armTemplateName)_v1.json"
$armTemplateJson = Get-Content -Path $armTemplatePath -Raw
$armTemplate = Get-Item -Path $armTemplatePath

Describe "ARM template $($armTemplate.Name)" {
    
    $template = ConvertFrom-Json -InputObject $armTemplateJson
    
    BeforeAll {
        $ErrorActionPreference = 'SilentlyContinue'
    }
    
    AfterAll {
        $ErrorActionPreference = 'Stop'
    }

    Context 'ARM Template Parameter Validation' {

        It 'Should have correct Parameters' {
            $parameters = @(
                @{
                    Name = 'webAppname'
                    Type = 'string'
                },
                @{
                    Name = 'webAppservicePlan'
                    Type = 'string'
                },
                @{
                    Name = 'location'
                    Type = 'string'
                },
                @{
                    Name = 'certificateName'
                    Type = 'string'
                },
                @{
                    Name = 'sharedKeyVaultId'
                    Type = 'string'
                },
                @{
                    Name = 'hostname'
                    Type = 'string'
                }
            )
            $templateParams = $template.parameters.psobject.Properties.Name            

            foreach ($param in $parameters)
            {
                $templateParams | Should -Contain $param['Name']
                $template.parameters.$($param['Name']).type | Should -Be $param['Type']

                if ($param['DefaultValue'] -or $param['DefaultValue'] -eq '')
                {
                    $template.parameters.$($param['Name']).defaultValue | Should -Be $param['DefaultValue']
                }
            }
        }
    }
    <#
    Context 'ARM Template Output Validation' {

        It 'Should have correct Outputs' {
            
        }
    }
    #>
    Context 'ARM Template Resource Validation' {

        It 'Should create the correct type of resource' {
            $types = 'Microsoft.Web/certificates', 'Microsoft.Web/sites/hostNameBindings'

            foreach ($resourceType in $types)
            {
                $type = @($template.resources).Where( { $_.type -eq $resourceType }).type
                $type | Should -Be $resourceType
            }            
        }
    }
}