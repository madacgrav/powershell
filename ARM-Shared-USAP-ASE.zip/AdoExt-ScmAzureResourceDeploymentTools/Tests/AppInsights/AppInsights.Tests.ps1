
$sut = Split-Path $MyInvocation.MyCommand.ScriptBlock.File -Leaf
$taskName = $sut.Split('.')[0]
$taskScriptPath = "$PSScriptRoot\..\..\Tasks\$taskName\$($taskName)V1\$taskName.ps1"
$script = Get-Item -Path $taskScriptPath

Describe "$($script.Name) for $taskName task" {
    
    . $PSScriptRoot\..\TestHelpers\Initialize-Functions.ps1
    . $PSScriptRoot\..\TestHelpers\Initialize-Mocks.ps1

    BeforeAll {
        $ErrorActionPreference = 'SilentlyContinue'
    }
    
    AfterAll {
        $ErrorActionPreference = 'Stop'
    }

    $resourceName = (New-AzResourceName).Name

    Context 'Azure Endpoint Validation' {
        
        Mock -CommandName Get-VstsEndpoint -MockWith { }

        It 'Should throw when no endpoint is found' {
            { . $script.FullName } | Should -Throw
        }

        It 'Should call Trace-VstsLeavingInvocation exactly one time when no endpoint is found' {
            Assert-MockCalled -CommandName Trace-VstsLeavingInvocation -Scope Context -Exactly 1
        }
    }    

    Context 'Azure OMS WorkspaceId Validation' {                
        
        Mock -CommandName Get-AzOmsWorkspaceId -MockWith { }

        It 'Should throw when no Workspace Id is found' {
            { . $script.FullName } | Should -Throw
        }

        It 'Should call Trace-VstsLeavingInvocation exactly one time when no Workspace Id is found' {
            Assert-MockCalled -CommandName Trace-VstsLeavingInvocation -Scope Context -Exactly 1
        }
    }    

    Context 'Azure Region Code Validation' {
        
        Mock -CommandName Get-AzRegionCode -MockWith { }
        
        It 'Should throw when no Azure Region Code is found' {
            { . $script.FullName } | Should -Throw
        }

        It 'Should call Trace-VstsLeavingInvocation exactly one time when no Azure Region Code is found' {
            Assert-MockCalled -CommandName Trace-VstsLeavingInvocation -Scope Context -Exactly 1
        }
    }

    Context 'Testing finally block in try/catch for Trace-VstsLeavingInvocation and Disconnect-AzSubscriptionAndClearContext' {

        It 'Should ALWAYS call Trace-VstsLeaving and Disconnect-Az - Success Test' {
            . $script.FullName
            Assert-MockCalled -CommandName Trace-VstsLeavingInvocation -Scope It -Exactly 1
            Assert-MockCalled -CommandName Disconnect-AzSubscriptionAndClearContext -Scope It -Exactly 1
        }

        It 'Should ALWAYS call Trace-VstsLeaving and Disconnect-Az - Error Test' {
            Mock -CommandName Initialize-AzSubscription -MockWith { throw 'SomeError' }
            { . $script.FullName } | Should throw
            Assert-MockCalled -CommandName Trace-VstsLeavingInvocation -Scope It -Exactly 1
            Assert-MockCalled -CommandName Disconnect-AzSubscriptionAndClearContext -Scope It -Exactly 1
        }
    }

    Context 'Cmdlets/Functions Script Should Call' {

        $cmdlets = 'Trace-VstsEnteringInvocation', 'Trace-VstsLeavingInvocation', 'Update-PSModulePathForHostedAgent', 
        'Initialize-AzSubscription', 'New-AzResourceGroupDeployment', 'Disconnect-AzSubscriptionAndClearContext'
        
        . $script.FullName

        foreach ($cmdlet in $cmdlets)
        {
            It "Should call $cmdlet exactly one time" {
                Assert-MockCalled -CommandName $cmdlet -Scope Context -Exactly 1
            }
        }        
    }

    Context 'Script Outputs Validation' {
        
        It 'Should output Azure DevOps Variables' {            
            $outputVarStrings = "##vsotask.setvariable variable=ado.AppInsightsName;$resourceName"
            $scriptOutput = . $script.FullName

            foreach ($outputVar in $outputVarStrings)
            {
                # This is dumb, but oh well
                # Have to remove [] in string because brackets are escape characters                
                $scriptOutputWeWant = @($scriptOutput -replace '\[|\]').Where( { $_ -eq $outputVar })
                $outputVar | Should -BeIn $scriptOutputWeWant
            }
        }
    }
    
    Context 'Script Inputs Validation' {        
        
        . $script.FullName
          
        It 'Should call Get-VstsInput for ServiceNameInput' {
            Assert-MockCalled -CommandName Get-VstsInput -Scope Context -Times 1 -Exactly -ParameterFilter {
                $Name -eq 'ConnectedServiceNameSelector' -and $Default -eq 'ConnectedServiceName'
            }
        }
        It 'Should call "Get-VstsInput -Name $serviceNameInput -Default (Get-VstsInput -Name DeploymentEnvironmentName)"' {
            Assert-MockCalled -CommandName Get-VstsInput -Scope Context -Times 1 -Exactly -ParameterFilter {                
                $Name -eq 'connectedService:AzureRM' -and $Default -eq 'US-AZSUB-AME-ENA-DAS-SCM-NPD'
            }
        }
        It 'Should call Get-VstsInput for ServiceName' {
            Assert-MockCalled -CommandName Get-VstsInput -Scope Context -Times 1 -Exactly -ParameterFilter {
                $Name -eq 'DeploymentEnvironmentName'
            }
        }
        It 'Should call Get-VstsEndpoint' {
            Assert-MockCalled -CommandName Get-VstsEndpoint -Scope Context -Times 1 -Exactly
        }
        It 'Should call Get-VstsInput for ResourceGroupName' {
            Assert-MockCalled -CommandName Get-VstsInput -Scope Context -Times 1 -Exactly -ParameterFilter {
                $Name -eq 'ResourceGroupName' -and $Require
            }
        }
        It 'Should call Get-VstsInput for AzureRegion' {
            Assert-MockCalled -CommandName Get-VstsInput -Scope Context -Times 1 -Exactly -ParameterFilter {
                $Name -eq 'AzureRegion' -and $Require
            }
        }
        It 'Should call Get-VstsInput for ProjectCode' {
            Assert-MockCalled -CommandName Get-VstsInput -Scope Context -Times 1 -Exactly -ParameterFilter {
                $Name -eq 'ProjectCode' -and $Require
            }
        }
        It 'Should call Get-VstsInput for ResourceUniqueId' {
            Assert-MockCalled -CommandName Get-VstsInput -Scope Context -Times 1 -Exactly -ParameterFilter {
                $Name -eq 'ResourceUniqueId' -and $Require
            }
        }
        It 'Should call Get-VstsInput for LogRetentionDays' {
            Assert-MockCalled -CommandName Get-VstsInput -Scope Context -Times 1 -Exactly -ParameterFilter {
                $Name -eq 'LogRetentionDays' -and $Require -and $AsInt
            }
        }
    }
}