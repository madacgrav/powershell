
$sut = Split-Path $MyInvocation.MyCommand.ScriptBlock.File -Leaf
$extensionId = $sut.Split('.')[0]

Describe "General project validation: $extensionId" {

    Context 'Powershell Script Validation' {

        $splatGetChildItem = @{
            Path    = "$PSScriptRoot\..\Tasks\", "$PSScriptRoot\..\BuildScripts\"
            Include = '*.ps1', '*.psm1', '*.psd1'            
            Recurse = $true
        }
        $scripts = @(Get-ChildItem @splatGetChildItem).Where( { $_.FullName -notlike '*\ps_modules\*' })

        # TestCases are splatted to the script so we need hashtables
        $testCase = $scripts | Foreach-Object { @{file = $_ } }
        It "Script <file> should be valid powershell" -TestCases $testCase {
            param($file)

            $file.FullName | Should -Exist        
            
            $contents = Get-Content -Path $file.FullName
            $errors = $null
            $null = [System.Management.Automation.PSParser]::Tokenize($contents, [ref]$errors)
            $errors.Count | Should -Be 0
        }        
    }

    Context 'ARM Template File Validation' {

        $splatGetChildItem = @{
            Path    = "$PSScriptRoot\..\Templates\"
            Include = '*.json'
            Recurse = $true
        }
        $armTemplates = Get-ChildItem @splatGetChildItem

        # TestCases are splatted to the script so we need hashtables
        $testCase = $armTemplates | Foreach-Object { @{file = $_ } }
        It "ARM Template <file> should be a valid JSON file" -TestCases $testCase {
            param($file)

            $file.FullName | Should -Exist
            $armTemplateJson = Get-Content -Path $file.FullName -Raw
            { ConvertFrom-Json -InputObject $armTemplateJson } | Should -Not -Throw
        }

        It "ARM Template <file> should contain all required elements" -TestCases $testCase {
            param($file)

            $elements = '$schema', 'contentVersion', 'outputs', 'parameters', 'resources', 'variables'
            $armTemplateJson = Get-Content -Path $file.FullName -Raw
            $template = ConvertFrom-Json -InputObject $armTemplateJson
            $templateElements = $template.psobject.Properties.Name

            foreach ($element in $elements)
            {
                $templateElements | Should -Contain $element
            }
        }
    }

    Context 'Task Json File Validation' {

        $splatGetChildItem = @{
            Path    = "$PSScriptRoot\..\Tasks\"
            Include = 'task.json'
            Recurse = $true
        }
        $taskJson = Get-ChildItem @splatGetChildItem

        # TestCases are splatted to the script so we need hashtables
        $testCase = $taskJson | Foreach-Object { @{file = $_ } }
        It "Task <file> should be a valid JSON file" -TestCases $testCase {
            param($file)

            $file.FullName | Should -Exist            
            $taskJsonRaw = Get-Content -Path $file.FullName -Raw
            { ConvertFrom-Json -InputObject $taskJsonRaw } | Should -Not -Throw
        }
    }

    Context 'VSS-Extension Json File Validation' {
        
        $extensionJson = Get-Item -Path "$PSScriptRoot\..\vss-extension.json"

        # TestCases are splatted to the script so we need hashtables
        $testCase = $extensionJson | Foreach-Object { @{file = $_ } }
        It "Extension <file> should be a valid JSON file" -TestCases $testCase {
            param($file)

            $file.FullName | Should -Exist            
            $extJsonRaw = Get-Content -Path $file.FullName -Raw
            { ConvertFrom-Json -InputObject $extJsonRaw } | Should -Not -Throw
        }
    }
}