
[CmdletBinding()]
param
()

Import-Module -Name $PSScriptRoot\ps_modules\VstsTaskSdk
Import-Module -Name $PSScriptRoot\ps_modules\ScmAzureTools

Trace-VstsEnteringInvocation $MyInvocation

try 
{
    $serviceNameInput = Get-VstsInput -Name ConnectedServiceNameSelector -Default 'ConnectedServiceName'
    $serviceName = Get-VstsInput -Name $serviceNameInput -Default (Get-VstsInput -Name DeploymentEnvironmentName)
    $endpoint = Get-VstsEndpoint -Name $serviceName -Require
    if (-not $endpoint)
    {
        throw "Endpoint not found..."
    }

    Update-PSModulePathForHostedAgent
    Initialize-AzSubscription -Endpoint $endpoint -ErrorAction Stop
    $resourceGroupName = Get-VstsInput -Name 'ResourceGroupName' -Require
    $ProjectCode = Get-VstsInput -Name 'ProjectCode' -Require   
    $sqlServerVersion = Get-VstsInput -Name 'sqlServerVersion' -Require   
    $Vnet = Get-VstsInput -Name 'Vnet' -Require   
    $subnet = Get-VstsInput -Name 'subnet' -Require
    $vnetResourceGroupName = Get-VstsInput -Name 'subnet' -Require
    $AzureRegion = Get-VstsInput -Name 'AzureRegion' -Require
    $LogRetentionDays = Get-VstsInput -Name 'LogRetentionDays' -Require -AsInt

    $workspaceId = Get-AzOmsWorkspaceId -SubscriptionName $endpoint.Data.SubscriptionName
    if (-not $workspaceId)
    {
        throw "No Workspace ID found for subscription name: '$($endpoint.Data.SubscriptionName)'"
    }

    $regionCode = Get-AzRegionCode -AzureRegion $azureRegion
    if (-not $regionCode)
    {
        throw "No region code found for Azure region: '$azureRegion'"
    }

    # Do something about sqlAdmin and sqlPassword
    # require it to be precreated??

    $sqlServerAdminUsername  = "dassql1_dev_admin"
    #check if value exists in keyvault with secret name - if so grab it
    # if not create random password and store in keyvault
    $sqlServerAdminPassword = "123456789"


    # Hard coded values for the Azure AD Group that will be admins of server
    $aadAdminLogin = "SG-US SCM PM"
    $aadAdminObjectId = "97ece1e6-eddc-4861-a6d9-80f14630cf50"
    $aadTenantId = "36da45f1-dd2c-4d1f-af13-5abe46b99921"

    #Hard coded values for deloitte networking

    $deloittePublicSubnetStartIp = "167.219.0.0"
    $deloittePublicSubnetEndIp = "167.219.255.255"

    # Build hashtable to splat for service
    $splatNewAzResourceName = @{
        AzResourceType = 'AzSqlServer'        
        ProjectCode    = $projectCode
        AzRegionCode   = $regionCode
        Environment    = $env:RELEASE_ENVIRONMENTNAME
    }
    $sqlServerName = "testcag-" + $ProjectCode

    write-host "Get Virtual Network Info"
   # $vnetInfo = Get-AzVirtualNetwork -Name $Vnet -ResourceGroupName $vnetResourceGroupName
    write-host "Get Subnet ID"
   # $subnetId = (Get-AzVirtualNetworkSubnetConfig -name $subnet -VirtualNetwork $vnetInfo).id

    $templateParameterObejct = @{
        sqlServerName               =   $sqlServerName
        sqlServerAdminUsername      =   $sqlServerAdminUsername
        sqlServerAdminPassword      =   $sqlServerAdminPassword
        sqlServerVersion            =   $sqlServerVersion
        aadAdminLogin               =   $aadAdminLogin
        aadAdminObjectId            =   $aadAdminObjectId
        aadTenantId                 =   $aadTenantId
        deloittePublicSubnetStartIp =   $deloittePublicSubnetStartIp
        deloittePublicSubnetEndIp   =   $deloittePublicSubnetEndIp
        aseVnetResourceGroupName    =   $vnetResourceGroupName
        aseVnetName                 =   $Vnet
        aseVnetSubnetName           =   $subnet
        workspaceId                 =   $workspaceId
        logsRetentionDays           =   $logRetentionDays
        azureRegion                 =   $azureRegion
    }   

    $splatNewAzRgDeployment = @{
        Name                    = "deploy-$sqlServerName"
        ResourceGroupName       = $resourceGroupName
        TemplateFile             = ".\Templates\sqlServer.json"
        TemplateParameterObject = $templateParameterObejct        
    }
    New-AzResourceGroupDeployment @splatNewAzRgDeployment

}
catch
{
    Write-Error "Exception caught from task: $($_.Exception.ToString())"
    throw
} 
finally 
{    
    Disconnect-AzSubscriptionAndClearContext
    Trace-VstsLeavingInvocation $MyInvocation
}
