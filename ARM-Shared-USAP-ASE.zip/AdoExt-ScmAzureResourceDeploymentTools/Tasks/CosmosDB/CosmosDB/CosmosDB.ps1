
[CmdletBinding()]
param
()

Import-Module -Name $PSScriptRoot\ps_modules\VstsTaskSdk
Import-Module -Name $PSScriptRoot\ps_modules\ScmAzureTools

Trace-VstsEnteringInvocation $MyInvocation

try
{
    $serviceNameInput = Get-VstsInput -Name ConnectedServiceNameSelector -Default 'ConnectedServiceName'
    $serviceName = Get-VstsInput -Name $serviceNameInput -Default (Get-VstsInput -Name DeploymentEnvironmentName)
    $endpoint = Get-VstsEndpoint -Name $serviceName -Require
    $resourceGroupName = Get-VstsInput -Name 'ResourceGroupName' -Require
    $ProjectCode = Get-VstsInput -Name 'ProjectCode' -Require
    $ResourceUniqueId = Get-VstsInput -Name 'ResourceUniqueId' -Require
    $PrimaryAzureRegion = Get-VstsInput -Name 'PrimaryAzureRegion' -Require
    $SecondaryAzureRegion = Get-VstsInput -Name 'SecondaryAzureRegion' -Require
    $apitype = Get-VstsInput -Name 'apitype' -Require
    $consistencyLevel = Get-VstsInput -Name 'consistencyLevel' -Require
    $maxStalenessPrefix = Get-VstsInput -Name 'maxStalenessPrefix' -AsInt
    $maxIntervalInSeconds = Get-VstsInput -Name 'maxIntervalInSeconds' -AsInt
    $sharedThroughput = Get-VstsInput -Name 'sharedThroughput' -Require -AsInt

    if (-not $endpoint)
    {
        throw "Endpoint not found..."
    }

    $workspaceId = Get-AzOmsWorkspaceId -SubscriptionName $endpoint.Data.SubscriptionName

    if (-not $workspaceId)
    {
        throw "No Workspace ID found for subscription name: '$($endpoint.Data.SubscriptionName)'"
    }

    $regionCode = Get-AzRegionCode -AzureRegion $PrimaryAzureRegion

    if (-not $regionCode)
    {
        throw "No region code found for Azure region: '$azureRegion'"
    }
}
catch
{
    Write-Error "Exception caught from task: $($_.Exception.ToString())"
    Trace-VstsLeavingInvocation $MyInvocation
    throw
}



try 
{
    Update-PSModulePathForHostedAgent
    Initialize-AzSubscription -Endpoint $endpoint

    $dbAccountName = "adamcosmosdbtest"
       

    if ($consistencyLevel -eq "BoundedStaleness") {
        $consistencyPolicy = @{
            defaultConsistencyLevel       = $consistencyLevel
            maxStalenessPrefix            = $maxStalenessPrefix
            maxIntervalInSeconds          = $maxIntervalInSeconds
        }
    }
    else {
        $consistencyPolicy = @{
            defaultConsistencyLevel       = $consistencyLevel
        }
    }
    switch ($apitype) {
        "MongoDB" {
            $kind = "MongoDB"
            $dbName = "adamMongoDB"

            $templateParameterObejctBaseAndAPI = @{
                dbAccountName       = $dbAccountName
                dbName              = $dbName
                throughput          = $sharedThroughput
                primaryRegion       = $PrimaryAzureRegion
                secondaryRegion     = $SecondaryAzureRegion
                consistencyPolicy   = $consistencyPolicy
                apiType             = $kind
                multipleWriteLocations = $true
                automaticFailover      = $true
            }

            $splatNewAzRgDeploymentBaseAndAPI = @{
                Name                    = "$dbAccountName-MongoDB-deploy"
                ResourceGroupName       = $resourceGroupName
                TemplateFile            = ".\Templates\CosmosDbMongo.json"
                TemplateParameterObject = $templateParameterObejctBaseAndAPI
            }

            New-AzResourceGroupDeployment @splatNewAzRgDeploymentBaseAndAPI
        }
        "SQL" {
            $kind = "GlobalDocumentDB"

            $templateParameterObejctBaseAndAPI = @{
                dbAccountName       = $dbAccountName
                dbName              = $dbName
                throughput          = $sharedThroughput
                primaryRegion       = $PrimaryAzureRegion
                secondaryRegion     = $SecondaryAzureRegion
                consistencyPolicy   = $consistencyPolicy
                apiType             = $kind
                multipleWriteLocations = $true
                automaticFailover      = $true
            }

            $splatNewAzRgDeploymentBaseAndAPI = @{
                Name                    = "$dbAccountName-SQLB-deploy"
                ResourceGroupName       = $resourceGroupName
                TemplateFile            = ".\Templates\CosmosDbSQL.json"
                TemplateParameterObject = $templateParameterObejctBaseAndAPI
            }

            New-AzResourceGroupDeployment @splatNewAzRgDeploymentBaseAndAPI
        }
        "Cassandra" {
            $capabilities = @{ name = "EnableCassandra"}
            $kind = "GlobalDocumentDB"

        }
        "Gremlin" {
            $capabilities = @{ name = "EnableGremlin" }
            $kind ="GlobalDocumentDB"
        }
        "Table" {
            $kind = @{
                kind            = "MongoDB"
                capabilities    = ""
            }
        }
    }
 
    
   # Write-Output "Creating new variable: ado.AppInsightsName $appInsightsName"
   # Write-Output "##vso[task.setvariable variable=ado.AppInsightsName;]$appInsightsName"
}
catch
{
    Write-Error "Exception caught from task: $($_.Exception.ToString())"
    throw
} 
finally 
{    
    Disconnect-AzSubscriptionAndClearContext
    Trace-VstsLeavingInvocation $MyInvocation
}
