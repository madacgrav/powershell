
[CmdletBinding()]
param
()

Import-Module -Name $PSScriptRoot\ps_modules\VstsTaskSdk
Import-Module -Name $PSScriptRoot\ps_modules\ScmAzureTools

Trace-VstsEnteringInvocation $MyInvocation

try 
{
    $serviceNameInput = Get-VstsInput -Name ConnectedServiceNameSelector -Default 'ConnectedServiceName'
    $serviceName = Get-VstsInput -Name $serviceNameInput -Default (Get-VstsInput -Name DeploymentEnvironmentName)
    $endpoint = Get-VstsEndpoint -Name $serviceName -Require
    $resourceGroupName = Get-VstsInput -Name 'ResourceGroupName' -Require   
    $projectCode = Get-VstsInput -Name 'ProjectCode' -Require
    $uniqueId = Get-VstsInput -Name 'ResourceUniqueId' -Require
    $keyVaultType = Get-VstsInput -Name 'KeyVaultType' -Require    
    $logRetentionDays = Get-VstsInput -Name 'LogRetentionDays' -Require -AsInt
    $AzureRegion = Get-VstsInput -Name 'AzureRegion' -Require
    
    if (-not $endpoint)
    {
        throw "Endpoint not found..."
    }

    $workspaceId = Get-AzOmsWorkspaceId -SubscriptionName $endpoint.Data.SubscriptionName

    if (-not $workspaceId)
    {
        throw "No Workspace ID found for subscription name: '$($endpoint.Data.SubscriptionName)'"
    }

    $regionCode = Get-AzRegionCode -AzureRegion $azureRegion

    if (-not $regionCode)
    {
        throw "No region code found for Azure region: '$azureRegion'"
    }
}
catch
{
    Write-Error "Exception caught from task: $($_.Exception.ToString())"
    Trace-VstsLeavingInvocation $MyInvocation
    throw
}

# Build hashtable to splat for KeyVault name
$splatNewAzResourceName = @{
    AzResourceType = 'AzKeyVault'
    KeyVaultType   = $keyVaultType
    ProjectCode    = $projectCode
    AzRegionCode   = $regionCode
    Environment    = $env:RELEASE_ENVIRONMENTNAME
    UniqueId       = $uniqueId
}
$keyVaultName = (New-AzResourceName @splatNewAzResourceName).Name

$scmAccessPolicy = @{
    tenantid                = "36da45f1-dd2c-4d1f-af13-5abe46b99921"
    objectid                = "97ece1e6-eddc-4861-a6d9-80f14630cf50"
    secretsPermissions      = @("Get", "List", "Set", "Delete", "Recover", "Backup", "Restore")
    keysPermissions         = @("Get", "List", "Update", "Create", "Import", "Delete", "Recover", "Backup", "Restore")
    certificatesPermissions = @("Get", "List", "Update", "Create", "Import", "Delete", "Recover", "Backup", "ManageContacts", "ManageIssuers", "GetIssuers", "ListIssuers", "SetIssuers", "DeleteIssuers")
    storagePermissions      = @("get", "list", "set", "setsas", "getsas", "listsas")
}

try
{
    Update-PSModulePathForHostedAgent
    Initialize-AzSubscription -Endpoint $endpoint

    $templateParameterObejct = @{        
        KeyVaultName      = $keyVaultName        
        workspaceId       = $workspaceId
        logsRetentionDays = $logRetentionDays
        adminAccessPolicy = $scmAccessPolicy
    }

    $splatNewAzRgDeployment = @{
        Name                    = "kv-deploy-$keyVaultName"
        ResourceGroupName       = $resourceGroupName
        TemplateFile             = ".\Templates\KeyVault.json"
        TemplateParameterObject = $templateParameterObejct        
    }
    New-AzResourceGroupDeployment @splatNewAzRgDeployment

    Write-Verbose "Creating new variable: ado.KeyVaultName $keyVaultName"
    Write-Output "##vso[task.setvariable variable=ado.KeyVaultName;]$keyVaultName"

    # Update here for custom permissions
   
    if ($env:ado_AppServiceName)
    {

        Write-Output "Getting MSI for app service to apply for keyvault access policy"
        Write-Output ("Name of AppService: " + $env:ado_AppServiceName)
        $appServiceInfo = Get-AzWebApp -ResourceGroupName $resourceGroupName -Name $env:ado_AppServiceName

        $appSvcAccesPolicy = @{
            tenantid                = "36da45f1-dd2c-4d1f-af13-5abe46b99921"
            objectid                = $appServiceInfo.Identity.PrincipalId
            secretsPermissions      = @("Get", "List")
            keysPermissions         = @("Get", "List")
            certificatesPermissions = @("Get", "List")
            storagePermissions      = @("get", "list")
        }

        Write-Output ("Updating Access Policy for the web app - " + $appServiceInfo.Identity.PrincipalId)
        $templateParameterObejct = @{        
            KeyVaultName = $keyVaultName        
            AccessPolicy = $appSvcAccesPolicy
        }
    
        $splatNewAzRgDeployment = @{
            Name                    = "kvaccessPolicy-deploy-$keyVaultName"
            ResourceGroupName       = $resourceGroupName
            TemplateFile             = ".\Templates\KeyVaultAccessPolicy.json"
            TemplateParameterObject = $templateParameterObejct        
        }
        New-AzResourceGroupDeployment @splatNewAzRgDeployment
    }
    else
    {
        Write-Output "No web app was found so new new access policy was applied."
    }
}
catch
{
    Write-Error "Exception caught from task: $($_.Exception.ToString())"
    throw
} 
finally 
{    
    Disconnect-AzSubscriptionAndClearContext    
    Trace-VstsLeavingInvocation $MyInvocation
}
