
[CmdletBinding()]
param
()

Import-Module -Name $PSScriptRoot\ps_modules\VstsTaskSdk
Import-Module -Name $PSScriptRoot\ps_modules\ScmAzureTools

Trace-VstsEnteringInvocation $MyInvocation

try
{
    $serviceNameInput = Get-VstsInput -Name ConnectedServiceNameSelector -Default 'ConnectedServiceName'
    $serviceName = Get-VstsInput -Name $serviceNameInput -Default (Get-VstsInput -Name DeploymentEnvironmentName)
    $endpoint = Get-VstsEndpoint -Name $serviceName -Require
    $resourceGroupName = Get-VstsInput -Name 'ResourceGroupName' -Require
    $azureRegion = Get-VstsInput -Name 'AzureRegion' -Require
    $workerPool = Get-VstsInput -Name 'WorkerPool' -Require
    $numberOfWorkersFromWorkerPool = Get-VstsInput -Name 'NumberOfWorkersFromWorkerPool' -Require -AsInt
    $logRetentionDays = Get-VstsInput -Name 'LogRetentionDays' -Require -AsInt
    $aseName = Get-VstsInput -Name 'AseName' -Require
    $aseRgName = Get-VstsInput -Name 'AseResourceGroupName' -Require
    $projectCode = Get-VstsInput -Name 'ProjectCode' -Require
    $uniqueId = Get-VstsInput -Name 'ResourceUniqueId' -Require
    $appInsightsName = Get-VstsInput -Name 'AppInsightsName'
    $createFncAppStorageAccount = Get-VstsInput -Name 'CreateFncAppSa' -AsBool
    $fncAppSaRgName = Get-VstsInput -Name 'FncAppSaRgName'
    $fncAppSaName = Get-VstsInput -Name 'FncAppSaName'
    $createAppServicePlan = Get-VstsInput -Name 'CreateAppServicePlan' -AsBool
    $appServicePlanRg = Get-VstsInput -Name 'AppServicePlanRgName'
    $appServicePlan = Get-VstsInput -Name 'AppServicePlanName'

    if (-not $endpoint)
    {
        throw "Endpoint not found..."
    }

    $workspaceId = Get-AzOmsWorkspaceId -SubscriptionName $endpoint.Data.SubscriptionName

    if (-not $workspaceId)
    {
        throw "No Workspace ID found for subscription name: '$($endpoint.Data.SubscriptionName)'"
    }

    $regionCode = Get-AzRegionCode -AzureRegion $azureRegion

    if (-not $regionCode)
    {
        throw "No region code found for Azure region: '$azureRegion'"
    }
}
catch
{
    Write-Error "Exception caught from task: $($_.Exception.ToString())"
    Trace-VstsLeavingInvocation $MyInvocation
    throw
}

# Build hashtable to splat for AppService name
$splatNewAzResourceName = @{
    AzResourceType = 'AzAppService'        
    ProjectCode    = $projectCode
    AzRegionCode   = $regionCode
    Environment    = $env:RELEASE_ENVIRONMENTNAME
    UniqueId       = $uniqueId
}
# Add dynamic parameter to splat called AppServiceType
# Valid values are Web, Job, Fnc
$splatNewAzResourceName.Add('AppServiceType', 'Fnc')
$fncAppName = (New-AzResourceName @splatNewAzResourceName).Name
$splatNewAzResourceName.Remove('AppServiceType')

try 
{
    Update-PSModulePathForHostedAgent
    Initialize-AzSubscription -Endpoint $endpoint

    # Default value from task input "AppInsightsName" is $(ado.AppInsightsName).
    # If environment variable for $(ado.AppInsightsName) is not set, value in input
    # is litteraly $(ado.AppInsightsName). Need to set appInsights key to null.
    $appInsightsKey = ''
    if ($appInsightsName -ne '$(ado.AppInsightsName)' -and -not [string]::IsNullOrEmpty($appInsightsName))
    {
        $splatGetAzAppInsights = @{
            ResourceGroupName = $resourceGroupName
            Name              = $appInsightsName
        }
        $appInsightsKey = (Get-AzApplicationInsights @splatGetAzAppInsights).InstrumentationKey

        if (-not $appInsightsKey)
        {
            throw "Could not find Instrumentation Key for AppInsights '$appInsightsName'."
        }
    }

    if ($createFncAppStorageAccount)
    {        
        # Change resource type in splat to AzStorageAccount
        $splatNewAzResourceName['AzResourceType'] = 'AzStorageAccount'
        $splatNewAzResourceName.Remove('AppServiceType')
        $fncAppSaName = (New-AzResourceName @splatNewAzResourceName).Name
        $fncAppSaRgName = $resourceGroupName

        $templateParameterObejct = @{
            StorageAccountName = $fncAppSaName
            storageKind        = 'StorageV2'
            storageAccountType = 'Standard_LRS'
            workspaceId        = $workspaceId
            logsRetentionDays  = $logRetentionDays
        }

        $splatNewAzRgDeployment = @{
            Name                    = "$fncAppSaName-deploy"
            ResourceGroupName       = $fncAppSaRgName
            TemplateFile            = ".\Templates\StorageAccount.json"
            TemplateParameterObject = $templateParameterObejct        
        }
        New-AzResourceGroupDeployment @splatNewAzRgDeployment

        Write-Verbose "Creating new variable: ado.StorageAccountName $fncAppSaName"
        Write-Output "##vso[task.setvariable variable=ado.StorageAccountName;]$fncAppSaName"
    }

    if ($createAppServicePlan)
    {
        # Change resource type in splat to AzAppServicePlan
        $splatNewAzResourceName['AzResourceType'] = 'AzAppServicePlan'        
        $appServicePlan = (New-AzResourceName @splatNewAzResourceName).Name
        $appServicePlanRg = $resourceGroupName

        $templateParameterObejct = @{
            azureRegion                   = $azureRegion
            workerPool                    = $workerPool
            numberOfWorkersFromWorkerPool = $numberOfWorkersFromWorkerPool
            workspaceId                   = $workspaceId
            logsRetentionDays             = $logRetentionDays
            aseName                       = $aseName.ToLower()
            aseRgName                     = $aseRgName.ToUpper()
            appServicePlan                = $appServicePlan
        }
    
        $splatNewAzRgDeployment = @{
            Name                    = "$appServicePlan-deploy"
            ResourceGroupName       = $appServicePlanRg
            TemplateFile            = ".\Templates\AppServicePlan.json"
            TemplateParameterObject = $templateParameterObejct
        }
        New-AzResourceGroupDeployment @splatNewAzRgDeployment        
        
        Write-Verbose "Creating new variable: ado.AppServicePlan $appServicePlan"
        Write-Output "##vso[task.setvariable variable=ado.AppServicePlan;]$appServicePlan"
    }
    
    # Grab Storage account key
    $splatGetAzSaKey = @{
        ResourceGroupName = $fncAppSaRgName
        Name              = $fncAppSaName
    }
    $storageAccountKey = (Get-AzStorageAccountKey @splatGetAzSaKey).Where( { $_.KeyName -eq 'key2' }).value

    if (-not $storageAccountKey)
    {
        throw "Could not find key2 for Storage account '$fncAppSaName'."
    }

    # Grab AppServicePlan ResourceId
    $splatGetAzResource = @{
        ResourceGroupName = $appServicePlanRg
        ResourceName      = $appServicePlan
    }
    $aspResourceId = (Get-AzResource @splatGetAzResource).ResourceId

    if (-not $aspResourceId)
    {
        throw "Could not find Resource Id for App Service Plan '$appServicePlan' in Resource Group '$appServicePlanRg'."
    }

    $templateParameterObejct = @{
        azureRegion          = $azureRegion
        workspaceId          = $workspaceId
        logsRetentionDays    = $logRetentionDays
        aseName              = $aseName.ToLower()
        aseRgName            = $aseRgName.ToUpper()
        fncAppName           = $fncAppName
        aiInstrumentationKey = $appInsightsKey
        aspResourceId        = $aspResourceId
        storageAccountKey    = $storageAccountKey
    }    

    $splatNewAzRgDeployment = @{
        Name                    = "$fncAppName-deploy"
        ResourceGroupName       = $resourceGroupName
        TemplateFile            = '.\Templates\FunctionApp.json'
        TemplateParameterObject = $templateParameterObejct
    }
    New-AzResourceGroupDeployment @splatNewAzRgDeployment

    Write-Verbose "Creating new variable: ado.FunctionApp $fncAppName"
    Write-Output "##vso[task.setvariable variable=ado.FunctionApp;]$fncAppName"

    Write-Verbose "Creating new variable: ado.AzureRegion $azureRegion"
    Write-Output "##vso[task.setvariable variable=ado.AzureRegion;]$azureRegion"
}
catch
{
    Write-Error "Exception caught from task: $($_.Exception.ToString())"
    throw
} 
finally 
{    
    Disconnect-AzSubscriptionAndClearContext
    Trace-VstsLeavingInvocation $MyInvocation
}
