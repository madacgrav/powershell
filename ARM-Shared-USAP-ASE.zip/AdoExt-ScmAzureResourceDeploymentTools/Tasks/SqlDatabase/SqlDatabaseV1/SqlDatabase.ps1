
[CmdletBinding()]
param
()

Import-Module -Name $PSScriptRoot\ps_modules\VstsTaskSdk
Import-Module -Name $PSScriptRoot\ps_modules\ScmAzureTools

Trace-VstsEnteringInvocation $MyInvocation

try 
{
    $serviceNameInput = Get-VstsInput -Name ConnectedServiceNameSelector -Default 'ConnectedServiceName'
    $serviceName = Get-VstsInput -Name $serviceNameInput -Default (Get-VstsInput -Name DeploymentEnvironmentName)
    $endpoint = Get-VstsEndpoint -Name $serviceName -Require

    if (-not $endpoint)
    {
        throw "Endpoint not found..."
    }        
    
    Update-PSModulePathForHostedAgent
    Initialize-AzSubscription -Endpoint $endpoint -ErrorAction Stop


    $resourceGroupName = Get-VstsInput -Name 'ResourceGroupName' -Require   
    $sqlServerName = Get-VstsInput -Name 'SqlServerName' -Require 
    $SecondarySQLname = Get-VstsInput -Name 'SecondarySQLname'
    $SecondarySQLrg = Get-VstsInput -Name 'SecondarySQLrg' 
    $databaseNames = Get-VstsInput -Name 'DatabaseNames' -Require 
    $FailOverOutput = Get-VstsInput -Name 'FailOverOutput' -Require -AsBool
    $elasticPoolEdition = Get-VstsInput -Name 'ElasticPoolEdition' -Require
    $ElasticPoolDtuStandard = Get-VstsInput -Name 'ElasticPoolDtuStandard'
    $ElasticPoolDtuPremium = Get-VstsInput -Name 'ElasticPoolDtuPremium'

    # DTU Min Options for Standard Tier 
    $ElasticPoolDatabaseDtuMinS50 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinS50' -AsInt
    $ElasticPoolDatabaseDtuMinS100 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinS100' -AsInt
    $ElasticPoolDatabaseDtuMinS200 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinS200' -AsInt
    $ElasticPoolDatabaseDtuMinS300 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinS300' -AsInt
    $ElasticPoolDatabaseDtuMinS400 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinS400' -AsInt
    $ElasticPoolDatabaseDtuMinS800 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinS800' -AsInt
    $ElasticPoolDatabaseDtuMinS1200 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinS1200' -AsInt
    $ElasticPoolDatabaseDtuMinS1600 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinS1600' -AsInt
    $ElasticPoolDatabaseDtuMinS2000 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinS2000' -AsInt
    $ElasticPoolDatabaseDtuMinS2500 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinS2500' -AsInt
    $ElasticPoolDatabaseDtuMinS3000 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinS3000' -AsInt

    # DTU Max  Options for Standard Tier 
    $ElasticPoolDatabaseDtuMaxS50 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxS50' -AsInt
    $ElasticPoolDatabaseDtuMaxS100 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxS100' -AsInt
    $ElasticPoolDatabaseDtuMaxS200 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxS200' -AsInt
    $ElasticPoolDatabaseDtuMaxS300 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxS300' -AsInt
    $ElasticPoolDatabaseDtuMaxS400 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxS400' -AsInt
    $ElasticPoolDatabaseDtuMaxS800 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxS800' -AsInt
    $ElasticPoolDatabaseDtuMaxS1200 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxS1200' -AsInt
    $ElasticPoolDatabaseDtuMaxS1600 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxS1600' -AsInt
    $ElasticPoolDatabaseDtuMaxS2000 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxS2000' -AsInt
    $ElasticPoolDatabaseDtuMaxS2500 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxS2500' -AsInt
    $ElasticPoolDatabaseDtuMaxS3000 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxS3000' -AsInt

    # DTU Min  Options for Premium Tier 
    $ElasticPoolDatabaseDtuMinP125 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinP125' -AsInt
    $ElasticPoolDatabaseDtuMinP250 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinP250' -AsInt
    $ElasticPoolDatabaseDtuMinP500 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinP500' -AsInt
    $ElasticPoolDatabaseDtuMinP1000 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinP1000' -AsInt
    $ElasticPoolDatabaseDtuMinP1500 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinP1500' -AsInt
    $ElasticPoolDatabaseDtuMinP2000 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinP2000' -AsInt
    $ElasticPoolDatabaseDtuMinP2500 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinP2500' -AsInt
    $ElasticPoolDatabaseDtuMinP3000 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinP3000' -AsInt
    $ElasticPoolDatabaseDtuMinP3500 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinP3500' -AsInt
    $ElasticPoolDatabaseDtuMinP4000 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMinP4000' -AsInt

    # DTU Max  Options for Premium Tier 
    $ElasticPoolDatabaseDtuMaxP125 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxP125' -AsInt
    $ElasticPoolDatabaseDtuMaxP250 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxP250' -AsInt
    $ElasticPoolDatabaseDtuMaxP500 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxP500' -AsInt
    $ElasticPoolDatabaseDtuMaxP1000 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxP1000' -AsInt
    $ElasticPoolDatabaseDtuMaxP1500 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxP1500' -AsInt
    $ElasticPoolDatabaseDtuMaxP2000 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxP2000' -AsInt
    $ElasticPoolDatabaseDtuMaxP2500 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxP2500' -AsInt
    $ElasticPoolDatabaseDtuMaxP3000 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxP3000' -AsInt
    $ElasticPoolDatabaseDtuMaxP3500 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxP3500' -AsInt
    $ElasticPoolDatabaseDtuMaxP4000 = Get-VstsInput -Name 'ElasticPoolDatabaseDtuMaxP4000' -AsInt

    # Storage Options for Standard Tier DTU
    $ElasticPoolDatabaseStorageS50 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageS50' -AsInt
    $ElasticPoolDatabaseStorageS100 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageS100' -AsInt
    $ElasticPoolDatabaseStorageS200 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageS200' -AsInt
    $ElasticPoolDatabaseStorageS300 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageS300' -AsInt
    $ElasticPoolDatabaseStorageS400 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageS400' -AsInt
    $ElasticPoolDatabaseStorageS800 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageS800' -AsInt
    $ElasticPoolDatabaseStorageS1200 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageS1200' -AsInt
    $ElasticPoolDatabaseStorageS1600 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageS1600' -AsInt
    $ElasticPoolDatabaseStorageS2000 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageS2000' -AsInt
    $ElasticPoolDatabaseStorageS2500 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageS2500' -AsInt
    $ElasticPoolDatabaseStorageS3000 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageS3000' -AsInt

    # Storage Options for Premium Tier DTU
    $ElasticPoolDatabaseStorageP125 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageP125' -AsInt
    $ElasticPoolDatabaseStorageP250 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageP250' -AsInt
    $ElasticPoolDatabaseStorageP500 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageP500' -AsInt
    $ElasticPoolDatabaseStorageP1000 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageP1000' -AsInt
    $ElasticPoolDatabaseStorageP1500 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageP1500' -AsInt
    $ElasticPoolDatabaseStorageP2000 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageP2000' -AsInt
    $ElasticPoolDatabaseStorageP2500 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageP2500' -AsInt
    $ElasticPoolDatabaseStorageP3000 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageP3000' -AsInt
    $ElasticPoolDatabaseStorageP3500 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageP3500' -AsInt
    $ElasticPoolDatabaseStorageP4000 = Get-VstsInput -Name 'ElasticPoolDatabaseStorageP4000' -AsInt


    $logRetentionDays = Get-VstsInput -Name 'LogRetentionDays' -Require -AsInt
    $AzureRegion = Get-VstsInput -Name 'AzureRegion' -Require
    $projectCode = Get-VstsInput -Name 'projectCode' -Require

    if (-not $endpoint)
    {
        throw "Endpoint not found..."
    }

    if (($env:RELEASE_ENVIRONMENTNAME).toLower() -eq "bcp") {
        throw "This task is not supported for BCP. DB config and failover is configured in PRD stage."
    }

    $sqlDatabaseCollation = "SQL_Latin1_General_CP1_CI_AS"
    $workspaceId = Get-AzOmsWorkspaceId -SubscriptionName $endpoint.Data.SubscriptionName

    if (-not $workspaceId)
    {
        throw "No Workspace ID found for subscription name: '$($endpoint.Data.SubscriptionName)'"
    }

    $regionCode = Get-AzRegionCode -AzureRegion $azureRegion

    if (-not $regionCode)
    {
        throw "No region code found for Azure region: '$azureRegion'"
    }

    #$elasticPoolInstance = [int]$env:ADO_ELASTICPOOLINSTANCE + 1

    # Build hashtable to splat for ElasticPool name
    $splatNewAzResourceName = @{
        AzResourceType = 'AzElasticPool'        
        ProjectCode    = $projectCode
        AzRegionCode   = $regionCode
        Environment    = $env:RELEASE_ENVIRONMENTNAME
        Iteration      = 0
    }
    $elasticPoolName = (New-AzResourceName @splatNewAzResourceName).Name

    switch ($elasticPoolEdition) {
        "Standard" {
            $elasticPoolDtu = $ElasticPoolDtuStandard
            switch ($ElasticPoolDtuStandard) {
                "50" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageS50 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinS50
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxS50
                } 
                "100" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageS100 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinS100
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxS100
                }
                "200" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageS200 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinS200
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxS200
                }
                "300" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageS300 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinS300
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxS300
                }
                "400" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageS400 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinS400
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxS400
                }
                "800" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageS800 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinS800
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxS800
                }
                "1200" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageS1200 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinS1200
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxS1200
                }
                "1600" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageS1600 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinS1600
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxS1600
                }
                "2000" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageS2000 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinS2000
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxS2000
                }
                "2500" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageS2500 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinS2500
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxS2500
                }
                "3000" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageS3000 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinS3000
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxS3000
                }
            }
        }
        "Premium" {
            $elasticPoolDtu = $ElasticPoolDtuPremium
            switch ($ElasticPoolDtuPremium) {
                "125" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageP125 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinP125
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxP125
                }
                "250" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageP250 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinP250
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxP250
                }
                "500" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageP500 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinP500
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxP500
                }
                "1000" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageP1000 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinP1000
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxP1000
                }
                "1500" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageP1500 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinP1500
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxP1500
                }
                "2000" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageP2000 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinP2000
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxP2000
                }
                "2500" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageP2500 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinP2500
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxP2500
                }
                "3000" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageP3000 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinP3000
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxP3000
                }
                "3500" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageP3500 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinP3500
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxP3500
                }
                "4000" {
                    $elasticPoolDatabaseStorage = $ElasticPoolDatabaseStorageP4000 * 1024
                    $elasticPoolDatabaseDtuMin = $ElasticPoolDatabaseDtuMinP4000
                    $elasticPoolDatabaseDtuMax = $ElasticPoolDatabaseDtuMaxP4000
                }

            }
        }
    }

    # Run EP ARM template
    $elasticPoolobj = @{
        edition   = $elasticPoolEdition
        DTU       = $elasticPoolDtu
        dbDTUMin  = $elasticPoolDatabaseDtuMin
        dbDTUMax  = $elasticPoolDatabaseDtuMax
        storageMB = $elasticPoolDatabaseStorage
    }

    $eptemplateParameterObejct = @{
        elasticPoolName     =   $elasticPoolName
        sqlServerName       =   $sqlServerName
        elasticPoolSettings =   $elasticPoolobj
        workspaceId         =   $workspaceId
        logsRetentionDays   =   $logRetentionDays
    }   

    $epsplatNewAzRgDeployment = @{
        Name                    = "ep1-deploy-$elasticPoolName"
        ResourceGroupName       = $resourceGroupName
        TemplateFile             = ".\Templates\elasticpool.json"
        TemplateParameterObject = $eptemplateParameterObejct        
    }
    New-AzResourceGroupDeployment @epsplatNewAzRgDeployment

    $splitdbnames = $databaseNames.split([Environment]::NewLine)

    foreach ($db in $splitdbnames) {
        write-host ("creating  db: " + $db)
        # Run DB ARM template 
        $dbtemplateParameterObejct = @{
            sqlServerName       =   $sqlServerName
            dbName              =   $db
            elasticPoolName     =   $elasticPoolName
            sqlDatabaseCollation =  $sqlDatabaseCollation
            workspaceId         =   $workspaceId
            logsRetentionDays   =   $logRetentionDays
        }    

        $dbsplatNewAzRgDeployment = @{
            Name                    = "$db-deploy-$sqlServerName"
            ResourceGroupName       = $resourceGroupName
            TemplateFile             = ".\Templates\sqldb.json"
            TemplateParameterObject = $dbtemplateParameterObejct        
        }
        New-AzResourceGroupDeployment @dbsplatNewAzRgDeployment
    }   
    # if failover group output is set to true -- run failover group ARM template
    if ($FailOverOutput) {

        if (($env:RELEASE_ENVIRONMENTNAME).toLower() -ne "prd") {
            throw "Failover group is only set for prd environment"
        }
        else {
        # Create secondary elastic pool for PRD/BCP environment
            write-host $SecondarySQLname
            $eptemplateParameterObejct = @{
                elasticPoolName     =   $elasticPoolName
                sqlServerName       =   $SecondarySQLname
                elasticPoolSettings =   $elasticPoolobj
                workspaceId         =   $workspaceId
                logsRetentionDays   =   $logRetentionDays
            }   
        
            $epsplatNewAzRgDeployment = @{
                Name                    = "ep2-deploy-$elasticPoolName"
                ResourceGroupName       = $SecondarySQLrg
                TemplateFile             = ".\Templates\elasticpool.json"
                TemplateParameterObject = $eptemplateParameterObejct        
            }
            New-AzResourceGroupDeployment @epsplatNewAzRgDeployment
        }
        
        # Build hashtable to splat for KeyVault name
        $splatNewAzResourceName = @{
            AzResourceType = 'AzFailoverGroup'        
            ProjectCode    = $projectCode
            AzRegionCode   = $regionCode
            Environment    = $env:RELEASE_ENVIRONMENTNAME
            Iteration      = 0
        }
        $failoverGroupName = (New-AzResourceName @splatNewAzResourceName).Name

        #when we allow multiple database entries
        $dbResourceIds = @()
        foreach ($db in $splitdbnames) {
            $dbResourceIds += (Get-AzResource -Name $db -ResourceType "Microsoft.Sql/servers/databases" -ResourceGroupName $resourceGroupName).ID
        }

        $fgtemplateParameterObejct = @{
            failoverGroupName       =   $failoverGroupName
            PrimarysqlServer        =   $sqlServerName
            SecondarysqlServer      =   $SecondarySQLname
            databaseNameResourceIds =   $dbResourceIds
        }    

        $fgsplatNewAzRgDeployment = @{
            Name                    = "fg-deploy-$sqlServerName"
            ResourceGroupName       = $SecondarySQLrg
            TemplateFile             = ".\Templates\failovergroup.json"
            TemplateParameterObject = $fgtemplateParameterObejct        
        }
        New-AzResourceGroupDeployment @fgsplatNewAzRgDeployment

    }

}
catch
{
    Write-Error "Exception caught from task: $($_.Exception.ToString())"
    throw
} 
finally 
{    
    Disconnect-AzSubscriptionAndClearContext
    Trace-VstsLeavingInvocation $MyInvocation
}
