
[CmdletBinding()]
param
()

Import-Module -Name $PSScriptRoot\ps_modules\VstsTaskSdk
Import-Module -Name $PSScriptRoot\ps_modules\ScmAzureTools

Trace-VstsEnteringInvocation $MyInvocation

try
{
    $serviceNameInput = Get-VstsInput -Name ConnectedServiceNameSelector -Default 'ConnectedServiceName'
    $serviceName = Get-VstsInput -Name $serviceNameInput -Default (Get-VstsInput -Name DeploymentEnvironmentName)
    $endpoint = Get-VstsEndpoint -Name $serviceName -Require
    $resourceGroupName = Get-VstsInput -Name 'ResourceGroupName' -Require
    $azureRegion = Get-VstsInput -Name 'AzureRegion' -Require
    $projectCode = Get-VstsInput -Name 'ProjectCode' -Require
    $uniqueId = Get-VstsInput -Name 'ResourceUniqueId' -Require
    $logRetentionDays = Get-VstsInput -Name 'LogRetentionDays' -Require -AsInt

    if (-not $endpoint)
    {
        throw "Endpoint not found..."
    }

    $workspaceId = Get-AzOmsWorkspaceId -SubscriptionName $endpoint.Data.SubscriptionName

    if (-not $workspaceId)
    {
        throw "No Workspace ID found for subscription name: '$($endpoint.Data.SubscriptionName)'"
    }

    $regionCode = Get-AzRegionCode -AzureRegion $azureRegion

    if (-not $regionCode)
    {
        throw "No region code found for Azure region: '$azureRegion'"
    }
}
catch
{
    Write-Error "Exception caught from task: $($_.Exception.ToString())"
    Trace-VstsLeavingInvocation $MyInvocation
    throw
}

# Build hashtable to splat for AppInsights name
$splatNewAzResourceName = @{
    AzResourceType = 'AzAppInsights'
    ProjectCode    = $projectCode
    AzRegionCode   = $regionCode
    Environment    = $env:RELEASE_ENVIRONMENTNAME
    UniqueId       = $uniqueId
}
$appInsightsName = (New-AzResourceName @splatNewAzResourceName).Name

try 
{
    Update-PSModulePathForHostedAgent
    Initialize-AzSubscription -Endpoint $endpoint

    $templateParameterObejct = @{
        aiName            = $appInsightsName
        workspaceId       = $workspaceId
        logsRetentionDays = $logRetentionDays
    }

    $armTemplateName = [IO.Path]::GetFileNameWithoutExtension($MyInvocation.MyCommand.Name)

    $splatNewAzRgDeployment = @{
        Name                    = "$appInsightsName-deploy"
        ResourceGroupName       = $resourceGroupName
        TemplateFile            = ".\Templates\$armTemplateName.json"
        TemplateParameterObject = $templateParameterObejct
    }
    New-AzResourceGroupDeployment @splatNewAzRgDeployment
    
    Write-Verbose "Creating new variable: ado.AppInsightsName $appInsightsName"
    Write-Output "##vso[task.setvariable variable=ado.AppInsightsName;]$appInsightsName"
}
catch
{
    Write-Error "Exception caught from task: $($_.Exception.ToString())"
    throw
} 
finally 
{    
    Disconnect-AzSubscriptionAndClearContext
    Trace-VstsLeavingInvocation $MyInvocation
}
