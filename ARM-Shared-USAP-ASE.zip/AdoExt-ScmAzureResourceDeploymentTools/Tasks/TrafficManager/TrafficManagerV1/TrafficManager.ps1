
[CmdletBinding()]
param
()

Import-Module -Name $PSScriptRoot\ps_modules\VstsTaskSdk
Import-Module -Name $PSScriptRoot\ps_modules\ScmAzureTools

Trace-VstsEnteringInvocation $MyInvocation

try 
{
    $serviceNameInput = Get-VstsInput -Name ConnectedServiceNameSelector -Default 'ConnectedServiceName'
    $serviceName = Get-VstsInput -Name $serviceNameInput -Default (Get-VstsInput -Name DeploymentEnvironmentName)
    $endpoint = Get-VstsEndpoint -Name $serviceName -Require
    $resourceGroupName = Get-VstsInput -Name 'ResourceGroupName' -Require   
    $projectCode = Get-VstsInput -Name 'projectCode' -Require
    $uniqueId = Get-VstsInput -Name 'ResourceUniqueId' -Require
    $endpointLocation = Get-VstsInput -Name 'EndpointLocation' -Require
    $endpointTargets = Get-VstsInput -Name 'EndpointTargets' -Require

    if (-not $endpoint)
    {
        throw "Endpoint not found..."
    }
}
catch
{
    Write-Error "Exception caught from task: $($_.Exception.ToString())"
    Trace-VstsLeavingInvocation $MyInvocation
    throw
}

try
{
    Update-PSModulePathForHostedAgent
    Initialize-AzSubscription -Endpoint $endpoint

    # Build hashtable to splat for AzTrafficManager name
    $splatNewAzResourceName = @{
        AzResourceType = 'AzTrafficManager'        
        ProjectCode    = $projectCode
        AzRegionCode   = "eus"  #value not really needed so passing default value
        Environment    = $env:RELEASE_ENVIRONMENTNAME
        UniqueId       = $uniqueId
    }
    $trafficManagerName = (New-AzResourceName @splatNewAzResourceName).Name

    # Deploy Traffic Manager
    $templateParameterObejct = @{
        trafficManagerDnsName = $trafficManagerName.ToLower()
    }

    $splatNewAzRgDeployment = @{
        Name                    = "deploy-$trafficManagerName"
        ResourceGroupName       = $resourceGroupName
        TemplateFile            = ".\Templates\TrafficManager.json"
        TemplateParameterObject = $templateParameterObejct        
    }
    New-AzResourceGroupDeployment @splatNewAzRgDeployment

    Write-Verbose "Creating new variable: ado.TrafficManagerName $trafficManagerName"
    Write-Output "##vso[task.setvariable variable=ado.TrafficManagerName;]$trafficManagerName"

    $splitEndPoints = $endpointTargets.split([Environment]::NewLine)
    
    $count = 1
    foreach ($endPoint in $splitEndPoints)
    {
        # Deploy Traffic Manager EndPoint
        $templateParameterObejct = @{
            priority              = $count
            trafficManagerDnsName = $trafficManagerName.ToLower()
            EndpointLocation      = $endpointLocation
            EndpointTarget        = $endPoint
        }    

        $splatNewAzRgDeployment = @{
            Name                    = "deployEndPoint($count)-$trafficManagerName"
            ResourceGroupName       = $resourceGroupName
            TemplateFile            = ".\Templates\TrafficManagerEndPoint.json"
            TemplateParameterObject = $templateParameterObejct        
        }
        New-AzResourceGroupDeployment @splatNewAzRgDeployment
        $count++
    }
}
catch
{
    Write-Error "Exception caught from task: $($_.Exception.ToString())"
    throw
} 
finally 
{    
    Disconnect-AzSubscriptionAndClearContext
    Trace-VstsLeavingInvocation $MyInvocation
}
