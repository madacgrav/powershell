
[CmdletBinding()]
param
()

Import-Module -Name $PSScriptRoot\ps_modules\VstsTaskSdk
Import-Module -Name $PSScriptRoot\ps_modules\ScmAzureTools

Trace-VstsEnteringInvocation $MyInvocation

try 
{
    $serviceNameInput = Get-VstsInput -Name ConnectedServiceNameSelector -Default 'ConnectedServiceName'
    $serviceName = Get-VstsInput -Name $serviceNameInput -Default (Get-VstsInput -Name DeploymentEnvironmentName)
    $endpoint = Get-VstsEndpoint -Name $serviceName -Require
    $resourceGroupName = Get-VstsInput -Name 'ResourceGroupName' -Require   
    $projectCode = Get-VstsInput -Name 'projectCode' -Require
    $uniqueId = Get-VstsInput -Name 'ResourceUniqueId' -Require
    $storageAccountType = Get-VstsInput -Name 'storageAccountType' -Require
    $storageAccountReplication = Get-VstsInput -Name 'storageAccountReplication' -Require    
    $logRetentionDays = Get-VstsInput -Name 'LogRetentionDays' -Require -AsInt
    $azureRegion = Get-VstsInput -Name 'azureRegion' -Require

    if (-not $endpoint)
    {
        throw "Endpoint not found..."
    }

    $workspaceId = Get-AzOmsWorkspaceId -SubscriptionName $endpoint.Data.SubscriptionName

    if (-not $workspaceId)
    {
        throw "No Workspace ID found for subscription name: '$($endpoint.Data.SubscriptionName)'"
    }

    $regionCode = Get-AzRegionCode -AzureRegion $azureRegion

    if (-not $regionCode)
    {
        throw "No region code found for Azure region: '$azureRegion'"
    }

    # Check to see if the storage sku and type are compatible for deployment. 
    $storageCompatibility = $false

    switch ($storageAccountType)
    {
        "Storage"
        {
            $validtypes = @("Standard_LRS", "Standard_GRS", "Premium_LRS", "Standard_RAGRS")
            if ($validtypes -contains $storageAccountReplication)
            {
                $storageCompatibility = $true
            }
        }
        "StorageV2"
        {
            # Storage V2 work sith all storage types
            $storageCompatibility = $true
        }
        "BlobStorage"
        {
            $validtypes = @("Standard_LRS", "Standard_GRS", "Standard_RAGRS")
            if ($validtypes -contains $storageAccountReplication)
            {
                $storageCompatibility = $true
            }
        }
        "FileStorage"
        {
            $validtypes = @("Premium_LRS")
            if ($validtypes -contains $storageAccountReplication)
            {
                $storageCompatibility = $true
            }
        }
        "BlockBlobStorage"
        {
            $validtypes = @("Premium_LRS")
            if ($validtypes -contains $storageAccountReplication)
            {
                $storageCompatibility = $true
            }
        }
    }

    if (-not $storageCompatibility)
    {
        throw "Azure is not compatible with $storageAccountType and $storageAccountReplication combination."
        throw "Please review available storage compatiblity at https://docs.microsoft.com/en-us/azure/storage/common/storage-account-overview"
    }
}
catch
{
    Write-Error "Exception caught from task: $($_.Exception.ToString())"
    Trace-VstsLeavingInvocation $MyInvocation
    throw
}
    
# Build hashtable to splat for StorageAccount name
$splatNewAzResourceName = @{
    AzResourceType = 'AzStorageAccount'        
    ProjectCode    = $projectCode
    AzRegionCode   = $regionCode
    Environment    = $env:RELEASE_ENVIRONMENTNAME
    UniqueId       = $uniqueId
}
$storageAccountName = (New-AzResourceName @splatNewAzResourceName).Name

try
{
    Update-PSModulePathForHostedAgent
    Initialize-AzSubscription -Endpoint $endpoint 

    $templateParameterObejct = @{
        StorageAccountName = $storageAccountName.ToLower()
        storageKind        = $storageAccountType
        storageAccountType = $storageAccountReplication
        workspaceId        = $workspaceId
        logsRetentionDays  = $logRetentionDays
    }    

    $splatNewAzRgDeployment = @{
        Name                    = "deploy-$storageAccountName"
        ResourceGroupName       = $resourceGroupName
        TemplateFile             = ".\Templates\StorageAccount.json"
        TemplateParameterObject = $templateParameterObejct        
    }
    New-AzResourceGroupDeployment @splatNewAzRgDeployment

    Write-Verbose "Creating new variable: ado.StorageAccountName $storageAccountName"
    Write-Output "##vso[task.setvariable variable=ado.StorageAccountName;]$storageAccountName"
}
catch
{
    Write-Error "Exception caught from task: $($_.Exception.ToString())"
    throw
} 
finally 
{    
    Disconnect-AzSubscriptionAndClearContext
    Trace-VstsLeavingInvocation $MyInvocation
}
