
[CmdletBinding()]
param
()

Import-Module -Name $PSScriptRoot\ps_modules\VstsTaskSdk
Import-Module -Name $PSScriptRoot\ps_modules\ScmAzureTools

Trace-VstsEnteringInvocation $MyInvocation

try 
{
    $serviceNameInput = Get-VstsInput -Name ConnectedServiceNameSelector -Default 'ConnectedServiceName'
    $serviceName = Get-VstsInput -Name $serviceNameInput -Default (Get-VstsInput -Name DeploymentEnvironmentName)
    $endpoint = Get-VstsEndpoint -Name $serviceName -Require
    $resourceGroupName = Get-VstsInput -Name 'ResourceGroupName' -Require   
    $keyVaultName = Get-VstsInput -Name 'keyVaultName' -Require
    $objectid = Get-VstsInput -Name 'objectid' -Require
    $keyAccess = Get-VstsInput -Name 'KeyAccess' -Require
    $secretAccess = Get-VstsInput -Name 'SecretAccess' -Require
    $certAccess = Get-VstsInput -Name 'CertAccess' -Require
    $storageAccess = Get-VstsInput -Name 'storageAccess' -Require
    
    if (-not $endpoint)
    {
        throw "Endpoint not found..."
    }

    Update-PSModulePathForHostedAgent
    Initialize-AzSubscription -Endpoint $endpoint -ErrorAction Stop

    switch ($keyAccess.toLower())
    {
        "none"
        {
            $keysPermissions = @()
        }
        "read"
        {
            $keysPermissions = @("Get", "List")
        }
        "modify"
        {
            $keysPermissions = @("Get", "List", "Update", "Create", "Import", "Delete")
        }
        "admin"
        {
            $keysPermissions = @("Get", "List", "Update", "Create", "Import", "Delete", "Recover", "Backup", "Restore")
        }
    }

    switch ($secretAccess.toLower())
    {
        "none"
        {
            $secretsPermissions = @()
        }
        "read"
        {
            $secretsPermissions = @("Get", "List")
        }
        "modify"
        {
            $secretsPermissions = @("Get", "List", "Set", "Delete")
        }
        "admin"
        {
            $secretsPermissions = @("Get", "List", "Set", "Delete", "Recover", "Backup", "Restore")
        }
    }

    switch ($certAccess.toLower())
    {
        "none"
        {
            $certificatesPermissions = @()
        }
        "read"
        {
            $certificatesPermissions = @("Get", "List", "GetIssuers", "ListIssuers")
        }
        "modify"
        {
            $certificatesPermissions = @("Get", "List", "Update", "Create", "Import", "Delete", "ManageContacts", "ManageIssuers", "GetIssuers", "ListIssuers", "SetIssuers", "DeleteIssuers")
        }
        "admin"
        {
            $certificatesPermissions = @("Get", "List", "Update", "Create", "Import", "Delete", "Recover", "Backup", "ManageContacts", "ManageIssuers", "GetIssuers", "ListIssuers", "SetIssuers", "DeleteIssuers")
        }
    }

    switch ($storageAccess.toLower())
    {
        "none"
        {
            $storagePermissions = @()
        }
        "read"
        {
            $storagePermissions = @("Get", "List", "listsas", "getsas")
        }
        "modify"
        {
            $storagePermissions = @("get", "list", "delete", "set", "update", "regeneratekey", "setsas", "listsas", "getsas", "deletesas")
        }
        "admin"
        {
            $storagePermissions = @("get", "list", "delete", "set", "update", "regeneratekey", "recover", "purge", "backup", "restore", "setsas", "listsas", "getsas", "deletesas")
        }
    }
    

    $AccessPolicy = @{
        tenantid                = "36da45f1-dd2c-4d1f-af13-5abe46b99921"
        objectid                = $objectid
        secretsPermissions      = $secretsPermissions
        keysPermissions         = $keysPermissions
        certificatesPermissions = $certificatesPermissions
        storagePermissions      = $storagePermissions
    }


    $templateParameterObejct = @{        
        KeyVaultName = $keyVaultName        
        AccessPolicy = $AccessPolicy
    }

    $splatNewAzRgDeployment = @{
        Name                    = "kvaccessPolicy-deploy-$keyVaultName"
        ResourceGroupName       = $resourceGroupName
        TemplateFile            = ".\Templates\KeyVaultAccessPolicy.json"
        TemplateParameterObject = $templateParameterObejct        
    }
    New-AzResourceGroupDeployment @splatNewAzRgDeployment
}
catch
{
    Write-Error "Exception caught from task: $($_.Exception.ToString())"
    throw
} 
finally 
{    
    Disconnect-AzSubscriptionAndClearContext    
    Trace-VstsLeavingInvocation $MyInvocation
}
