
[CmdletBinding()]
param
()

Import-Module -Name $PSScriptRoot\ps_modules\VstsTaskSdk
Import-Module -Name $PSScriptRoot\ps_modules\ScmAzureTools

Trace-VstsEnteringInvocation $MyInvocation

try
{
    $serviceNameInput = Get-VstsInput -Name ConnectedServiceNameSelector -Default 'ConnectedServiceName'
    $serviceName = Get-VstsInput -Name $serviceNameInput -Default (Get-VstsInput -Name DeploymentEnvironmentName)
    $endpoint = Get-VstsEndpoint -Name $serviceName -Require
    $resourceGroupName = Get-VstsInput -Name 'ResourceGroupName' -Require
    $azureRegion = Get-VstsInput -Name 'AzureRegion' -Require
    $workerPool = Get-VstsInput -Name 'WorkerPool' -Require
    $numberOfWorkersFromWorkerPool = Get-VstsInput -Name 'NumberOfWorkersFromWorkerPool' -Require -AsInt
    $logRetentionDays = Get-VstsInput -Name 'LogRetentionDays' -Require -AsInt
    $aseName = Get-VstsInput -Name 'AseName' -Require
    $aseRgName = Get-VstsInput -Name 'AseResourceGroupName' -Require
    $projectCode = Get-VstsInput -Name 'ProjectCode' -Require
    $uniqueId = Get-VstsInput -Name 'ResourceUniqueId' -Require

    if (-not $endpoint)
    {
        throw "Endpoint not found..."
    }

    $workspaceId = Get-AzOmsWorkspaceId -SubscriptionName $endpoint.Data.SubscriptionName

    if (-not $workspaceId)
    {
        throw "No Workspace ID found for subscription name: '$($endpoint.Data.SubscriptionName)'"
    }

    $regionCode = Get-AzRegionCode -AzureRegion $azureRegion

    if (-not $regionCode)
    {
        throw "No region code found for Azure region: '$azureRegion'"
    }
}
catch
{
    Write-Error "Exception caught from task: $($_.Exception.ToString())"
    Trace-VstsLeavingInvocation $MyInvocation
    throw
}

# Build hashtable to splat for AzAppServicePlan name
$splatNewAzResourceName = @{
    AzResourceType = 'AzAppServicePlan'        
    ProjectCode    = $projectCode
    AzRegionCode   = $regionCode
    Environment    = $env:RELEASE_ENVIRONMENTNAME
    UniqueId       = $uniqueId
}
$appServicePlan = (New-AzResourceName @splatNewAzResourceName).Name

try 
{
    Update-PSModulePathForHostedAgent
    Initialize-AzSubscription -Endpoint $endpoint
    
    $templateParameterObejct = @{
        azureRegion                   = $azureRegion
        workerPool                    = $workerPool
        numberOfWorkersFromWorkerPool = $numberOfWorkersFromWorkerPool
        workspaceId                   = $workspaceId
        logsRetentionDays             = $logRetentionDays
        aseName                       = $aseName.ToLower()
        aseRgName                     = $aseRgName.ToUpper()
        appServicePlan                = $appServicePlan
    }

    $splatNewAzRgDeployment = @{
        Name                    = "$appServicePlan-deploy"
        ResourceGroupName       = $resourceGroupName
        TemplateFile            = ".\Templates\AppServicePlan.json"
        TemplateParameterObject = $templateParameterObejct
    }
    New-AzResourceGroupDeployment @splatNewAzRgDeployment
    
    Write-Verbose "Creating new variable: ado.AppServicePlan $appServicePlan"
    Write-Output "##vso[task.setvariable variable=ado.AppServicePlan;]$appServicePlan"

    Write-Verbose "Creating new variable: ado.AzureRegion $azureRegion"
    Write-Output "##vso[task.setvariable variable=ado.AzureRegion;]$azureRegion"
}
catch
{
    Write-Error "Exception caught from task: $($_.Exception.ToString())"
    throw
} 
finally 
{    
    Disconnect-AzSubscriptionAndClearContext
    Trace-VstsLeavingInvocation $MyInvocation
}
