
[CmdletBinding()]
param
()

Import-Module -Name $PSScriptRoot\ps_modules\VstsTaskSdk
Import-Module -Name $PSScriptRoot\ps_modules\ScmAzureTools

Trace-VstsEnteringInvocation $MyInvocation

try 
{
    $serviceNameInput = Get-VstsInput -Name ConnectedServiceNameSelector -Default 'ConnectedServiceName'
    $serviceName = Get-VstsInput -Name $serviceNameInput -Default (Get-VstsInput -Name DeploymentEnvironmentName)
    $endpoint = Get-VstsEndpoint -Name $serviceName -Require
    $resourceGroupName = Get-VstsInput -Name 'ResourceGroupName' -Require   
    $kvresourceGroupName = Get-VstsInput -Name 'kvResourceGroupName' -Require
    $sharedKeyVault = Get-VstsInput -Name 'sharedKeyVault' -Require
    $certificateName = Get-VstsInput -Name 'certificateName' -Require
    $HostName = Get-VstsInput -Name 'HostName' -Require
    $AppServiceName = Get-VstsInput -Name 'AppServiceName'
    $AppServicePlan = Get-VstsInput -Name 'AppServicePlan' 
    $AppServiceOutput = Get-VstsInput -Name 'AppServiceOutput' -Require
    $AzureRegion = Get-VstsInput -Name 'AzureRegion' -Require
    
    #find appservice name and ID if output flag is set to true
    #write-host $AppServiceOutput
    #write-host "Checking if output from previous task is needed."
    if (($AppServiceOutput -eq "true") -or ($AppServiceOutput -eq $true))
    {
        write-output "Updating AppServiceName, AppServicePlan and Region from outputs"
        $AppServiceNameFinal = $env:ado_AppServiceName
        $AppServicePlanFinal = $env:ado_AppServicePlan
        $AzureRegionFinal = $env:ado_AzureRegion
    }
    else
    {
        write-output "Using AppServiceName, AppServicePlan and Region from inputs"
        $AppServiceNameFinal = $AppServiceName
        $AppServicePlanFinal = $AppServicePlan
        $AzureRegionFinal = $AzureRegion
    }

    if (-not $endpoint)
    {
        throw "Endpoint not found..."
    }
}
catch
{
    Write-Error "Exception caught from task: $($_.Exception.ToString())"
    Trace-VstsLeavingInvocation $MyInvocation
    throw
}

try
{
    Update-PSModulePathForHostedAgent
    Initialize-AzSubscription -Endpoint $endpoint -ErrorAction Stop

    # Find shared keyvault id from Name    
    $kv = Get-AzKeyVault -ResourceGroupName $kvresourceGroupName -VaultName $sharedKeyVault
    $sharedKeyVaultId = $kv.ResourceId

    $templateParameterObejct = @{
        sharedKeyVaultId  = $sharedKeyVaultId
        certificateName   = $certificateName
        HostName          = $HostName
        webAppservicePlan = $AppServicePlanFinal
        webAppname        = $AppServiceNameFinal
        Location          = $AzureRegionFinal
    }

    $splatNewAzRgDeployment = @{
        Name                    = "deploy-$certificateName"
        ResourceGroupName       = $resourceGroupName
        TemplateFile            = ".\Templates\certificate.json"
        TemplateParameterObject = $templateParameterObejct        
    }
    New-AzResourceGroupDeployment @splatNewAzRgDeployment

    Write-Output "##vso[task.setvariable variable=ado.CertificateName;]$($certificateName.ToLower())"
    Write-Output "##vso[task.setvariable variable=ado.HostBinding;]$($HostName.ToLower())"
}
catch
{
    Write-Error "Exception caught from task: $($_.Exception.ToString())"
    throw
} 
finally 
{    
    Disconnect-AzSubscriptionAndClearContext
    Trace-VstsLeavingInvocation $MyInvocation
}
