# Drag-and-Drop Infrastructure

## Overview

Drag-and-Drop Infrastructure (DDI) is a collection of Azure DevOps extensions and tasks that allow you to build Deloitte-standard cloud infrastructure directly from a release pipeline with little-to-no coding required. You can also leverage Azure DevOps features, like Pipeline Variables, Approvers, and Deployment Gates, to ensure complete consistency across your platform.

### Azure Extension

[Marketplace](https://marketplace.visualstudio.com/items?itemName=DeloitteUSITSDAS.ScmAzureResourceDeploymentToolsV2&targetId=a4895a10-c273-4f02-a925-ffbfbd23f1f5&utm_source=vstsproduct&utm_medium=ExtHubManageList)

This extension provides a catalog of tasks for creating and managing Azure infrastructure. Now, instead of spending hours creating ARM templates, you can create resources like Application Services or SQL Databases in minutes with a few simple clicks.

_Please note that this tool cannot modify IAM permissions for resources in Azure and it can **ONLY** use those permissions provided to it by the service connection in Azure DevOps. If your service connection does not have permission to add resources, then the DDI tool does not either._

### Standards and Compliance

The DDI Azure Extension is backed by ARM templates that follow Deloitte Cyber standards, thus ensuring that the created infrastructure is fully compliant. The DDI team also monitors Cyber policies for updates and will update the tool accordingly.

### Before Getting Started

#### Azure Prerequisites

To build infrastructure using DDI, you must already have:

- A project in Azure DevOps.
- A service connection with access to your subscriptions and resource groups within Azure.
- A basic architecture plan for what you want to build in Azure.

#### Task Prerequisites

Each task in the extension has extensive [documentation](http://tfs.deloitte.com:8080/tfs/DAS%20Public/_git/ADO%20Extensions?path=%2FOverall.md) which details any prerequisite infrastructure, as well as the purpose and expected values for each field in the task form.

*Examples of Task Prerequisites:*

- To use the Certificate task, you will need to have an existing Key Vault with a certificate already stored inside it.
- To use the Traffic Manager task, you will need to know the URL to enter in as endpoint(s).

### Using the Tasks

- Open [Azure DevOps](https://dev.azure.com/apps-its-us-deloitte) and navigate to your project.
- Open or create a release pipeline.
- Select or create a pipeline stage, and open the tasks view.
- Click the Plus (+) on Agent job and search for **SCM** in the Add Tasks pane.
![TaskList Image](images/DDI-tasklist.png)
  - If you do not see any SCM Azure tasks in this list, please contact US SCM Platform Mgmt., <usscmplatformmgmt@deloitte.com>.
- Fill in the parameters based off the type of task (ex. resource group, project code, region etc..)
- ** _Special Note: Be sure to use the correct Agent Pool type in your release pipeline._
![TaskList Image](images/DDI-agentPool.png)

### Azure Infrastructure Task Lists

#### Currently Available

1. Application Service (Website, Webjob)
2. Azure SQL Database
3. KeyVault
4. KeyVault Access Policy
5. Storage Account
6. Add Certificate to Application Service
7. Traffic Manager
8. Application Insight

#### Preview/Testing

1. Azure SQL Server

#### Roadmap

1. Function
2. CosmosDB
3. Many more...make a suggestion at <usscmplatformmgmt@deloitte.com>

### Additional Information

This Getting Started document is only the beginning. For more detailed information and help, check the [documentation site](http://tfs.deloitte.com:8080/tfs/DAS%20Public/_git/ADO%20Extensions?path=%2FOverall.md).

## Contact Information

Please report problems, provide feedback, and submit feature requests to US SCM Platform Mgmt, <usscmplatformmgmt@deloitte.com>.
