[CmdletBinding()]
Param(
    [Parameter(Mandatory = $True)]
    [String]$resourceGroupsPath,

    [Parameter(Mandatory = $True)]
    [String]$projectTagsPath,

    [Parameter(Mandatory = $True)]
    [String]$sharedResourcesPath,

    [Parameter(Mandatory = $True)]
    [String]$subscriptionName,

    [Parameter(Mandatory = $True)]
    [String]$exceptionListPath,

    [Parameter(Mandatory = $True)]
    [String]$ResourceTypeApiVersionsPath
)

function Get-FilteredList
(
    [array]$list,
    [string]$filterKey,
    [string]$filterValue
) {
    $filteredList = @()
    foreach ($entry in $list) {
        $validEntry = $entry | Where-Object {$_.$filterKey -eq $filterValue}
        if ($validEntry) {
            $filteredList += $validEntry
        }
    }
    return $filteredList
}

function Get-ProjectTags
(
    [array]$list,
    [string]$projectCode

) {
    $projectTags = @{}
    $tagsList = Get-FilteredList -list $list -filterKey "ProjectCode" -filterValue $projectCode
    $tagsPropertyMembers = $tagsList.PSObject.Members.Name | Where-Object {$_ -like "Tag:*"}
    foreach ($entry in $tagsPropertyMembers) {
        $tagKey = $entry.Replace('Tag:', '').trim()
        $tagValue = $tagsList.$entry
        $projectTags.Add( $tagKey, $tagValue)
    }
    return $projectTags
}

function Find-ItemInList
(
    [array]$list,
    [string]$item,
    [string]$listFilterKey
) {
    $itemFound = $false
    foreach ($entry in $list) {
        if ($item -match $entry.$listFilterKey) {
            $itemFound = $true
        }
    }
    return  $itemFound
}

function Compare-Tags
(
    [hashtable]$referenceTag,
    [hashtable]$differenceTag
) {
    foreach ($key in $referenceTag.Keys) {
        if (($differenceTag.ContainsKey($key))) {
            if (!($differenceTag.$key -eq $referenceTag[$key])) {
                $differenceTag.Remove($key)
                $differenceTag.Add($key, $referenceTag[$key])
            }
        }
        else {
            $differenceTag.Add($key, $referenceTag[$key])
        }
    }
    return $differenceTag
}

function Compare-HashArray
(
    [hashtable]$referenceObject,
    [hashtable]$differenceObject
) {
    $diffFound = $false
    foreach ($entry in $referenceObject.GetEnumerator()) {
        [String]$referenceObjectKey = $entry.Name
        [String]$referenceObjectValue = $entry.Value
        [String]$differenceObjectValue = $differenceObject.item($referenceObjectKey)
        if ($referenceObjectValue) {
            if ($differenceObjectValue) {
                $diff = Compare-Object -ReferenceObject $referenceObjectValue -DifferenceObject $differenceObjectValue
                if ($diff) {
                    $diffFound = $true
                }
            }
            else {
                $diffFound = $true
            }
        }
        else {
            $diffFound = $true
        }
    }
    return $diffFound
}

function Update-Tags
(
    [Boolean]$apiVersionFlag,
    [array]$ResourceTypeApiVersionsList,
    $resource,
    [hashtable]$newResourcetags
) {
    $returnApiVersion = "Latest"
    if ($apiVersionFlag) {
        $resourceApiVersion = ($ResourceTypeApiVersionsList | Where-Object {$_.ResourceType -eq $resource.ResourceType}).ApiVersion
        Set-AzureRmResource -Tag $newResourcetags -ResourceId $resource.ResourceId -Force -ApiVersion $resourceApiVersion | Out-Null
        $returnApiVersion = $resourceApiVersion
    }
    else {
        Set-AzureRmResource -Tag $newResourcetags -ResourceId $resource.ResourceId -Force | Out-Null
    }
    return $returnApiVersion
}



# !#######################Start of Application###############################################################

try {
    #Import and Filter Resource Group List
    $rawResourceGroupsList = Import-Csv -Path $resourceGroupsPath
    $resourceGroupsList = Get-FilteredList -list $rawResourceGroupsList -filterKey "SubscriptionName" -filterValue $subscriptionName

    #Import and Filter Shared Resources List
    $rawSharedResourcesList = Import-Csv -Path $sharedResourcesPath
    $sharedResourcesList = Get-FilteredList -list $rawSharedResourcesList -filterKey "SubscriptionName" -filterValue $subscriptionName

    #Import Exception List
    $exceptionList = Import-Csv -Path $exceptionListPath

    #Import Resource Type API Version List
    $ResourceTypeApiVersionsList = Import-Csv -Path $ResourceTypeApiVersionsPath

    #Import Project Tags List
    $projectTagsList = Import-Csv -Path $projectTagsPath
}

catch {
    $ErrorMessage = $_.Exception.Message
    throw "Script failed, with error message: $ErrorMessage"
}

#loop through all resource groups
foreach ($entry in $resourceGroupsList) {

    #Get project tags from project csv file, and filter based on ProjectCode
    $projectTags = @{}
    $projectTags = Get-ProjectTags -list $projectTagsList -projectCode $entry.ProjectCode

    try {
        #Get Azure Resource Group Info
        $currentResourceGroup = Get-AzureRmResourceGroup $entry.ResourceGroupName

        Write-Host "`n*****************************"
        Write-Host "ResourceGroup:" $currentResourceGroup.ResourceGroupName "-> Processing..."

        #Get shared resource group flag from CSV file
        $sharedResourceGroupFlag = $entry.SharedResourceGroup

        #Apply project tags from csv file to Azure resource group
        Write-Host "ResourceGroup:" $currentResourceGroup.ResourceGroupName "-> Applying Tags.."
        Set-AzureRmResourceGroup -Tag $projectTags -Name $currentResourceGroup.ResourceGroupName | Out-Null
        Write-Host "ResourceGroup:" $currentResourceGroup.ResourceGroupName "-> Tags Applied Successfully"
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        throw "Script failed, with error message: $ErrorMessage"
    }

    #Apply all tags from a resource group to its resources, and retain existing tags on resources that are not duplicates and update matching tags keys
    if (($currentResourceGroup.Tags) -and ($sharedResourceGroupFlag -eq "False")) {
        try {
            Write-Host "ResourceGroup:" $currentResourceGroup.ResourceGroupName "-> Processing Resources in Resource Group..."
            #Get Resource Group Resources
            $resources = Get-AzureRmResource | Where-Object {$_.ResourceGroupName -eq $currentResourceGroup.ResourceGroupName}
            foreach ($resource in $resources) {

                #Determine if resource is a part of the exception list
                $exceptionFlag = Find-ItemInList -list $exceptionList -item $resource.ResourceId -listFilterKey "keyword"

                # Proceed if item wasn't found in exception list
                if (!$exceptionFlag) {

                    #Detrmine if API version is required
                    $apiVersionFlag = Find-ItemInList -list $ResourceTypeApiVersionsList -item $resource.ResourceType -listFilterKey "ResourceType"

                    if ($resource.tags) {

                        #compare current tags on the resource and compare to the list
                        #$newResourceTags = Compare-Tags -referenceTag $projectTags -differenceTag $resource.tags

                        #Check if resource tags need to be updated
                        $updateFlag = Compare-HashArray -ReferenceObject $projectTags -DifferenceObject $resource.tags

                        if ($updateFlag) {
                            Write-Host "ResourceGroup:" $currentResourceGroup.ResourceGroupName ",ResourceName:" $resource.Name ",ResourceType:" $resource.ResourceType "-> Updating Tags..." -ForegroundColor Yellow
                            $resourceApiVersion = Update-Tags -apiVersionFlag $apiVersionFlag -ResourceTypeApiVersionsList $ResourceTypeApiVersionsList -resource $resource -newResourcetags $projectTags
                            Write-Host "ResourceGroup:" $currentResourceGroup.ResourceGroupName ",ResourceName:" $resource.Name ",ResourceType:" $resource.ResourceType "-> Updating Tags Using API Version:" $resourceApiVersion
                            Write-Host "ResourceGroup:" $currentResourceGroup.ResourceGroupName ",ResourceName:" $resource.Name ",ResourceType:" $resource.ResourceType "-> Tags Updated" -ForegroundColor Green
                        }
                        else {
                            Write-Host "ResourceGroup:" $currentResourceGroup.ResourceGroupName ",ResourceName:" $resource.Name ",ResourceType:" $resource.ResourceType "-> Tags Matched, Skip Update"
                        }
                    }
                    else {
                        #Run When Resource doesn't have any tags
                        Write-Host "ResourceGroup:" $currentResourceGroup.ResourceGroupName ",ResourceName:" $resource.Name ",ResourceType:" $resource.ResourceType "-> Updating Tags..." -ForegroundColor Yellow
                        Write-Host "ResourceGroup:" $currentResourceGroup.ResourceGroupName ",ResourceName:" $resource.Name ",ResourceType:" $resource.ResourceType "-> Updating All Tags" -ForegroundColor Yellow
                        $resourceApiVersion = Update-Tags -apiVersionFlag $apiVersionFlag -ResourceTypeApiVersionsList $ResourceTypeApiVersionsList -resource $resource -newResourcetags $projectTags
                        Write-Host "ResourceGroup:" $currentResourceGroup.ResourceGroupName ",ResourceName:" $resource.Name ",ResourceType:" $resource.ResourceType "-> Updating Tags Using API Version:" $resourceApiVersion
                        Write-Host "ResourceGroup:" $currentResourceGroup.ResourceGroupName ",ResourceName:" $resource.Name ",ResourceType:" $resource.ResourceType "-> Tags Updated" -ForegroundColor Green
                    }
                }
                else {
                    Write-Host "ResourceGroup:" $currentResourceGroup.ResourceGroupName ",ResourceName:" $resource.Name ",ResourceType:" $resource.ResourceType "-> Resource Found in Exception List, Skip Update"
                }
            }
        }
        catch {
            $ErrorMessage = $_.Exception.Message
            throw "Script failed, with error message: $ErrorMessage"
        }
    }
    else {
        Write-Host "ResourceGroup:" $currentResourceGroup.ResourceGroupName "-> Stop Processing, Skip Resources Since Resource Group is Shared"
    }
    Write-Host "ResourceGroup:" $currentResourceGroup.ResourceGroupName "-> Processing Successfully Completed"
}



foreach ($entry in $sharedResourcesList) {

    #Get project tags from project csv file, and filter based on ProjectCode
    $projectTags = @{}
    $projectTags = Get-ProjectTags -list $projectTagsList -projectCode $entry.ProjectCode

    try {
        #Get Azure Resource Group Info
        $currentResource = Get-AzureRmResource -ResourceGroupName $entry.ResourceGroupName  -Name $entry.ResourceName -ResourceType $entry.ResourceType

        Write-Host "`n*****************************"
        Write-Host "SharedResourceGroup:" $currentResource.ResourceGroupName "-> Processing..."

        #Determine if resource is a part of the exception list
        $exceptionFlag = Find-ItemInList -list $exceptionList -item $currentResource.ResourceId -listFilterKey "keyword"

        if (!$exceptionFlag) {
            
            #Detrmine if API version is required
            $apiVersionFlag = Find-ItemInList -list $ResourceTypeApiVersionsList -item $currentResource.ResourceType -listFilterKey "ResourceType"

            if ($currentResource.tags) {
                #Check if resource tags need to be updated
                $updateFlag = Compare-HashArray -ReferenceObject $projectTags -DifferenceObject $currentResource.tags
                if ($updateFlag) {
                    Write-Host "SharedResourceGroup:" $currentResource.ResourceGroupName ",ResourceName:" $currentResource.Name ",ResourceType:" $currentResource.ResourceType "-> Updating Tags..." -ForegroundColor Yellow
                    $resourceApiVersion = Update-Tags -apiVersionFlag $apiVersionFlag -ResourceTypeApiVersionsList $ResourceTypeApiVersionsList -resource $currentResource -newResourcetags $projectTags
                    Write-Host "SharedResourceGroup:" $currentResource.ResourceGroupName ",ResourceName:" $currentResource.Name ",ResourceType:" $currentResource.ResourceType "-> Updating Tags Using API Version:" $resourceApiVersion
                    Write-Host "SharedResourceGroup:" $currentResource.ResourceGroupName ",ResourceName:" $currentResource.Name ",ResourceType:" $currentResource.ResourceType "-> Tags Updated" -ForegroundColor Green
                }
                else {
                    Write-Host "SharedResourceGroup:" $currentResource.ResourceGroupName ",ResourceName:" $currentResource.Name ",ResourceType:" $currentResource.ResourceType "-> Tags Matched, Skip Update"
                }
            }
            else {
                #Run When Resource doesn't have any tags
                Write-Host "SharedResourceGroup:" $currentResource.ResourceGroupName ",ResourceName:" $currentResource.Name ",ResourceType:" $currentResource.ResourceType "-> Updating Tags..." -ForegroundColor Yellow
                Write-Host "SharedResourceGroup:" $currentResource.ResourceGroupName ",ResourceName:" $currentResource.Name ",ResourceType:" $currentResource.ResourceType "-> Updating All Tags" -ForegroundColor Yellow
                $resourceApiVersion = Update-Tags -apiVersionFlag $apiVersionFlag -ResourceTypeApiVersionsList $ResourceTypeApiVersionsList -resource $currentResource -newResourcetags $projectTags
                Write-Host "SharedResourceGroup:" $currentResource.ResourceGroupName ",ResourceName:" $currentResource.Name ",ResourceType:" $currentResource.ResourceType "-> Updating Tags Using API Version:" $resourceApiVersion
                Write-Host "SharedResourceGroup:" $currentResource.ResourceGroupName ",ResourceName:" $currentResource.Name ",ResourceType:" $currentResource.ResourceType "-> Tags Updated" -ForegroundColor Green
            }
        }
        else {
            Write-Host "SharedResourceGroup:" $currentResource.ResourceGroupName ",ResourceName:" $currentResource.Name ",ResourceType:" $currentResource.ResourceType "-> Resource Found in Exception List, Skip Update"
        }
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        throw "Script failed, with error message: $ErrorMessage"
    }
    Write-Host "SharedResourceGroup:" $currentResource.ResourceGroupName "-> Processing Successfully Completed"
}
