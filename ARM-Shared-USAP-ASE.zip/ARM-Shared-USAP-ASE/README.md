East US - Preprod

$resourceGroupName = "AZRG-USAP-DAS-ASE-PREPROD-EUS"
$resourceGroupLocation = "East US"
$deploymentName = "ase-eus"
$templateFile = ".\ase\ase.json"
$templateParameterFile = ".\ase\preprod-ase-eus.parameters.json"

New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName `
-TemplateFile $templateFile `
-TemplateParameterFile $templateParameterFile


East US - Prod

$resourceGroupName = "AZRG-USAP-DAS-ASE-PROD-EUS"
$resourceGroupLocation = "East US"
$deploymentName = "ase-eus"
$templateFile = ".\ase\ase.json"
$templateParameterFile = ".\ase\prod-ase-eus.parameters.json"

New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName `
-TemplateFile $templateFile `
-TemplateParameterFile $templateParameterFile


West US - Prod

$resourceGroupName = "AZRG-USAP-DAS-ASE-PROD-EUS"
$resourceGroupLocation = "West US"
$deploymentName = "ase-wus"
$templateFile = ".\ase\ase.json"
$templateParameterFile = ".\ase\prod-ase-wus.parameters.json"

New-AzureRmResourceGroupDeployment -Name $deploymentName -ResourceGroupName $resourceGroupName `
-TemplateFile $templateFile `
-TemplateParameterFile $templateParameterFile